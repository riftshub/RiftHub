"""Renders every sound file for Vertigo Freight, Creeps, Night Owl Market and Little Lantern.

    python3 tools/sfx/render.py            # writes client/vertigo/audio/*.mp3 and client/creeps/audio/*.mp3

Needs numpy, scipy and ffmpeg (with libmp3lame).
"""
import os
import subprocess
import sys
import tempfile
import json
import numpy as np
from scipy.io import wavfile

sys.path.insert(0, os.path.dirname(__file__))
from synth import *  # noqa
import synth

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
OUT = {
    'vertigo': os.path.join(ROOT, 'client', 'vertigo', 'audio'),
    'creeps': os.path.join(ROOT, 'client', 'creeps', 'audio'),
    'market': os.path.join(ROOT, 'client', 'market', 'audio'),
    'lantern': os.path.join(ROOT, 'client', 'lantern', 'audio'),
}
written = {'vertigo': [], 'creeps': [], 'market': [], 'lantern': []}


def save(game, name, x, loop=False, kbps=None):
    os.makedirs(OUT[game], exist_ok=True)
    x = np.asarray(x, dtype=np.float64)
    if not loop:
        x = fade(x, 0.002, 0.03)
    x = normalize(x, -1.5)
    data = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
        wavfile.write(f.name, SR, data)
        tmp = f.name
    stereo = x.ndim == 2
    rate = kbps or (128 if stereo else 96)
    dst = os.path.join(OUT[game], name + '.mp3')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp, '-codec:a', 'libmp3lame', '-b:a', f'{rate}k', dst], check=True)
    os.unlink(tmp)
    written[game].append(name)


# ═══════════════════════════ shared recipes ═══════════════════════════

def step(surface, k):
    synth.seed(100 + k * 7 + hash(surface) % 50)
    d = 0.32
    n = noise(d)
    if surface == 'metal':
        thud = lp(n, 300) * env_exp(len(n), 0.03) * 2.2
        ring1 = sum(osc(f * (1 + 0.03 * k), d) * env_exp(len(n), 0.06 + 0.02 * i) * a for i, (f, a) in enumerate([(420, 0.25), (1130, 0.12), (2650, 0.06)]))
        grit = bp(n, 1800, 6000) * env_exp(len(n), 0.012) * 0.7
        x = thud + ring1 + grit
    elif surface == 'wood':
        x = bp(n, 120, 900) * env_exp(len(n), 0.035) * 2 + bp(n, 2000, 5000) * env_exp(len(n), 0.008) * 0.6 + osc(190 + 15 * k, d) * env_exp(len(n), 0.04) * 0.4
    elif surface == 'carpet':
        x = lp(n, 700) * env_exp(len(n), 0.05) * 1.6 + bp(n, 2000, 4000) * env_exp(len(n), 0.03) * 0.15
    elif surface == 'foam':  # soft-play mats: muffled squish
        x = lp(n, 450) * env_adsr(len(n), 0.01, 0.06, 0.2, 0.08) * 1.8 + osc(glide([(0, 260), (1, 180)], d), d) * env_exp(len(n), 0.04) * 0.25
    elif surface == 'tile':
        x = bp(n, 600, 5000) * env_exp(len(n), 0.012) * 1.4 + lp(n, 250) * env_exp(len(n), 0.03) * 1.2
    else:
        x = lp(n, 1000) * env_exp(len(n), 0.04)
    # heel then toe
    y = x.copy()
    y = place(y, x * 0.45, 0.06 + 0.01 * k)
    return reverb(y, 0.35, 0.15)


def heartbeat():
    synth.seed(5)
    d = 0.9
    x = silence(d)
    for at, a in [(0.0, 1.0), (0.24, 0.7)]:
        b = osc(glide([(0, 70), (1, 38)], 0.18), 0.18) * env_exp(int(0.18 * SR), 0.06)
        b = lp(b + noise(0.18) * 0.05, 160) * a
        x = place(x, b, at)
    return x


def stinger(kind):
    synth.seed(30 + kind)
    d = 3.2
    t = t_axis(d)
    if kind == 0:  # string screech cluster
        x = sum(osc(glide([(0, f), (1, f * 1.06)], d), d, 'saw') * (0.6 + 0.4 * np.sin(2 * np.pi * (5 + i) * t)) for i, f in enumerate([880, 932, 988, 1046]))
        x = bp(x, 600, 5000) * env_adsr(len(x), 0.005, 0.4, 0.4, 2.0)
        x += lp(noise(d), 120) * env_exp(len(x), 0.4) * 3  # low hit
    elif kind == 1:  # brass/metal hit with bend
        x = sum(osc(glide([(0, f), (1, f * 0.7)], d), d, 'saw') for f in [55, 82.4, 110, 164]) * env_exp(int(d * SR), 0.8)
        x = lp(distort(x, 2), 1800) + bp(noise(d), 3000, 9000) * env_exp(int(d * SR), 0.2) * 0.6
    else:  # reversed swell into hit
        sw = bp(noise(1.6), 300, 6000) * np.linspace(0, 1, int(1.6 * SR)) ** 3
        hit = lp(noise(1.6), 200) * env_exp(int(1.6 * SR), 0.3) * 3 + osc(46, 1.6) * env_exp(int(1.6 * SR), 0.5) * 2
        x = np.concatenate([sw, hit])
    return reverb(x, 2.4, 0.35, stereo=True)


def scream(kind=0):
    """Jump-scare scream: shrieking voice + metal screech + sub hit"""
    synth.seed(60 + kind)
    d = 1.6
    pitch = glide([(0, 520), (0.08, 980), (0.5, 900), (1, 620)], d) * (1 + 0.04 * np.sin(2 * np.pi * 23 * t_axis(d)))
    v = formant_voice(pitch, ['a', 'aa', 'a', 'ow'], d, breath=0.6) * 1.0
    v2 = formant_voice(pitch * 1.49, ['e', 'a', 'a', 'a'], d, breath=0.6) * 0.6
    screech = sum(osc(glide([(0, f), (1, f * 0.85)], d), d, 'saw') for f in [2100, 2230, 3150]) * 0.25
    screech = bp(screech, 1500, 7000)
    x = distort(v + v2 + screech, 4) * env_adsr(int(d * SR), 0.004, 0.2, 0.8, 0.6)
    sub = osc(glide([(0, 90), (1, 30)], d), d) * env_exp(int(d * SR), 0.35) * 1.5
    x += sub + lp(noise(d), 200) * env_exp(int(d * SR), 0.15) * 2
    return reverb(x, 1.4, 0.3, stereo=True)


def growl(kind, length=1.6, base=58):
    synth.seed(80 + kind)
    d = length
    t = t_axis(d)
    # rough voiced source: low pitch with jitter + amplitude flutter
    jitter = 1 + 0.08 * lp(noise(d), 18) * 6
    pitch = base * (1 + 0.15 * np.sin(2 * np.pi * 0.7 * t)) * jitter
    src = osc(pitch, d, 'saw') * (0.6 + 0.4 * np.abs(lp(noise(d), 40) * 8))
    src += noise(d) * 0.18
    x = peak(src, 330, 5, 1.0) + peak(src, 750, 6, 0.6) + peak(src, 2200, 8, 0.15) + lp(src, 160) * 0.8
    x = lp(distort(x * 1.5, 2.5), 3200) * env_adsr(int(d * SR), 0.15, 0.3, 0.8, 0.5)
    return reverb(x, 1.0, 0.25)


def whisper(kind):
    synth.seed(120 + kind)
    d = 1.8
    x = silence(d)
    at = 0.05
    for i in range(5 + kind % 3):
        sd = 0.12 + rng.random() * 0.18
        vowel = ['i', 'e', 'a', 'u', 'o'][int(rng.random() * 5)]
        s = formant_voice(200, [vowel], sd, breath=8.0) * 0.08
        s += bp(noise(sd), 3500, 8000) * (0.4 if rng.random() < 0.5 else 0.1)  # sibilants
        s *= env_adsr(len(s), 0.02, 0.05, 0.7, 0.05)
        x = place(x, s, at)
        at += sd + rng.random() * 0.08
    return reverb(x, 1.8, 0.45, stereo=True)


def door_slide(slam=False):
    synth.seed(140 + slam)
    d = 1.1 if not slam else 0.9
    n = noise(d)
    roll = bp(n, 200, 1800) * (0.5 + 0.5 * lp(np.abs(noise(d)), 30) * 6)
    roll *= env_adsr(len(n), 0.05, 0.1, 0.8, 0.25)
    squeal = osc(glide([(0, 1300), (1, 1700)], d), d, 'saw') * 0.05 * env_adsr(len(n), 0.2, 0.1, 0.5, 0.3)
    x = roll + bp(squeal, 900, 4000)
    stop = lp(noise(0.3), 400) * env_exp(int(0.3 * SR), 0.05) * (4 if slam else 1.5)
    stop += sum(osc(f, 0.3) * env_exp(int(0.3 * SR), 0.12) for f in [180, 410, 960]) * (0.6 if slam else 0.2)
    x = place(np.pad(x, (0, int(0.3 * SR))), stop, d - 0.06)
    return reverb(x, 0.8, 0.2)


def click():
    synth.seed(150)
    d = 0.12
    return bp(noise(d), 1500, 8000) * env_exp(int(d * SR), 0.004) + osc(2400, d) * env_exp(int(d * SR), 0.01) * 0.3


def pickup():
    synth.seed(151)
    d = 0.5
    x = silence(d)
    for i, f in enumerate([660, 990]):
        x = place(x, osc(f, 0.25, 'tri') * env_exp(int(0.25 * SR), 0.08) * 0.5, i * 0.07)
    x += bp(noise(d), 2000, 6000) * env_exp(int(d * SR), 0.02) * 0.3
    return reverb(x, 0.6, 0.2)


def lever():
    synth.seed(152)
    d = 0.8
    ratchet = silence(d)
    for i in range(6):
        ratchet = place(ratchet, bp(noise(0.03), 1200, 5000) * env_exp(int(0.03 * SR), 0.006), 0.05 + i * 0.05)
    clunk = lp(noise(0.4), 300) * env_exp(int(0.4 * SR), 0.08) * 3 + osc(110, 0.4) * env_exp(int(0.4 * SR), 0.12)
    return reverb(place(ratchet, clunk, 0.38), 0.7, 0.2)


def locked():
    synth.seed(153)
    d = 0.5
    x = silence(d)
    for at in (0.0, 0.14):
        x = place(x, (bp(noise(0.08), 400, 3000) + osc(320, 0.08, 'square') * 0.2) * env_exp(int(0.08 * SR), 0.02), at)
    return reverb(x, 0.5, 0.2)


def thunder(kind):
    synth.seed(160 + kind)
    d = 6.0
    crack = bp(noise(0.25), 800, 8000) * env_exp(int(0.25 * SR), 0.05) * 1.5
    rumble = lp(noise(d, 'brown'), 140) * (env_adsr(int(d * SR), 0.08, 1.0, 0.5, 4.0) * (0.6 + 0.4 * lp(np.abs(noise(d)), 4) * 10))
    x = place(rumble * 3, crack, 0.02)
    return reverb(x, 3, 0.4, stereo=True)


def chase_loop(bpm=150, key=55.0, bars=4, creepy_box=False):
    """Driving chase music: pounding drums, pulsing bass, dissonant stabs"""
    synth.seed(200 + bpm)
    beat = 60 / bpm
    d = beat * 4 * bars
    x = silence(d)
    kick = lambda: (osc(glide([(0, 140), (1, 42)], 0.25), 0.25) * env_exp(int(0.25 * SR), 0.09) * 1.4)
    snare = lambda: (bp(noise(0.2), 800, 7000) * env_exp(int(0.2 * SR), 0.05) + osc(190, 0.2) * env_exp(int(0.2 * SR), 0.03) * 0.5)
    hat = lambda: hp(noise(0.05), 7000) * env_exp(int(0.05 * SR), 0.012) * 0.35
    for b in range(4 * bars):
        at = b * beat
        x = place(x, kick(), at)
        if b % 2 == 1:
            x = place(x, snare(), at)
        if b % 4 == 3:
            x = place(x, kick() * 0.7, at + beat * 0.5)
        for s in range(2):
            x = place(x, hat(), at + s * beat / 2)
    # pulsing bass (8ths), dissonant movement every bar
    roots = [key, key, key * 1.059, key * 0.944]
    for bar in range(bars):
        for e in range(8):
            f = roots[bar % 4] * (2 if e % 4 == 2 else 1)
            note = lp(osc(f, beat / 2, 'saw') + osc(f * 1.005, beat / 2, 'saw'), 600) * env_adsr(int(beat / 2 * SR), 0.005, 0.05, 0.6, 0.05) * 0.5
            x = place(x, note, (bar * 8 + e) * beat / 2)
        # stab
        stab_f = [key * 8, key * 8 * 1.059, key * 8 * 1.414]
        stab = sum(osc(f, beat, 'saw') for f in stab_f)
        stab = bp(stab, 400, 4000) * env_exp(int(beat * SR), 0.25) * 0.25
        x = place(x, stab, bar * beat * 4)
        if creepy_box:
            mel = [12, 11, 7, 6][bar % 4]
            for i in range(4):
                f = key * 16 * 2 ** ((mel - i * 2) / 12)
                tone = osc(f, 0.4, 'sine') * env_exp(int(0.4 * SR), 0.15) * 0.18 + osc(f * 3.01, 0.4) * env_exp(int(0.4 * SR), 0.05) * 0.05
                x = place(x, tone, bar * beat * 4 + i * beat)
    x = reverb(x, 1.2, 0.2, stereo=True)
    return make_loop(x[:int((d + 0.4) * SR)], 0.4)


def breath_loop():
    synth.seed(210)
    d = 6.0
    x = silence(d)
    for i in range(4):
        at = i * 1.5
        inhale = bp(noise(0.6), 500, 3000) * env_adsr(int(0.6 * SR), 0.2, 0.1, 0.8, 0.3) * 0.5
        exhale = bp(noise(0.7), 300, 2200) * env_adsr(int(0.7 * SR), 0.05, 0.2, 0.6, 0.4) * 0.6
        x = place(x, inhale, at)
        x = place(x, exhale, at + 0.65)
    return make_loop(np.pad(x, (0, SR)), 0.5)


def gasp():
    synth.seed(211)
    d = 0.6
    x = bp(noise(d), 600, 3500) * env_adsr(int(d * SR), 0.01, 0.1, 0.6, 0.4)
    x += formant_voice(glide([(0, 260), (1, 200)], d), ['a', 'u'], d, breath=4) * 0.05
    return reverb(x, 0.6, 0.15)


def drag():
    synth.seed(212)
    d = 2.2
    n = noise(d)
    x = bp(n, 150, 1400) * (0.4 + 0.6 * np.abs(lp(noise(d), 6) * 12))
    x *= env_adsr(len(n), 0.3, 0.2, 0.7, 0.6)
    x += sum(osc(f, d) * 0.03 for f in [220, 233]) * env_adsr(len(n), 0.4, 0.2, 0.6, 0.6)
    return reverb(x, 1.5, 0.3)


def creature_step(k):
    synth.seed(220 + k)
    d = 0.45
    thud = lp(noise(d), 180) * env_exp(int(d * SR), 0.05) * 2.5
    claw = bp(noise(d), 2500, 7000) * env_exp(int(d * SR), 0.01) * 0.6
    claw2 = place(silence(d), bp(noise(0.05), 3000, 8000) * env_exp(int(0.05 * SR), 0.008) * 0.5, 0.04 + 0.01 * k)
    return reverb(thud + claw + claw2, 0.9, 0.25)


def knock():
    synth.seed(230)
    d = 1.4
    x = silence(d)
    for i in range(3):
        k = lp(noise(0.2), 600) * env_exp(int(0.2 * SR), 0.03) * 2 + osc(150, 0.2) * env_exp(int(0.2 * SR), 0.05)
        x = place(x, k, i * 0.42)
    return reverb(x, 1.0, 0.35)


def rattle():
    synth.seed(231)
    d = 2.4
    x = silence(d)
    at = 0
    while at < d - 0.1:
        hit = bp(noise(0.06), 300, 4000) * env_exp(int(0.06 * SR), 0.015) + osc(240 + rng.random() * 60, 0.06, 'square') * env_exp(int(0.06 * SR), 0.01) * 0.15
        x = place(x, hit * (0.5 + rng.random() * 0.5), at)
        at += 0.05 + rng.random() * 0.09
    return reverb(x, 0.6, 0.15)


def paper():
    synth.seed(232)
    d = 0.6
    return bp(noise(d), 1500, 8000) * env_adsr(int(d * SR), 0.02, 0.1, 0.5, 0.3) * (0.5 + 0.5 * np.abs(lp(noise(d), 30) * 10))


def creak(k):
    synth.seed(240 + k)
    d = 1.6
    # stick-slip: pulse train with drifting rate through resonances
    rate = glide([(0, 18 + 6 * k), (0.5, 40), (1, 22)], d)
    src = osc(rate, d, 'pulse')
    x = peak(src, 520 + 90 * k, 14) + peak(src, 1300, 16, 0.6) + peak(src, 2700, 18, 0.25)
    return reverb(x * env_adsr(len(x), 0.1, 0.2, 0.8, 0.4), 1.0, 0.25)


def ui_chime(notes, wave='sine', spacing=0.11, decay=0.35):
    synth.seed(250)
    d = spacing * len(notes) + 1.0
    x = silence(d)
    for i, f in enumerate(notes):
        tone = osc(f, 0.9, wave) * env_exp(int(0.9 * SR), decay) + osc(f * 2.01, 0.9) * env_exp(int(0.9 * SR), decay / 3) * 0.2
        x = place(x, tone * 0.5, i * spacing)
    return reverb(x, 1.2, 0.25)


# ═══════════════════════════ Vertigo Freight ═══════════════════════════

def train_loop():
    synth.seed(300)
    d = 12.0
    rumble = lp(noise(d, 'brown'), 90) * 2.5 + lp(noise(d, 'pink'), 300) * 0.25
    rumble *= 1 + 0.15 * np.sin(2 * np.pi * 0.31 * t_axis(d))
    x = rumble
    # wheel clacks: pairs every ~1.5 s (bogies), loop-aligned
    period = d / 8
    for i in range(8):
        for off in (0.0, 0.11):
            c = lp(noise(0.12), 900) * env_exp(int(0.12 * SR), 0.02) * 1.6 + bp(noise(0.12), 2000, 5000) * env_exp(int(0.12 * SR), 0.006) * 0.4
            x = place(x, c, i * period + off + 0.3)
    # body creaks + far squeal
    x = place(x, creak(1) * 0.15, 3.0)
    x = place(x, creak(2) * 0.1, 8.1)
    st = reverb(x, 0.9, 0.2, stereo=True)
    return make_loop(st[:int((d + 0.9) * SR)], 0.9)


def wind_loop():
    synth.seed(301)
    d = 10.0
    n = noise(d, 'pink')
    x = sweep_filter(n, 300, 900, q=3) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.2 * t_axis(d)))
    whistle = osc(glide([(0, 700), (0.5, 980), (1, 760)], d), d) * 0.03 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.13 * t_axis(d)))
    st = reverb(x + whistle, 1.0, 0.2, stereo=True)
    return make_loop(st[:int((d + 1) * SR)], 1.0)


def drone_loop(key=41.2):
    synth.seed(302)
    d = 12.0
    t = t_axis(d)
    x = sum(osc(key * m * (1 + 0.002 * i), d, 'saw') * a for i, (m, a) in enumerate([(1, 0.6), (1.5, 0.3), (2.12, 0.2), (3.03, 0.1)]))
    x = lp(x, 500) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.09 * t))
    x += bp(noise(d), 2000, 6000) * 0.02 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.31 * t))
    st = reverb(x, 3.0, 0.4, stereo=True)
    return make_loop(st[:int((d + 1.5) * SR)], 1.5)


def power_down():
    synth.seed(310)
    d = 2.6
    f = glide([(0, 120), (1, 18)], d)
    x = osc(f, d, 'saw') * 0.6 + osc(f * 2, d, 'square') * 0.15
    x = lp(x, 900) * env_adsr(int(d * SR), 0.01, 0.2, 0.8, 1.2)
    clunk = lp(noise(0.5), 250) * env_exp(int(0.5 * SR), 0.1) * 3
    return reverb(place(x, clunk, 0), 1.6, 0.3, stereo=True)


def power_up():
    synth.seed(311)
    d = 3.0
    f = glide([(0, 22), (1, 120)], d)
    x = (osc(f, d, 'saw') * 0.6 + osc(f * 2, d, 'square') * 0.1)
    x = lp(x, 1200) * env_adsr(int(d * SR), 0.6, 0.2, 0.9, 0.5)
    hum = osc(60, d) * 0.2 + osc(120, d) * 0.1
    x += hum * np.linspace(0, 1, int(d * SR))
    clunk = lp(noise(0.5), 250) * env_exp(int(0.5 * SR), 0.1) * 3
    return reverb(place(x, clunk, 0), 1.6, 0.3, stereo=True)


def radio_static():
    synth.seed(312)
    d = 2.5
    n = noise(d)
    x = bp(n, 800, 5000) * (0.5 + 0.5 * (lp(np.abs(noise(d)), 15) * 10 > 0.6))
    voice = formant_voice(glide([(0, 140), (0.5, 120), (1, 150)], d), ['o', 'u', 'a', 'e', 'o'], d, breath=0.3)
    x += bitcrush(bp(voice, 400, 2800), 5, 6) * 0.25
    return distort(x, 2)


def brakes():
    synth.seed(313)
    d = 7.0
    t = t_axis(d)
    f = glide([(0, 2400), (0.7, 1800), (1, 900)], d)
    x = sum(osc(f * m, d, 'saw') * a for m, a in [(1, 0.4), (1.007, 0.4), (1.5, 0.15)])
    x = bp(x, 700, 6000) * (0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 7 * t)))
    x *= env_adsr(int(d * SR), 0.3, 0.5, 0.8, 2.0)
    x += lp(noise(d, 'brown'), 120) * 2 * env_adsr(int(d * SR), 0.1, 1, 0.7, 3)
    return reverb(x, 1.5, 0.3, stereo=True)


def render_vertigo():
    g = 'vertigo'
    save(g, 'amb_train', train_loop(), loop=True)
    save(g, 'amb_wind', wind_loop(), loop=True)
    save(g, 'amb_drone', drone_loop(), loop=True)
    save(g, 'music_chase', chase_loop(146, 49.0, 4), loop=True)
    save(g, 'breath_loop', breath_loop(), loop=True)
    for s in ('metal', 'wood', 'carpet'):
        for k in range(4):
            save(g, f'step_{s}_{k + 1}', step(s, k))
    for k in range(3):
        save(g, f'creature_step_{k + 1}', creature_step(k))
        save(g, f'growl_{k + 1}', growl(k, 1.4 + 0.3 * k, 52 + 8 * k))
        save(g, f'whisper_{k + 1}', whisper(k))
        save(g, f'stinger_{k + 1}', stinger(k))
    save(g, 'roar', growl(9, 2.6, 46) * 1.0 + growl(10, 2.6, 70) * 0.6)
    save(g, 'scream', scream(0))
    save(g, 'heartbeat', heartbeat())
    save(g, 'drag', drag())
    save(g, 'door_slide', door_slide(False))
    save(g, 'door_slam', door_slide(True))
    save(g, 'locked', locked())
    save(g, 'pickup', pickup())
    save(g, 'click', click())
    save(g, 'lever', lever())
    save(g, 'power_up', power_up())
    save(g, 'power_down', power_down())
    save(g, 'radio_static', radio_static())
    save(g, 'thunder_1', thunder(0))
    save(g, 'thunder_2', thunder(1))
    save(g, 'gasp', gasp())
    save(g, 'brakes', brakes())
    save(g, 'knock', knock())
    save(g, 'rattle', rattle())
    save(g, 'paper', paper())
    save(g, 'creak_1', creak(0))
    save(g, 'creak_2', creak(1))
    save(g, 'valve', lever())
    save(g, 'objective', ui_chime([392, 523.25, 659.25], 'tri', 0.14, 0.5))
    save(g, 'checkpoint', ui_chime([523.25, 659.25], 'sine', 0.18, 0.6))


# ═══════════════════════════ Creeps ═══════════════════════════

def playroom_loop():
    """Fluorescent hum + air handling + a far-off, warped nursery tune"""
    synth.seed(400)
    d = 16.0
    t = t_axis(d)
    hum = (osc(120, d) * 0.12 + osc(240, d) * 0.05 + osc(360, d) * 0.03) * (1 + 0.05 * np.sin(2 * np.pi * 0.5 * t))
    buzz = bp(noise(d), 3000, 7000) * 0.015
    air = lp(noise(d, 'pink'), 400) * 0.4
    x = hum + buzz + air
    # distant music box melody (detuned, wobbly), heavily filtered as if through walls
    mel = [72, 76, 79, 76, 74, 72, 71, 67, 69, 71, 72, 67]
    for i, m in enumerate(mel):
        f = 440 * 2 ** ((m - 69) / 12) * (1 - 0.01 * i)
        tone = (osc(f, 1.2) + osc(f * 3.98, 1.2) * 0.15) * env_exp(int(1.2 * SR), 0.4) * 0.07
        x = place(x, lp(tone, 1800), 0.8 + i * 1.2)
    st = reverb(x, 2.5, 0.35, stereo=True)
    return make_loop(st[:int((d + 1.5) * SR)], 1.5)


def music_box_loop():
    synth.seed(401)
    beat = 0.42
    mel = [76, 79, 84, 83, 79, 76, 77, 74, 76, 72, 74, 71, 72, 67, 69, 71]
    d = beat * len(mel)
    x = silence(d + 2)
    for i, m in enumerate(mel):
        f = 440 * 2 ** ((m - 69) / 12) * (1 + 0.006 * np.sin(i))
        tone = (osc(f, 1.6) + osc(f * 2.0, 1.6) * 0.3 + osc(f * 5.4, 1.6) * 0.05) * env_exp(int(1.6 * SR), 0.5)
        x = place(x, tone * 0.4, i * beat)
        if i % 4 == 0:
            low = osc(f / 4, 1.6) * env_exp(int(1.6 * SR), 0.7) * 0.25
            x = place(x, low, i * beat)
    # wind-down warble
    x = x * (1 + 0.02 * np.sin(2 * np.pi * 3 * np.arange(len(x)) / SR))
    st = reverb(x, 2.0, 0.35, stereo=True)
    return make_loop(st[:int((d + 1) * SR)], 1.0)


def vent_loop():
    synth.seed(402)
    d = 10.0
    x = sweep_filter(noise(d, 'pink'), 200, 500, 2) * 0.8 + osc(55, d) * 0.05
    for at in (2.3, 6.8):
        x = place(x, bp(noise(0.3), 400, 2500) * env_exp(int(0.3 * SR), 0.08) * 0.6, at)  # metal tick
    st = reverb(x, 1.4, 0.4, stereo=True)
    return make_loop(st[:int((d + 1) * SR)], 1.0)


def giggle(kind):
    """Child-like giggle, slightly wrong (pitch-shifted, ring modulated)"""
    synth.seed(410 + kind)
    n_syl = 4 + kind
    d = 0.11 * n_syl + 1.0
    x = silence(d)
    base = 420 + 60 * kind
    for i in range(n_syl):
        sd = 0.09
        p = glide([(0, base * (1.15 - i * 0.05)), (1, base * (0.95 - i * 0.05))], sd)
        syl = formant_voice(p, ['i', 'e'], sd, breath=0.3) * env_adsr(int(sd * SR), 0.005, 0.03, 0.5, 0.04)
        syl += bp(noise(sd), 1500, 5000) * env_exp(int(sd * SR), 0.015) * 0.2  # 'h'
        x = place(x, syl, i * 0.115)
    x = x * 0.8 + ring(x, 31 + 7 * kind) * 0.35
    return reverb(x, 1.6, 0.35, stereo=True)


def mannequin_move(k):
    synth.seed(420 + k)
    d = 0.7
    scrape = bp(noise(d), 300, 3000) * env_adsr(int(d * SR), 0.01, 0.1, 0.6, 0.2) * (0.6 + 0.4 * np.abs(lp(noise(d), 40) * 10))
    joint = creak(k + 3)[:int(d * SR)] * 0.5
    clack = bp(noise(0.05), 800, 5000) * env_exp(int(0.05 * SR), 0.01) * 1.2
    x = scrape + joint[:len(scrape)]
    x = place(x, clack, 0.0)
    x = place(x, clack * 0.7, d - 0.12)
    return reverb(x, 0.9, 0.25)


def mimic_reveal():
    synth.seed(430)
    d = 1.8
    crunch = silence(d)
    for i in range(14):
        crunch = place(crunch, bp(noise(0.04), 600, 6000) * env_exp(int(0.04 * SR), 0.01) * (0.5 + rng.random()), 0.02 + i * 0.03 + rng.random() * 0.02)
    wet = lp(noise(d), 700) * env_adsr(int(d * SR), 0.02, 0.2, 0.5, 0.8) * (np.abs(lp(noise(d), 20) * 10) > 0.4) * 1.2
    shriek = growl(431, 1.2, 130)
    x = crunch + wet + np.pad(shriek, (0, max(0, int(d * SR) - len(shriek))))[:int(d * SR)] * 0.7
    return reverb(x, 1.2, 0.3, stereo=True)


def meow(k):
    synth.seed(440 + k)
    d = 0.55 + 0.12 * k
    p = glide([(0, 480 + 40 * k), (0.35, 760 + 50 * k), (0.8, 620), (1, 430)], d)
    v = formant_voice(p, ['u', 'i', 'a', 'a', 'ow', 'u'], d, breath=0.06, q=(7, 10, 12), gains=(1, 0.8, 0.35))
    v = lp(hp(v, 250), 5000) * env_adsr(int(d * SR), 0.04, 0.1, 0.85, 0.2)
    return reverb(v, 0.35, 0.1)


def purr_loop():
    synth.seed(450)
    d = 4.0
    t = t_axis(d)
    rate = 25
    x = lp(noise(d), 300) * (0.5 + 0.5 * np.sin(2 * np.pi * rate * t)) ** 2
    x *= 0.6 + 0.4 * np.sin(2 * np.pi * 0.45 * t)  # breathing in/out
    return make_loop(np.pad(x, (0, int(0.5 * SR))), 0.5)


def soda():
    synth.seed(460)
    d = 1.6
    pop = bp(noise(0.06), 800, 6000) * env_exp(int(0.06 * SR), 0.01) * 1.5
    fizz = hp(noise(d), 4000) * env_exp(int(d * SR), 0.5) * 0.4 * (np.abs(noise(d)) > 1.6)
    gulp = silence(d)
    for i in range(3):
        gulp = place(gulp, lp(osc(glide([(0, 300), (1, 160)], 0.12), 0.12) * env_exp(int(0.12 * SR), 0.04), 900), 0.5 + i * 0.28)
    return place(fizz + gulp, pop, 0)


def glowstick():
    synth.seed(461)
    d = 0.8
    crack = bp(noise(0.04), 1500, 7000) * env_exp(int(0.04 * SR), 0.008) * 2
    shake = bp(noise(0.6), 2000, 7000) * (0.5 + 0.5 * np.sin(2 * np.pi * 12 * t_axis(0.6))) * 0.2
    x = place(silence(d), crack, 0)
    return place(x, shake, 0.15)


def windup():
    synth.seed(462)
    d = 3.0
    x = silence(d)
    for i in range(10):
        x = place(x, bp(noise(0.03), 2000, 7000) * env_exp(int(0.03 * SR), 0.006), i * 0.07)
    tune = [84, 88, 91, 88, 86, 84, 83, 79]
    for i, m in enumerate(tune):
        f = 440 * 2 ** ((m - 69) / 12)
        x = place(x, (osc(f, 0.3, 'square') * 0.15 + osc(f, 0.3) * 0.2) * env_exp(int(0.3 * SR), 0.1), 0.8 + i * 0.22)
    return reverb(x, 0.8, 0.2)


def chest(open_=True):
    synth.seed(470 + open_)
    d = 0.8
    hinge = creak(7)[:int(0.5 * SR)] * 0.5
    thump = lp(noise(0.3), 400) * env_exp(int(0.3 * SR), 0.05) * 2.5
    x = silence(d)
    if open_:
        x = place(x, hinge, 0)
        x = place(x, thump * 0.4, 0.45)
    else:
        x = place(x, hinge * 0.6, 0)
        x = place(x, thump, 0.3)
    return reverb(x, 0.6, 0.2)


def squeak():
    synth.seed(480)
    d = 0.4
    p = glide([(0, 900), (0.3, 1500), (1, 1100)], d)
    x = formant_voice(p, ['i', 'e'], d, breath=0.5) * env_adsr(int(d * SR), 0.01, 0.05, 0.8, 0.15)
    return reverb(x, 0.5, 0.15)


def ballpit():
    synth.seed(481)
    d = 1.2
    x = silence(d)
    for i in range(30):
        b = (bp(noise(0.03), 900, 4000) + osc(600 + rng.random() * 900, 0.03) * 0.3) * env_exp(int(0.03 * SR), 0.008)
        x = place(x, b * rng.random(), rng.random() * (d - 0.05))
    return reverb(x, 0.4, 0.15)


def elevator():
    synth.seed(490)
    d = 4.0
    ding = ui_chime([659.25, 523.25], 'sine', 0.35, 0.8)
    motor = lp(noise(d, 'brown'), 200) * env_adsr(int(d * SR), 0.5, 0.5, 0.8, 1.0) + osc(70, d) * 0.1
    x = motor * 0.8
    x = place(x, ding[:len(x)], 0.0)
    return x


def door_creak():
    synth.seed(491)
    x = creak(9)
    thump = lp(noise(0.3), 400) * env_exp(int(0.3 * SR), 0.05) * 2
    return place(np.pad(x, (0, int(0.3 * SR))), thump, len(x) / SR - 0.1)


def respawn():
    synth.seed(492)
    d = 2.0
    sw = bp(noise(d), 200, 5000) * np.linspace(1, 0, int(d * SR)) ** 2
    tone = osc(glide([(0, 880), (1, 220)], d), d) * env_exp(int(d * SR), 0.6) * 0.3
    return reverb(sw * 0.5 + tone, 2, 0.4, stereo=True)


def stalker_breath():
    synth.seed(493)
    d = 2.8
    x = silence(d)
    for at in (0.0, 1.4):
        x = place(x, growl(494, 1.1, 40) * 0.6, at)
    return x


def render_creeps():
    g = 'creeps'
    save(g, 'amb_playroom', playroom_loop(), loop=True)
    save(g, 'amb_vent', vent_loop(), loop=True)
    save(g, 'music_box', music_box_loop(), loop=True)
    save(g, 'music_chase', chase_loop(160, 55.0, 4, creepy_box=True), loop=True)
    save(g, 'amb_drone', drone_loop(46.2), loop=True)
    save(g, 'purr_loop', purr_loop(), loop=True)
    save(g, 'breath_loop', breath_loop(), loop=True)
    for s in ('foam', 'tile', 'carpet', 'wood'):
        for k in range(3):
            save(g, f'step_{s}_{k + 1}', step(s, k))
    for k in range(3):
        save(g, f'giggle_{k + 1}', giggle(k))
        save(g, f'mannequin_{k + 1}', mannequin_move(k))
        save(g, f'meow_{k + 1}', meow(k))
        save(g, f'stinger_{k + 1}', stinger(k))
        save(g, f'stalker_step_{k + 1}', creature_step(k + 5))
        save(g, f'whisper_{k + 1}', whisper(k + 4))
    save(g, 'stalker_growl', growl(500, 1.8, 48))
    save(g, 'stalker_roar', growl(501, 2.4, 44) + growl(502, 2.4, 66) * 0.5)
    save(g, 'stalker_breath', stalker_breath())
    save(g, 'scream', scream(1))
    save(g, 'scream_child', scream(2))
    save(g, 'mimic', mimic_reveal())
    save(g, 'heartbeat', heartbeat())
    save(g, 'pickup', pickup())
    save(g, 'click', click())
    save(g, 'soda', soda())
    save(g, 'glowstick', glowstick())
    save(g, 'windup', windup())
    save(g, 'chest_open', chest(True))
    save(g, 'chest_close', chest(False))
    save(g, 'squeak', squeak())
    save(g, 'ballpit', ballpit())
    save(g, 'elevator', elevator())
    save(g, 'door', door_creak())
    save(g, 'locked', locked())
    save(g, 'respawn', respawn())
    save(g, 'gasp', gasp())
    save(g, 'unlock', ui_chime([523.25, 659.25, 783.99, 1046.5], 'tri', 0.1, 0.5))
    save(g, 'level_done', ui_chime([392, 493.88, 587.33, 783.99], 'sine', 0.16, 0.7))
    save(g, 'token', ui_chime([880, 1318.5], 'sine', 0.08, 0.3))


# ═══════════════════════════ Night Owl Market ═══════════════════════════

def hum_loop():
    synth.seed(900)
    d = 8.0
    t = t_axis(d)
    x = sum(osc(60 * k, d) * a for k, a in [(1, 0.5), (2, 0.35), (3, 0.12), (4, 0.08)])
    x = x * (1 + 0.04 * np.sin(2 * np.pi * 0.3 * t)) + bp(noise(d, 'pink'), 2000, 7000) * 0.03
    x += peak(noise(d), 120, 4, 0.04)
    return make_loop(x, 1.0)


def street_loop():
    synth.seed(901)
    d = 12.0
    x = lp(noise(d, 'brown'), 300) * 0.6 + bp(noise(d, 'pink'), 300, 2000) * 0.06
    t = t_axis(d)
    # a distant car passing
    car = bp(noise(d), 200, 1200) * np.exp(-((t - 6.0) / 1.6) ** 2) * 0.5
    x += car
    return make_loop(x, 1.5)


def muzak_loop():
    """Cheerful but slightly off shop music: e-piano chords, walking bass, soft brush beat"""
    synth.seed(902)
    bpm = 96
    beat = 60 / bpm
    bars = 8
    d = beat * 4 * bars
    x = silence(d + 1)
    prog = [(261.63, [0, 4, 7, 11]), (220.0, [0, 3, 7, 10]), (174.61, [0, 4, 7, 11]), (196.0, [0, 4, 7, 10])]
    for bar in range(bars):
        root, iv = prog[bar % 4]
        t0 = bar * 4 * beat
        for hit in (0, 1.5, 2.5):
            chord = sum(osc(root * 2 ** (i / 12) * 1.003, beat * 1.4) * 0.5 + osc(root * 2 ** (i / 12) * 2, beat * 1.4) * 0.12 for i in iv)
            chord = lp(chord, 2400) * env_adsr(int(beat * 1.4 * SR), 0.005, 0.25, 0.3, 0.3) * 0.12
            x = place(x, chord, t0 + hit * beat)
        for b in range(4):
            f = root / 2 * 2 ** ([0, 7, 12, 7][b] / 12)
            note = lp(osc(f, beat, 'tri'), 500) * env_adsr(int(beat * SR), 0.005, 0.1, 0.6, 0.1) * 0.3
            x = place(x, note, t0 + b * beat)
            x = place(x, bp(noise(0.12), 3000, 9000) * env_exp(int(0.12 * SR), 0.04) * 0.05, t0 + b * beat + beat / 2)
        # a little melody, a touch flat (it's 3 a.m.)
        mel = [12, 14, 16, 19] if bar % 2 == 0 else [19, 16, 14, 11]
        for i, m in enumerate(mel):
            f = root * 2 ** ((m - 0.25) / 12)
            tone = (osc(f, beat * 0.9) + osc(f * 2, beat * 0.9) * 0.2) * env_exp(int(beat * 0.9 * SR), 0.25) * 0.08
            x = place(x, tone, t0 + i * beat)
    x = lp(x, 3500)  # through the ceiling speakers
    x = reverb(x, 0.9, 0.25, stereo=True)
    return make_loop(x[:int((d + 0.4) * SR)], 0.4)


def doorbell():
    synth.seed(903)
    out = silence(1.6)
    for at, f in ((0, 659.25), (0.35, 523.25)):
        tone = (osc(f, 1.2) + osc(f * 2.76, 1.2) * 0.25 + osc(f * 5.4, 1.2) * 0.08) * env_exp(int(1.2 * SR), 0.45)
        out = place(out, tone, at)
    return reverb(out, 0.8, 0.2)


def buzzer():
    d = 0.5
    x = lp(osc(110, d, 'square') + osc(116, d, 'square'), 1500) * env_adsr(int(d * SR), 0.005, 0.05, 0.9, 0.05)
    return x


def beep():
    d = 0.12
    return osc(2600, d, 'square') * env_adsr(int(d * SR), 0.002, 0.02, 0.8, 0.02) * 0.4 + osc(2600, d) * 0.3


def kaching():
    synth.seed(904)
    out = silence(1.2)
    drawer = lp(noise(0.25), 900) * env_exp(int(0.25 * SR), 0.06) * 1.2
    out = place(out, drawer, 0)
    bell = sum(osc(f, 1.0) * env_exp(int(1.0 * SR), 0.3) * a for f, a in [(2093, 0.5), (2637, 0.35), (4186, 0.15)])
    out = place(out, bell, 0.12)
    out = place(out, bp(noise(0.3), 3000, 9000) * env_exp(int(0.3 * SR), 0.06) * 0.4, 0.15)  # coins
    return reverb(out, 0.5, 0.15)


def grumble():
    synth.seed(905)
    v = formant_voice(glide([(0, 140), (0.5, 120), (1, 105)], 0.8), ['u', 'o', 'u'], 0.8, 0.2)
    return lp(v, 2500) * env_adsr(int(0.8 * SR), 0.05, 0.2, 0.7, 0.2)


def monster_turn():
    synth.seed(906)
    d = 2.2
    crack = sum(place(silence(d), bp(noise(0.05), 1000, 6000) * env_exp(int(0.05 * SR), 0.01), 0.05 + k * 0.09) for k in range(8))
    sc = formant_voice(glide([(0, 220), (0.3, 520), (1, 900)], d), ['a', 'aa', 'e', 'i'], d, 0.5)
    sc = distort(ring(sc, 47) * 1.5, 2.0) * env_adsr(int(d * SR), 0.2, 0.4, 0.8, 0.5)
    return reverb(sc * 0.8 + crack * 0.8 + growl(907, d, 50) [:int(d * SR)] * 0.5, 1.4, 0.3)


def swipe():
    synth.seed(908)
    d = 0.35
    return sweep_filter(noise(d), 600, 4000, 3) * env_adsr(int(d * SR), 0.03, 0.1, 0.4, 0.15) * 1.2


def smash():
    synth.seed(909)
    d = 0.9
    x = lp(noise(d), 400) * env_exp(int(d * SR), 0.08) * 1.5
    for k in range(10):
        x = place(x, bp(noise(0.08), 2000, 9000) * env_exp(int(0.08 * SR), 0.02) * 0.4, 0.05 + rng_u() * 0.5)
    return reverb(x, 0.6, 0.2)


def rng_u():
    return float(synth.rng.random())


def impact():
    synth.seed(910)
    d = 0.25
    return lp(noise(d), 1200) * env_exp(int(d * SR), 0.03) * 1.5 + osc(90, d) * env_exp(int(d * SR), 0.05)


def splat():
    synth.seed(911)
    d = 0.8
    x = lp(noise(d), 700) * env_exp(int(d * SR), 0.12) * 1.2 + lp(noise(d), 250) * env_exp(int(d * SR), 0.2)
    x = place(x, impact() * 0.8, 0.3)
    return reverb(x, 0.5, 0.15)


def gunshot(kind):
    synth.seed(920 + kind)
    d = {0: 0.9, 1: 1.2, 2: 0.25, 3: 1.4}[kind]
    n = int(d * SR)
    crack = bp(noise(d), 1500, 9000) * env_exp(n, [0.012, 0.02, 0.008, 0.01][kind]) * 1.4
    body = lp(noise(d), [900, 600, 1400, 700][kind]) * env_exp(n, [0.06, 0.12, 0.03, 0.09][kind]) * 1.6
    thump = osc(glide([(0, 160), (1, 45)], d), d) * env_exp(n, [0.05, 0.09, 0.025, 0.07][kind]) * [0.8, 1.2, 0.4, 1.0][kind]
    x = distort(crack + body + thump, 1.8)
    if kind == 1:  # pump after the shot
        x = place(x, bp(noise(0.08), 400, 3000) * env_exp(int(0.08 * SR), 0.02) * 0.4, 0.55)
        x = place(x, bp(noise(0.08), 600, 4000) * env_exp(int(0.08 * SR), 0.02) * 0.4, 0.72)
    return reverb(x, [0.8, 1.0, 0.4, 1.4][kind], 0.25)


def explosion():
    synth.seed(930)
    d = 2.8
    n = int(d * SR)
    x = lp(noise(d, 'brown'), 400) * env_exp(n, 0.7, 0.003) * 1.5
    x += lp(noise(d), 1500) * env_exp(n, 0.15) * 1.2
    x += osc(glide([(0, 80), (1, 25)], d), d) * env_exp(n, 0.4) * 1.0
    return reverb(distort(x, 2.2), 1.6, 0.3)


def fuse():
    synth.seed(931)
    d = 1.6
    x = bp(noise(d), 2500, 9000) * (0.5 + 0.5 * np.abs(lp(noise(d), 30) * 6)) * 0.5
    return x * env_adsr(int(d * SR), 0.02, 0.1, 0.9, 0.1)


def reload_sfx():
    synth.seed(932)
    out = silence(0.7)
    for at, lo, hi in ((0.0, 800, 5000), (0.25, 400, 3000), (0.45, 1200, 7000)):
        out = place(out, bp(noise(0.08), lo, hi) * env_exp(int(0.08 * SR), 0.015), at)
        out = place(out, osc(1800, 0.05) * env_exp(int(0.05 * SR), 0.01) * 0.2, at)
    return out


def box_sfx():
    synth.seed(933)
    d = 0.4
    return lp(noise(d), 600) * env_exp(int(d * SR), 0.05) * 1.3 + bp(noise(d), 1500, 4000) * env_exp(int(d * SR), 0.02) * 0.3


def stock_sfx():
    synth.seed(934)
    out = silence(0.6)
    for k in range(4):
        out = place(out, bp(noise(0.06), 500, 3500) * env_exp(int(0.06 * SR), 0.015) * (0.6 + 0.1 * k), k * 0.11)
    return out


def sizzle():
    synth.seed(935)
    d = 2.5
    x = hp(noise(d), 3000) * (0.5 + 0.5 * np.abs(lp(noise(d), 60) * 6)) * 0.5
    return x * env_adsr(int(d * SR), 0.05, 0.2, 0.8, 0.8)


def burnt():
    d = 0.6
    return lp(osc(glide([(0, 300), (1, 120)], d), d, 'saw'), 1200) * env_adsr(int(d * SR), 0.01, 0.1, 0.7, 0.2) * 0.6


def hurt():
    synth.seed(936)
    v = formant_voice(glide([(0, 180), (1, 140)], 0.35), ['aa', 'u'], 0.35, 0.3)
    out = v * env_adsr(int(0.35 * SR), 0.01, 0.1, 0.6, 0.15)
    return place(out, impact() * 0.5, 0)


def truck():
    synth.seed(937)
    d = 2.0
    x = lp(osc(42, d, 'saw') + noise(d) * 0.4, 300) * env_adsr(int(d * SR), 0.3, 0.3, 0.7, 0.8)
    x = place(x, door_slide(True)[:int(0.8 * SR)] * 0.6, 1.2)
    return reverb(x, 0.6, 0.2)


def danger_loop():
    return chase_loop(132, 49.0, 4, creepy_box=False)


def render_market():
    g = 'market'
    save(g, 'amb_hum', hum_loop(), loop=True)
    save(g, 'amb_street', street_loop(), loop=True)
    save(g, 'music_muzak', muzak_loop(), loop=True)
    save(g, 'music_danger', danger_loop(), loop=True)
    for k in range(3):
        save(g, f'step_tile_{k + 1}', step('tile', k))
        save(g, f'stinger_{k + 1}', stinger(k))
    save(g, 'doorbell', doorbell())
    save(g, 'door_slide', door_slide(False))
    save(g, 'buzzer', buzzer())
    save(g, 'beep', beep())
    save(g, 'kaching', kaching())
    save(g, 'grumble', grumble())
    save(g, 'monster_turn', monster_turn())
    save(g, 'scream', scream(1))
    save(g, 'swipe', swipe())
    save(g, 'smash', smash())
    save(g, 'impact', impact())
    save(g, 'splat', splat())
    for k, name in enumerate(['shot_pistol', 'shot_shotgun', 'shot_uzi', 'shot_rifle']):
        save(g, name, gunshot(k))
    save(g, 'explosion', explosion())
    save(g, 'fuse', fuse())
    save(g, 'reload', reload_sfx())
    save(g, 'box', box_sfx())
    save(g, 'stock', stock_sfx())
    save(g, 'sizzle', sizzle())
    save(g, 'perfect', ui_chime([1046.5, 1318.5, 1568], 'sine', 0.07, 0.35))
    save(g, 'burnt', burnt())
    save(g, 'hurt', hurt())
    save(g, 'truck', truck())
    save(g, 'click', click())
    save(g, 'unlock', ui_chime([523.25, 659.25, 783.99, 1046.5], 'tri', 0.1, 0.5))
    save(g, 'day_start', ui_chime([392, 523.25, 659.25], 'sine', 0.14, 0.6))
    save(g, 'day_end', ui_chime([659.25, 523.25, 392, 523.25], 'sine', 0.2, 0.8))


# ═══════════════════════════ Little Lantern ═══════════════════════════

def waltz_loop(minor=True, bpm=84, key=57):
    """A slow, slightly warped waltz on a music box over a soft bowed drone"""
    synth.seed(1000 + bpm)
    beat = 60 / bpm
    bars = 8
    d = beat * 3 * bars
    x = silence(d + 2.5)
    prog = [0, 5, 3, 7, 0, 8, 5, 7] if minor else [0, 5, 7, 0, 9, 5, 7, 0]
    tri = (lambda r: [r, r + 3, r + 7]) if minor else (lambda r: [r, r + 4, r + 7])
    mel = [12, 15, 14, 12, 10, 12, 7, 8, 10, 12, 15, 19, 17, 15, 14, 12, 11, 12, 14, 15, 12, 10, 7, 11]
    for bar in range(bars):
        root = key + prog[bar]
        t0 = bar * 3 * beat
        bass = osc(440 * 2 ** ((root - 12 - 69) / 12), beat * 1.5) * env_exp(int(beat * 1.5 * SR), 0.5) * 0.35
        x = place(x, bass, t0)
        for b in (1, 2):
            ch = sum(osc(440 * 2 ** ((n - 69) / 12), beat * 0.8) for n in tri(root))
            x = place(x, ch * env_exp(int(beat * 0.8 * SR), 0.2) * 0.07, t0 + b * beat)
        for i in range(3):
            m = key + mel[(bar * 3 + i) % len(mel)] + 12
            f = 440 * 2 ** ((m - 69) / 12) * (1 + 0.004 * np.sin(bar + i))  # a little out of tune
            tone = (osc(f, 1.4) + osc(f * 2, 1.4) * 0.25 + osc(f * 5.4, 1.4) * 0.05) * env_exp(int(1.4 * SR), 0.45) * 0.22
            x = place(x, tone, t0 + i * beat)
    x = x * (1 + 0.03 * np.sin(2 * np.pi * 0.5 * np.arange(len(x)) / SR))
    st = reverb(x, 2.4, 0.4, stereo=True)
    return make_loop(st[:int((d + 1.2) * SR)], 1.2)


def boss_loop():
    """Driving but strange: the chase drums under a low waltz-time ostinato"""
    synth.seed(1010)
    x = chase_loop(138, 46.25, 4, creepy_box=True)
    return x


def void_loop():
    synth.seed(1011)
    d = 14.0
    t = t_axis(d)
    x = sweep_filter(noise(d, 'pink'), 150, 600, q=2) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.07 * t))
    x += sum(osc(f, d) * a * (0.5 + 0.5 * np.sin(2 * np.pi * r * t)) for f, a, r in [(110, 0.03, 0.05), (164.8, 0.02, 0.08), (220.5, 0.012, 0.11)])
    st = reverb(x, 3.0, 0.5, stereo=True)
    return make_loop(st[:int((d + 1.5) * SR)], 1.5)


def hum_lantern():
    synth.seed(1012)
    d = 4.0
    t = t_axis(d)
    x = sum(osc(f, d) * a for f, a in [(220, 0.3), (330.5, 0.15), (441, 0.08)]) * (0.8 + 0.2 * np.sin(2 * np.pi * 3 * t))
    x += bp(noise(d), 2000, 6000) * 0.05
    return make_loop(x, 0.5)


def moths_loop():
    synth.seed(1013)
    d = 6.0
    x = bp(noise(d), 300, 1400) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 23 * t_axis(d)))) * 0.6
    x *= 0.7 + 0.3 * np.sin(2 * np.pi * 0.4 * t_axis(d))
    return make_loop(x, 0.6)


def heart_loop():
    x = silence(1.6)
    x = place(x, heartbeat(), 0)
    x = place(x, heartbeat(), 0.8)
    return x


def chime_up(notes, length=1.4):
    synth.seed(1014)
    x = silence(length + 1)
    for i, f in enumerate(notes):
        tone = (osc(f, 1.2) + osc(f * 2.01, 1.2) * 0.3) * env_exp(int(1.2 * SR), 0.5) * 0.4
        x = place(x, tone, i * length / len(notes))
    return reverb(x, 1.8, 0.4)


def soul_free():
    synth.seed(1015)
    x = chime_up([523.25, 659.25, 783.99, 1046.5, 1318.5], 1.0)
    # a soft child's sigh of relief
    v = formant_voice(glide([(0, 420), (1, 330)], 0.9), ['a', 'aa'], 0.9, 0.6) * env_adsr(int(0.9 * SR), 0.15, 0.2, 0.6, 0.4) * 0.25
    x = place(x, reverb(v, 1.2, 0.4), 0.5)
    return x


def snip():
    synth.seed(1016)
    x = silence(0.8)
    for at in (0, 0.12):
        x = place(x, bp(noise(0.06), 2500, 9000) * env_exp(int(0.06 * SR), 0.01) + osc(3200, 0.06) * env_exp(int(0.06 * SR), 0.015) * 0.3, at)
    twang = osc(glide([(0, 300), (1, 120)], 0.6), 0.6, 'saw') * env_exp(int(0.6 * SR), 0.2) * 0.4
    x = place(x, lp(twang, 2000), 0.13)
    return reverb(x, 1.0, 0.3)


def clink():
    x = sum(osc(f, 0.5) * env_exp(int(0.5 * SR), 0.12) * a for f, a in [(2400, 0.5), (3610, 0.3), (5200, 0.15)])
    return reverb(x, 0.8, 0.3)


def porcelain_smash():
    synth.seed(1017)
    x = silence(1.0)
    x = place(x, lp(noise(0.2), 900) * env_exp(int(0.2 * SR), 0.04), 0)
    for k in range(14):
        x = place(x, sum(osc(f * (1 + rng_u() * 0.4), 0.3) * env_exp(int(0.3 * SR), 0.05) for f in (2600, 3900)) * 0.15, rng_u() * 0.4)
    return reverb(x, 0.9, 0.3)


def whoosh(lo=400, hi=3000, d=0.45, seed=1018):
    synth.seed(seed)
    return sweep_filter(noise(d), lo, hi, 3) * env_adsr(int(d * SR), 0.1, 0.1, 0.6, 0.2)


def needles_sfx():
    synth.seed(1019)
    x = silence(0.8)
    for k in range(6):
        x = place(x, whoosh(2000, 7000, 0.25, 1019 + k) * 0.5, k * 0.04)
    return x


def rethread():
    synth.seed(1020)
    d = 2.0
    x = bp(noise(d), 1500, 5000) * (0.3 + 0.7 * np.abs(np.sin(2 * np.pi * 4 * t_axis(d)))) * 0.4
    hum = formant_voice(glide([(0, 260), (0.5, 300), (1, 250)], d), ['u', 'o', 'u'], d, 0.1) * 0.25
    return reverb(x + hum * env_adsr(int(d * SR), 0.2, 0.2, 0.8, 0.4), 1.4, 0.35)


def whip_sfx():
    synth.seed(1021)
    x = silence(0.6)
    x = place(x, whoosh(500, 4000, 0.18, 1021), 0)
    x = place(x, bp(noise(0.05), 2000, 9000) * env_exp(int(0.05 * SR), 0.008) * 1.5, 0.17)
    return reverb(x, 0.9, 0.3)


def poof():
    synth.seed(1022)
    d = 0.9
    x = lp(noise(d), 1500) * env_adsr(int(d * SR), 0.01, 0.15, 0.3, 0.4) * 0.8
    x += bp(noise(d), 300, 1400) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 25 * t_axis(d)))) * env_exp(int(d * SR), 0.4) * 0.6
    return reverb(x, 1.0, 0.35)


def hoop_sfx():
    synth.seed(1023)
    d = 1.2
    x = lp(noise(d), 800) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t_axis(d))) * env_adsr(int(d * SR), 0.05, 0.1, 0.8, 0.3)
    return x


def lash_sfx():
    synth.seed(1024)
    d = 1.6
    x = osc(glide([(0, 90), (1, 140)], d), d, 'saw') * 0.3 + bp(noise(d), 800, 4000) * 0.3
    x = lp(x, 2500) * env_adsr(int(d * SR), 0.3, 0.2, 0.7, 0.5)
    return reverb(x, 1.6, 0.35)


def witch_laugh():
    synth.seed(1025)
    n = 6
    x = silence(0.16 * n + 1.5)
    for i in range(n):
        sd = 0.13
        p = glide([(0, 340 - i * 18), (1, 300 - i * 18)], sd)
        syl = formant_voice(p, ['aa', 'a'], sd, breath=0.5) * env_adsr(int(sd * SR), 0.005, 0.04, 0.6, 0.05)
        x = place(x, syl, i * 0.16)
    x = x + ring(x, 23) * 0.3
    return reverb(x, 2.2, 0.45)


def witch_offer():
    """A low, warm, too-sweet voice: a long murmured phrase without words"""
    synth.seed(1026)
    d = 3.2
    v = formant_voice(glide([(0, 190), (0.3, 230), (0.6, 200), (1, 170)], d), ['o', 'u', 'a', 'e', 'o', 'u'], d, 0.35)
    v = v * env_adsr(int(d * SR), 0.2, 0.3, 0.8, 0.6) * 0.7
    pad = sum(osc(f, d) for f in (220, 261.6, 329.6)) * env_adsr(int(d * SR), 1.0, 0.5, 0.6, 1.0) * 0.06
    return reverb(v + pad, 2.6, 0.5)


def spindle_break():
    synth.seed(1027)
    x = silence(1.6)
    x = place(x, lp(noise(0.3), 1200) * env_exp(int(0.3 * SR), 0.06) * 1.2, 0)  # wood cracks
    x = place(x, snip()[:int(0.8 * SR)] * 0.6, 0.05)
    x = place(x, chime_up([659.25, 880, 1318.5], 0.5)[:int(1.4 * SR)] * 0.6, 0.2)
    return x


def boss_down():
    synth.seed(1028)
    d = 3.0
    g = growl(1029, 2.4, 70)
    x = silence(d + 1.5)
    x = place(x, g[:int(2.4 * SR)] * 0.6, 0)
    x = place(x, lp(noise(0.6), 400) * env_exp(int(0.6 * SR), 0.2), 1.6)
    return reverb(x, 2.0, 0.35)


def drain():
    synth.seed(1030)
    d = 0.7
    x = osc(glide([(0, 900), (1, 200)], d), d, 'tri') * env_adsr(int(d * SR), 0.01, 0.1, 0.6, 0.2) * 0.4
    return x + poof()[:int(d * SR)] * 0.3


def unravel():
    synth.seed(1031)
    d = 2.2
    x = bp(noise(d), 1200, 5000) * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * glide([(0, 14), (1, 3)], d).cumsum() / SR))) * env_adsr(int(d * SR), 0.05, 0.3, 0.6, 0.8) * 0.6
    x += osc(glide([(0, 600), (1, 90)], d), d) * env_exp(int(d * SR), 0.9) * 0.3
    return reverb(x, 1.8, 0.4)


def flare_sfx():
    synth.seed(1032)
    d = 1.4
    x = whoosh(300, 6000, 0.5, 1032)
    x = np.concatenate([x, silence(d - 0.5)])
    bell = sum(osc(f, d) * env_exp(int(d * SR), 0.5) * a for f, a in [(880, 0.3), (1318.5, 0.2), (1760, 0.1)])
    return reverb(x + bell, 1.6, 0.35)


def gate_sfx():
    synth.seed(1033)
    d = 2.0
    x = sweep_filter(noise(d, 'pink'), 200, 3000, 4) * env_adsr(int(d * SR), 0.3, 0.3, 0.6, 0.8) * 0.6
    x += sum(osc(glide([(0, f), (1, f * 2)], d), d) * 0.08 for f in (220, 330, 440)) * env_adsr(int(d * SR), 0.4, 0.3, 0.6, 0.8)
    return reverb(x, 2.2, 0.4)


def girl_voice(kind):
    synth.seed(1034 + kind)
    if kind == 0:  # hurt
        d = 0.3
        return formant_voice(glide([(0, 480), (1, 380)], d), ['aa', 'u'], d, 0.4) * env_adsr(int(d * SR), 0.01, 0.08, 0.6, 0.12)
    if kind == 1:  # jump
        d = 0.2
        return formant_voice(glide([(0, 420), (1, 470)], d), ['u'], d, 1.5) * env_adsr(int(d * SR), 0.01, 0.05, 0.4, 0.1) * 0.5
    d = 0.9  # falling
    return formant_voice(glide([(0, 520), (1, 300)], d), ['a', 'aa', 'o'], d, 0.4) * env_adsr(int(d * SR), 0.02, 0.2, 0.7, 0.4)


def render_lantern():
    g = 'lantern'
    save(g, 'amb_void', void_loop(), loop=True)
    save(g, 'music_waltz', waltz_loop(), loop=True)
    save(g, 'music_boss', boss_loop(), loop=True)
    save(g, 'lantern_hum', hum_lantern(), loop=True)
    save(g, 'moths_loop', moths_loop(), loop=True)
    save(g, 'heartbeat_loop', heart_loop(), loop=True)
    for s, surf in (('grass', 'carpet'), ('wood', 'wood'), ('porcelain', 'tile')):
        for k in range(3):
            save(g, f'step_{s}_{k + 1}', step(surf, k + 3) * 0.8)
    for k in range(3):
        save(g, f'stinger_{k + 1}', stinger(k))
    save(g, 'beam_on', whoosh(800, 4000, 0.35, 1040) * 0.6)
    save(g, 'boss_down', boss_down())
    save(g, 'click', click())
    save(g, 'clink', clink())
    save(g, 'drain', drain())
    save(g, 'fall', girl_voice(2))
    save(g, 'flare', flare_sfx())
    save(g, 'gate', gate_sfx())
    save(g, 'hoop', hoop_sfx())
    save(g, 'hurt', girl_voice(0))
    save(g, 'jump', girl_voice(1))
    save(g, 'land', step('carpet', 9) * 1.2)
    save(g, 'lash', lash_sfx())
    save(g, 'minion_die', poof())
    save(g, 'mote', ui_chime([1318.5, 1760], 'sine', 0.06, 0.3))
    save(g, 'needles', needles_sfx())
    save(g, 'needle_land', clink())
    save(g, 'poof', poof())
    save(g, 'refuse', chime_up([392, 523.25, 783.99], 0.6))
    save(g, 'rethread', rethread())
    save(g, 'shield_down', chime_up([329.6, 415.3, 493.9, 659.3], 0.8))
    save(g, 'snip', snip())
    save(g, 'soul_free', soul_free())
    save(g, 'spindle_break', spindle_break())
    save(g, 'unravel', unravel())
    save(g, 'victory', chime_up([392, 493.9, 587.3, 783.99, 987.8], 1.6))
    save(g, 'whip', whip_sfx())
    save(g, 'witch_laugh', witch_laugh())
    save(g, 'witch_offer', witch_offer())
    save(g, 'teacup', porcelain_smash())
    save(g, 'shears', snip())
    save(g, 'thorn', step('wood', 7) * 1.5)
    save(g, 'ending_dawn', chime_up([523.25, 659.25, 783.99, 987.8, 1046.5, 1318.5], 3.0))
    save(g, 'ending_thread', chime_up([440, 523.25, 659.25, 587.3, 523.25], 3.0))
    save(g, 'ending_spindle', stinger(2))


if __name__ == '__main__':
    which = sys.argv[1:] or ['vertigo', 'creeps', 'market', 'lantern']
    if 'vertigo' in which:
        render_vertigo()
    if 'creeps' in which:
        render_creeps()
    if 'market' in which:
        render_market()
    if 'lantern' in which:
        render_lantern()
    for g, names in written.items():
        if names:
            with open(os.path.join(OUT[g], 'index.js'), 'w') as f:
                f.write('// List of the sound files in this folder (made by tools/sfx/render.py)\nexport default ' + json.dumps(sorted(names), indent=0) + '\n')
            print(g, len(names), 'files ->', OUT[g])
