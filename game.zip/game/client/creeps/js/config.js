// Creeps: shared settings

/** Co-op relay on the same Render server as the Minecraft world (path /creeps) */
export const COOP_SERVER = 'wss://gl-tahx.onrender.com/creeps'

export const coopServerUrl = () => {
  const { hostname, protocol, host } = window.location
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    const port = new URLSearchParams(location.search).get('relayPort') || '8080'
    return `${protocol === 'https:' ? 'wss' : 'ws'}://${hostname}:${port}/creeps`
  }
  if (hostname.endsWith('.onrender.com')) return `wss://${host}/creeps`
  return COOP_SERVER
}

export const WALK = 2.6
export const SPRINT = 4.7
export const CROUCH = 1.3
export const RADIUS = 0.28
export const EYE = 1.6
export const CROUCH_EYE = 0.95
export const STAMINA_DRAIN = 13 // per second while sprinting (of 100)
export const STAMINA_REGEN = 17
export const RESPAWN_SECONDS = 3.5
export const CAT_UNLOCK_FLOOR = 5

export const DEFAULT_SETTINGS = { sensitivity: 1, volume: 0.8, quality: 'auto', invertY: false, cat: true }

export const isTouchDevice = () => (navigator.maxTouchPoints > 0 && matchMedia('(pointer: coarse)').matches) || /Android|iPhone|iPad/i.test(navigator.userAgent)
