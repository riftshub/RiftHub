// Creeps: the 16 room templates the floors are generated from (+ the elevator lobby).
// Every room is a 12 x 12 m cell. Doorways sit in the middle of each wall, so templates keep
// a walkable cross (|x| < 1.3 or |z| < 1.3) clear of furniture.
import { M } from './textures.js'

export const ROOM = 12
export const HALF = ROOM / 2
export const WALL_H = 3.2

const BALL_COLORS = [0xd94141, 0x3d78c9, 0xe8c23a, 0x4fae5c, 0xe07ab0, 0xf08a35]

/**
 * Each template: { id, name, floor, wall, build(R) }.
 * R is the room-builder API (local coordinates, room centre = 0,0):
 *   R.box(w,h,d,mat,x,y,z,{ry,solid,cover})  R.cyl(rt,rb,h,mat,x,y,z,{solid})  R.ball(r,mat,x,y,z)
 *   R.hide(type,x,z,facingYaw,label)  R.spot(x,y,z)  R.light(x,z,{broken,color})
 *   R.mannequin(x,z,yaw)  R.poster(k,x,y,z,ry)  R.rng()  R.balls(minX,maxX,minZ,maxZ,n)  R.spin(group,speed)
 */
export const TEMPLATES = [
  {
    id: 'ballpit', name: 'Ball Pit', floor: 'foam', wall: 'wallBlue',
    build (R) {
      // netted pit in one quadrant, a slide into it
      const [x0, x1, z0, z1] = [1.8, 5.4, -5.4, -1.8]
      R.box(x1 - x0, 0.55, 0.15, M.padPink(), (x0 + x1) / 2, 0, z1)
      R.box(0.15, 0.55, z1 - z0, M.padPink(), x0, 0, (z0 + z1) / 2)
      for (const [x, z] of [[x0, z0], [x0, z1], [x1, z1]]) R.cyl(0.06, 0.06, 2.4, M.plastic(0xe8c23a), x, 0, z, { solid: true })
      R.box(x1 - x0, 0.03, 0.03, M.plastic(0xe8c23a), (x0 + x1) / 2, 2.4, z1, { solid: false })
      R.balls(x0 + 0.2, x1 - 0.1, z0 + 0.1, z1 - 0.2, 420)
      R.hide('ballpit', (x0 + x1) / 2, (z0 + z1) / 2, Math.PI * 0.75, 'Burrow into the balls')
      R.solid(x0, x1, z0, z1)
      // slide tower in the opposite corner
      R.box(1.6, 1.4, 1.6, M.plastic(0x3d78c9), -4.3, 0, 4.3)
      R.box(0.8, 0.08, 3.2, M.plastic(0xe07ab0), -4.3, 0.7, 2.2, { rx: -0.42, solid: false })
      R.box(1.6, 1.8, 0.08, M.plastic(0xe8c23a), -4.3, 1.4, 5.1, { solid: false })
      R.spot(-4.3, 1.45, 4.3); R.spot(4.5, 0.02, 4.5); R.spot(-4.5, 0.02, -4.5)
      R.light(-3, -3); R.light(3, 3, { broken: true })
      R.mannequin(4.6, 3.4, -2.4)
      R.poster(3, -5.95, 1.6, -3, Math.PI / 2)
    },
  },
  {
    id: 'nap', name: 'Nap Room', floor: 'carpet', wall: 'wallPink',
    build (R) {
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (let k = 0; k < 2; k++) {
        const x = sx * (2.6 + k * 1.6), z = sz * 3.6
        R.box(1.2, 0.3, 2.0, M.fabric(k ? 0x8aa6c9 : 0xd9a0b4), x, 0, z)
        R.box(0.5, 0.12, 0.35, M.fabric(0xf0ebe0), x, 0.3, z + sz * 0.7, { solid: false })
      }
      // cubbies along the back wall: two you can climb into
      for (let k = 0; k < 4; k++) {
        const x = -5.1 + k * 0.7
        if (Math.abs(x) < 1.4) continue
      }
      R.hide('cubby', -4.9, -0.0 + 2.2, Math.PI / 2, 'Squeeze into the cubby')
      R.hide('cubby', 4.9, -2.2, -Math.PI / 2, 'Squeeze into the cubby')
      R.spot(-2.6, 0.32, 3.6); R.spot(4.2, 0.32, -3.6); R.spot(2.6, 0.32, 3.6)
      R.light(0, -3, { color: 0xffd9e6 }); R.light(0, 3, { broken: true })
      R.mannequin(-4.2, -4.8, 0.6); R.mannequin(4.4, 4.9, 3.6)
      R.poster(2, 3, 1.7, 5.95, Math.PI)
    },
  },
  {
    id: 'arcade', name: 'Arcade', floor: 'linoDark', wall: 'wallMint',
    build (R) {
      for (const sx of [-1, 1]) for (let k = 0; k < 3; k++) {
        const x = sx * 5.4, z = -4.6 + k * 1.3 + (k > 1 ? 4.6 : 0)
        R.cabinet(x, z, sx > 0 ? -Math.PI / 2 : Math.PI / 2)
      }
      R.cabinet(-2.6, 5.4, Math.PI); R.cabinet(2.6, 5.4, Math.PI); R.cabinet(-2.6, -5.4, 0); R.cabinet(3.6, -5.4, 0)
      // prize counter with plushies
      R.box(2.4, 1.0, 0.7, M.plastic(0xd94141), -3.6, 0, -2.6)
      for (let k = 0; k < 6; k++) R.ball(0.14, M.fabric(BALL_COLORS[k]), -4.6 + k * 0.4, 1.14, -2.6)
      R.hide('counter', -3.6, -3.25, 0, 'Duck behind the prize counter')
      R.spot(-3.0, 1.02, -2.6); R.spot(3.5, 0.02, 3.5); R.spot(-4.6, 0.02, 4.0)
      R.light(0, 0, { color: 0xc8f0ff }); R.light(-3.6, -3, { broken: true, color: 0xff9ed2 })
      R.mannequin(3.6, -3.2, -1)
    },
  },
  {
    id: 'party', name: 'Party Room', floor: 'lino', wall: 'wallYellow',
    build (R) {
      for (const sz of [-1, 1]) {
        R.box(4.2, 0.72, 1.1, M.plastic(0xf2ead6), sz * 3.5, 0, sz * 3.3)
        for (let k = 0; k < 5; k++) for (const dz of [-0.85, 0.85]) R.box(0.4, 0.42, 0.4, M.plastic(BALL_COLORS[k]), sz * 3.5 - 1.7 + k * 0.85, 0, sz * 3.3 + dz, { solid: false })
        // balloons tied to the chairs
        for (let k = 0; k < 4; k++) R.balloon(sz * 3.5 - 1.5 + k, 2.2 + (k % 2) * 0.3, sz * 3.3 + 1.1, BALL_COLORS[(k + 2) % 6])
      }
      // the cake, candles still in
      R.cyl(0.35, 0.35, 0.3, M.plastic(0xf3d1dc), 3.5, 0.72, 3.3, { solid: false })
      for (let k = 0; k < 5; k++) R.cyl(0.015, 0.015, 0.12, M.plastic(0x3d78c9), 3.3 + k * 0.1, 1.02, 3.3, { solid: false })
      R.hide('table', -3.5, -3.3, 0, 'Crawl under the table')
      R.spot(3.5, 0.74, 3.3); R.spot(-3.5, 0.74, -3.3); R.spot(-4.8, 0.02, 4.8)
      R.light(-3.5, -3.3); R.light(3.5, 3.3, { color: 0xffe4b0 })
      R.mannequin(-4.9, 2.2, 1.6); R.mannequin(4.9, -2.4, -1.6)
      R.poster(0, -3, 1.7, -5.95, 0)
    },
  },
  {
    id: 'crawl', name: 'Crawl Maze', floor: 'foam', wall: 'padTeal',
    build (R) {
      // padded partitions make pockets in each quadrant
      const pad = [M.padTeal(), M.padPink()]
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        const m = pad[(sx + sz + 2) / 2 % 2 | 0]
        R.box(3.2, 1.9, 0.3, m, sx * 3.6, 0, sz * 2.0)
        R.box(0.3, 1.9, 2.4, m, sx * 2.1, 0, sz * 3.9)
        R.box(0.3, 1.9, 1.6, m, sx * 4.8, 0, sz * 4.5)
      }
      R.tube(3.6, 4.6, 0, 'Crawl into the tunnel')
      R.tube(-3.6, -4.6, Math.PI, 'Crawl into the tunnel')
      R.spot(3.4, 0.02, 3.2); R.spot(-3.4, 0.02, -3.2); R.spot(-4.4, 0.02, 3.4)
      R.light(-3.6, 3.6, { broken: true }); R.light(3.6, -3.6)
      R.mannequin(-3.2, 4.8, 3)
    },
  },
  {
    id: 'tower', name: 'Climbing Frame', floor: 'foam', wall: 'wallBlue',
    build (R) {
      // big frame in two quadrants: posts, decks, netting
      for (const [cx, cz] of [[-3.6, -3.6], [3.6, 3.6]]) {
        for (const [dx, dz] of [[-1.5, -1.5], [1.5, -1.5], [-1.5, 1.5], [1.5, 1.5]]) R.cyl(0.09, 0.09, 2.6, M.plastic(0xd94141), cx + dx, 0, cz + dz, { solid: true })
        R.box(3.2, 0.12, 3.2, M.plastic(0x3d78c9), cx, 1.3, cz, { solid: false })
        R.box(3.2, 0.12, 3.2, M.plastic(0xe8c23a), cx, 2.5, cz, { solid: false })
        R.net(cx, cz)
      }
      R.hide('frame', -3.6, -3.6, Math.PI / 4, 'Hide under the deck')
      R.spot(-3.6, 1.43, -3.6); R.spot(3.6, 1.43, 3.6); R.spot(4.5, 0.02, -4.5)
      R.light(-3.6, 3.6); R.light(3.6, -3.6, { broken: true })
      R.mannequin(4.5, -3.8, -0.4)
      R.poster(1, 5.95, 1.6, -3.4, -Math.PI / 2)
    },
  },
  {
    id: 'craft', name: 'Craft Room', floor: 'lino', wall: 'wallYellow',
    build (R) {
      for (const [x, z] of [[-3.4, -3.4], [3.4, -3.4], [-3.4, 3.4], [3.4, 3.4]]) {
        R.box(2.2, 0.55, 1.2, M.wood(), x, 0, z)
        for (const dx of [-0.7, 0, 0.7]) for (const dz of [-0.85, 0.85]) R.box(0.3, 0.3, 0.3, M.plastic(BALL_COLORS[(dx * 10 + dz * 7 + 30 | 0) % 6]), x + dx, 0, z + dz, { solid: false })
        for (let k = 0; k < 4; k++) R.box(0.03, 0.01, 0.12, M.plastic(BALL_COLORS[k]), x - 0.4 + k * 0.25, 0.56, z, { ry: k, solid: false })
      }
      // easels with drawings
      for (const [x, z, ry] of [[-5.3, 0 + 2.6, Math.PI / 2], [5.3, -2.6, -Math.PI / 2]]) {
        R.box(0.08, 1.6, 0.08, M.wood(), x, 0, z, { ry })
        R.poster(2, x + (x < 0 ? 0.06 : -0.06), 1.3, z, ry)
      }
      R.hide('cupboard', -5.3, -4.8, Math.PI / 2, 'Hide in the supply cupboard')
      R.spot(-3.4, 0.57, -3.4); R.spot(3.4, 0.57, 3.4); R.spot(3.4, 0.57, -3.4)
      R.light(-3.4, 0); R.light(3.4, 0, { broken: true })
      R.mannequin(0 + 4.8, 4.9, 3.6)
      R.poster(3, 0 + 3, 1.7, 5.95, Math.PI); R.poster(0, -3, 1.7, -5.95, 0)
    },
  },
  {
    id: 'storage', name: 'Toy Storage', floor: 'linoDark', wall: 'wallMint',
    build (R) {
      for (const sx of [-1, 1]) for (let k = 0; k < 2; k++) {
        const x = sx * (2.6 + k * 2.2)
        for (const sz of [-1, 1]) R.shelf(x, sz * 3.7, 2.6)
      }
      R.hide('chest', -1.8, 4.9, Math.PI, 'Climb into the toy chest')
      R.hide('chest', 1.8, -4.9, 0, 'Climb into the toy chest')
      R.spot(-2.6, 1.05, 3.7); R.spot(4.8, 1.55, -3.7); R.spot(2.6, 0.55, 3.7)
      R.light(-2.6, 0, { broken: true }); R.light(2.6, 0)
      R.mannequin(-4.8, 1.8, Math.PI / 2); R.mannequin(4.8, 1.8, -Math.PI / 2)
    },
  },
  {
    id: 'restroom', name: 'Restrooms', floor: 'lino', wall: 'wallBlue',
    build (R) {
      // stalls along one side
      for (let k = 0; k < 3; k++) {
        const z = -4.8 + k * 1.3
        R.box(1.25, 1.9, 0.06, M.plastic(0x7aa3b8), 4.65, 0.15, z - 0.62)
        R.cyl(0.18, 0.22, 0.42, M.plastic(0xf2f2ee), 5.6, 0, z, { solid: true })
        if (k !== 1) R.hide('stall', 5.0, z, -Math.PI / 2, 'Lock yourself in the stall')
      }
      R.box(1.25, 1.9, 0.06, M.plastic(0x7aa3b8), 4.65, 0.15, -4.8 + 3 * 1.3 - 0.62)
      // little sinks + mirror on the other wall
      for (let k = 0; k < 3; k++) R.box(0.5, 0.65, 0.45, M.plastic(0xf2f2ee), -5.5, 0, 2.6 + k * 0.9)
      R.box(0.04, 0.9, 2.8, M.glass(), -5.93, 1.1, 3.5, { solid: false })
      R.spot(-5.5, 0.67, 2.6); R.spot(4.6, 0.02, 4.4); R.spot(-4.5, 0.02, -4.5)
      R.light(-3, 3); R.light(3, -3, { broken: true, color: 0xd6ffe8 })
      R.mannequin(-4.6, -3.8, 0.8)
      R.poster(1, -2.5, 1.7, -5.95, 0)
    },
  },
  {
    id: 'kitchen', name: 'Snack Bar', floor: 'lino', wall: 'wallYellow',
    build (R) {
      R.box(0.7, 0.95, 4.2, M.metal(), -5.25, 0, -3.4)
      R.box(0.7, 0.95, 4.2, M.metal(), 5.25, 0, 3.4)
      R.box(0.8, 1.9, 0.8, M.plastic(0xe9e6dc), -5.2, 0, 3.0) // fridge
      R.box(2.6, 1.05, 0.7, M.plastic(0xd94141), 3.2, 0, -3.0) // serving counter
      for (let k = 0; k < 3; k++) R.cyl(0.22, 0.04, 0.75, M.plastic(0xe8c23a), 2.4 + k * 0.8, 0, -2.1, { solid: false })
      R.hide('cupboard', -5.25, 4.6, Math.PI / 2, 'Hide in the pantry')
      R.spot(-5.25, 0.97, -3.0); R.spot(5.25, 0.97, 3.8); R.spot(3.2, 1.07, -3.0)
      R.light(-3, -3, { color: 0xfff1cc }); R.light(3, 3)
      R.mannequin(3.6, 4.8, Math.PI)
      R.poster(3, 3, 1.7, -5.95, 0)
    },
  },
  {
    id: 'stage', name: 'Puppet Theatre', floor: 'carpet', wall: 'wallPink',
    build (R) {
      // stage across the back-left, curtains
      R.box(4.6, 0.6, 2.6, M.wood(), -3.4, 0, -4.4)
      R.box(4.6, 2.6, 0.08, M.fabric(0x7a1d2e), -3.4, 0.6, -5.6, { solid: false })
      for (const x of [-5.6, -1.2]) R.box(0.6, 2.4, 0.15, M.fabric(0x9a2238), x, 0.6, -3.15, { solid: false })
      R.box(4.6, 0.4, 0.15, M.fabric(0x9a2238), -3.4, 2.75, -3.15, { solid: false })
      // the "performers": a row of puppets slumped on the stage
      for (let k = 0; k < 3; k++) R.puppet(-4.8 + k * 1.3, 0.6, -4.6, BALL_COLORS[k + 1])
      for (let row = 0; row < 3; row++) for (let k = 0; k < 4; k++) R.box(0.42, 0.4, 0.4, M.plastic(BALL_COLORS[(k + row) % 6]), 2.2 + k * 0.9, 0, 2.2 + row * 1.2, { solid: false })
      R.hide('curtain', -3.4, -5.2, 0, 'Hide behind the curtain')
      R.spot(-3.4, 0.62, -4.0); R.spot(4.8, 0.02, -4.6); R.spot(3.4, 0.42, 4.6)
      R.light(-3.4, -4.2, { color: 0xffc0a0 }); R.light(3.4, 3.4, { broken: true })
      R.mannequin(-2.0, -4.6, 0.2)
    },
  },
  {
    id: 'carousel', name: 'Carousel', floor: 'carpet', wall: 'wallMint',
    build (R) {
      R.carousel(0, 0)
      for (const [x, z] of [[-4.6, -4.6], [4.6, 4.6]]) R.box(1.6, 0.45, 0.5, M.plastic(0x3d78c9), x, 0, z)
      R.hide('booth', 4.8, -4.6, -Math.PI * 0.75, 'Hide in the ticket booth')
      R.spot(-4.6, 0.47, -4.6); R.spot(0, 0.32, 2.4); R.spot(4.6, 0.47, 4.6)
      R.light(-3, 3); R.light(3, -3, { broken: true })
      R.mannequin(-4.6, 4.5, Math.PI * 0.75)
      R.poster(0, 5.95, 1.7, 2.5, -Math.PI / 2)
    },
  },
  {
    id: 'shop', name: 'Gift Shop', floor: 'lino', wall: 'wallPink',
    build (R) {
      for (const [x, z] of [[-3.4, -3.2], [3.4, -3.2], [-3.4, 3.4]]) R.rack(x, z)
      R.box(2.4, 1.0, 0.7, M.wood(), 3.6, 0, 3.6) // till counter
      R.box(0.4, 0.3, 0.3, M.dark(), 3.2, 1.0, 3.6)
      R.hide('bin', 4.9, -0.0 + 4.9, Math.PI * 0.75, 'Dive into the plush bin')
      R.spot(-3.4, 1.25, -3.2); R.spot(3.6, 1.02, 3.6); R.spot(3.4, 1.25, -3.2)
      R.light(-3, 0, { color: 0xfff0e0 }); R.light(3, 0, { broken: true })
      R.mannequin(-4.9, -0.0 - 4.9, 0.8); R.mannequin(-4.8, 4.9, 2.4)
    },
  },
  {
    id: 'office', name: 'Staff Office', floor: 'linoDark', wall: 'wallBlue',
    build (R) {
      for (const [x, z, ry] of [[-3.8, -3.6, 0], [3.8, -3.6, 0], [-3.8, 3.4, Math.PI]]) {
        R.box(1.8, 0.75, 0.9, M.wood(), x, 0, z, { ry })
        R.box(0.6, 0.45, 0.06, M.dark(), x, 0.75, z - 0.2, { ry, solid: false })
        R.screen(x, 1.0, z - 0.17, ry)
        R.box(0.5, 0.45, 0.5, M.dark(), x, 0, z + (ry ? -0.8 : 0.8), { solid: false })
      }
      // CCTV wall
      for (let k = 0; k < 3; k++) R.screen(5.92, 1.6 + (k % 2) * 0.45, 2.6 + k * 0.7, -Math.PI / 2, true)
      R.hide('locker', 5.4, 4.9, -Math.PI / 2, 'Hide in the staff locker')
      R.hide('locker', -5.4, 0 - 2.0, Math.PI / 2, 'Hide in the staff locker')
      R.spot(-3.8, 0.77, -3.6); R.spot(3.8, 0.77, -3.6); R.spot(-3.8, 0.77, 3.4)
      R.light(0, -3.6, { color: 0xe8f4ff }); R.light(0, 3.6, { broken: true })
      R.mannequin(3.6, 3.2, Math.PI)
    },
  },
  {
    id: 'hall', name: 'Hallway', floor: 'carpet', wall: 'wallYellow',
    build (R) {
      for (const [x, z] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) R.box(0.7, WALL_H, 0.7, M.padTeal(), x, 0, z)
      R.box(1.6, 0.45, 0.5, M.plastic(0xd94141), -4.6, 0, 1.8)
      R.box(0.9, 1.9, 0.75, M.plastic(0x3d78c9), 5.2, 0, -4.6) // vending machine
      R.screen(5.0, 1.3, -4.6, -Math.PI / 2, true)
      R.hide('locker', -5.4, -4.6, Math.PI / 2, 'Hide in the coat locker')
      R.spot(-4.6, 0.47, 1.8); R.spot(4.6, 0.02, 4.6); R.spot(-4.8, 0.02, -2.6)
      R.light(-3, 0); R.light(3, 0, { broken: true }); R.light(0, 4.5)
      R.mannequin(4.6, 2.2, -Math.PI / 2)
      R.poster(1, 5.95, 1.6, 2.5, -Math.PI / 2); R.poster(3, -5.95, 1.6, -2.5, Math.PI / 2)
    },
  },
  {
    id: 'blocks', name: 'Block Room', floor: 'foam', wall: 'padPink',
    build (R) {
      const letters = 'PLAYWITHUS'
      let i = 0
      for (const [x, z, s] of [[-4.2, -4.4, 1.2], [-2.6, -4.6, 0.9], [-4.6, -2.6, 1.0], [4.0, 4.2, 1.3], [2.6, 4.7, 0.9], [4.6, 2.6, 0.8], [3.8, -4.4, 1.1], [-4.0, 4.0, 1.0], [-2.7, 4.8, 0.7]]) {
        R.letterBlock(x, z, s, letters[i % letters.length], BALL_COLORS[i % 6])
        i++
      }
      R.hide('block', -4.2, -3.4, 0, 'Hide behind the big block')
      R.spot(4.0, 1.32, 4.2); R.spot(-4.6, 1.02, -2.6); R.spot(4.8, 0.02, -2.4)
      R.light(-3, -3, { broken: true }); R.light(3, 3)
      R.mannequin(2.4, -4.6, -0.3)
    },
  },
]

/** Start / exit room: an old service elevator in one wall */
export const LOBBY = {
  id: 'lobby', name: 'Lobby', floor: 'carpet', wall: 'wallMint',
  build (R, { exit }) {
    R.box(1.6, 0.45, 0.5, M.plastic(0x3d78c9), -4.4, 0, 4.6)
    R.box(1.6, 0.45, 0.5, M.plastic(0x3d78c9), 4.4, 0, 4.6)
    R.spot(-4.4, 0.47, 4.6)
    R.light(0, 0, { color: exit ? 0xd6ffe0 : 0xfff1d8 })
    R.light(0, 4)
    R.poster(exit ? 3 : 0, 3, 1.7, 5.95, Math.PI)
  },
}

export const BALL_PALETTE = BALL_COLORS
