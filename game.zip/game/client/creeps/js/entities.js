// Creeps: the things that live in the play centre. Models + host-side AI.
//   Peeker    peeks round door frames. Shine your light on it and it hides; ignore it and it lunges.
//   Mannequin moves only while nobody is looking at it.
//   Mimic     pretends to be a play token. Get close and it unfolds.
//   Stalker   a huge, worn costume that hunts by sound and sight. Hide from it.
import * as THREE from 'three'
import { ROOM, HALF } from './rooms.js'
import { DOOR_W } from './level.js'

const std = (color, rough = 0.6, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness: rough, ...extra })
const part = (geo, mat, parent, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m }
const joint = (parent, x, y, z) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); return g }

// ═════════════ models ═════════════

export function peekerModel () {
  const root = new THREE.Group()
  const skin = std(0xeee3cf, 0.45)
  const black = std(0x050505, 0.3)
  const body = joint(root, 0, 0, 0)
  part(new THREE.CapsuleGeometry(0.16, 1.3, 4, 10), std(0x2a2430, 0.8), body, 0, 1.05, 0)
  const neck = joint(body, 0, 1.75, 0)
  part(new THREE.CylinderGeometry(0.04, 0.05, 0.4, 8), skin, neck, 0, 0.2, 0)
  const head = joint(neck, 0, 0.5, 0)
  const skull = part(new THREE.SphereGeometry(0.34, 24, 18), skin, head, 0, 0, 0)
  skull.scale.set(1, 0.92, 0.88)
  // painted party-mask face: hollow eyes, a smile far too wide
  for (const sx of [-0.12, 0.12]) {
    const eye = part(new THREE.SphereGeometry(0.075, 12, 10), black, head, sx, 0.06, 0.27)
    eye.scale.set(1, 1.35, 0.5)
  }
  const smile = part(new THREE.TorusGeometry(0.2, 0.028, 8, 28, Math.PI * 0.9), std(0x9a1020, 0.4), head, 0, -0.04, 0.26)
  smile.rotation.z = Math.PI + Math.PI * 0.05
  for (let k = 0; k < 9; k++) {
    const a = Math.PI + 0.2 + k * 0.32
    part(new THREE.ConeGeometry(0.013, 0.05, 5), std(0xf4f0e6, 0.3), head, Math.cos(a) * 0.19, -0.04 + Math.sin(a) * 0.19 + 0.02, 0.3).rotation.z = Math.PI
  }
  const blush = std(0xe07ab0, 0.8)
  for (const sx of [-0.2, 0.2]) part(new THREE.CircleGeometry(0.05, 12), blush, head, sx, -0.06, 0.29)
  const hat = part(new THREE.ConeGeometry(0.13, 0.38, 14), std(0x3d78c9, 0.5), head, 0.08, 0.38, 0)
  hat.rotation.z = -0.3
  part(new THREE.SphereGeometry(0.05, 8, 6), std(0xe8c23a), head, 0.17, 0.56, 0)
  // long arm with long fingers, wrapping the door frame
  const arm = joint(body, 0.2, 1.65, 0)
  part(new THREE.CapsuleGeometry(0.035, 0.7, 4, 6), skin, arm, 0, -0.35, 0)
  const hand = joint(arm, 0, -0.75, 0)
  const fingers = []
  for (let k = 0; k < 4; k++) {
    const f = joint(hand, -0.03 + k * 0.02, 0, 0)
    part(new THREE.CapsuleGeometry(0.012, 0.22, 3, 5), skin, f, 0, -0.11, 0)
    f.rotation.x = 0.4
    fingers.push(f)
  }
  root.traverse(o => { if (o.isMesh) o.castShadow = true })
  return {
    root, head, arm,
    animate (dt, st) {
      const t = performance.now() / 1000
      if (st.state === 'peek') {
        body.rotation.z = 0.55 // leaning round the frame
        body.position.y = -0.35
        head.rotation.z = -0.5 + Math.sin(t * 2.2) * 0.12
        arm.rotation.set(-1.4, 0, -0.6)
      } else if (st.state === 'lunge') {
        body.rotation.z = 0
        body.rotation.x = 0.5
        body.position.y = 0
        head.rotation.z = Math.sin(t * 40) * 0.2
        arm.rotation.set(-1.6, 0, 0)
      } else {
        body.rotation.set(0, 0, 0); body.position.y = 0; head.rotation.z = 0; arm.rotation.set(0, 0, 0)
      }
      fingers.forEach((f, k) => { f.rotation.x = 0.5 + Math.sin(t * 6 + k) * 0.25 })
    },
  }
}

export function mannequinModel (seed = 0) {
  const root = new THREE.Group()
  const plastic = std(0xd8c9b2, 0.35)
  const jointMat = std(0xbfae96, 0.4)
  const hips = joint(root, 0, 0.98, 0)
  part(new THREE.CapsuleGeometry(0.15, 0.12, 4, 10), plastic, hips, 0, 0, 0).scale.set(1.1, 1, 0.75)
  const spine = joint(hips, 0, 0.1, 0)
  part(new THREE.CapsuleGeometry(0.16, 0.38, 4, 12), plastic, spine, 0, 0.3, 0).scale.set(1.12, 1, 0.68)
  const neck = joint(spine, 0, 0.62, 0)
  part(new THREE.CylinderGeometry(0.045, 0.05, 0.1, 8), jointMat, neck, 0, 0.04, 0)
  const head = joint(neck, 0, 0.12, 0)
  part(new THREE.SphereGeometry(0.115, 18, 14), plastic, head, 0, 0.08, 0).scale.set(0.85, 1.12, 0.95)
  // a party crown drawn on in marker, slightly crooked
  if (seed % 2) { const crown = part(new THREE.CylinderGeometry(0.1, 0.1, 0.06, 8, 1, true), std(0xe8c23a, 0.5, { side: THREE.DoubleSide }), head, 0, 0.2, 0); crown.rotation.z = 0.2 }
  const limbs = []
  for (const side of [-1, 1]) {
    const sh = joint(spine, side * 0.22, 0.55, 0)
    part(new THREE.SphereGeometry(0.05, 8, 6), jointMat, sh)
    part(new THREE.CapsuleGeometry(0.045, 0.24, 4, 8), plastic, sh, 0, -0.16, 0)
    const el = joint(sh, 0, -0.32, 0)
    part(new THREE.SphereGeometry(0.04, 8, 6), jointMat, el)
    part(new THREE.CapsuleGeometry(0.04, 0.22, 4, 8), plastic, el, 0, -0.15, 0)
    part(new THREE.SphereGeometry(0.045, 8, 6), plastic, el, 0, -0.32, 0).scale.set(0.7, 1.2, 0.5)
    const hip = joint(hips, side * 0.09, -0.03, 0)
    part(new THREE.CapsuleGeometry(0.06, 0.32, 4, 8), plastic, hip, 0, -0.21, 0)
    const kn = joint(hip, 0, -0.44, 0)
    part(new THREE.SphereGeometry(0.05, 8, 6), jointMat, kn)
    part(new THREE.CapsuleGeometry(0.05, 0.32, 4, 8), plastic, kn, 0, -0.22, 0)
    limbs.push({ sh, el, hip, kn, side })
  }
  // the stand it was supposed to be bolted to
  part(new THREE.CylinderGeometry(0.2, 0.22, 0.03, 18), std(0x333336, 0.4, { metalness: 0.6 }), root, 0, 0.015, 0)
  let poseSeed = seed
  const pose = () => {
    const r = n => { poseSeed = (poseSeed * 9301 + 49297) % 233280; return (poseSeed / 233280 - 0.5) * n }
    for (const l of limbs) {
      l.sh.rotation.set(r(2.4) - 0.3, 0, l.side * (0.1 + Math.abs(r(1.2))))
      l.el.rotation.set(-Math.abs(r(2)), 0, 0)
      l.hip.rotation.set(r(0.8), 0, 0)
      l.kn.rotation.set(Math.abs(r(0.8)), 0, 0)
    }
    head.rotation.set(r(0.8), r(1.6), r(0.9))
    spine.rotation.set(r(0.4), r(0.6), r(0.3))
  }
  pose()
  return { root, head, newPose: pose, animate () {} }
}

export function mimicModel () {
  const root = new THREE.Group()
  const fur = std(0x3a2a4a, 0.95)
  const body = part(new THREE.SphereGeometry(0.35, 16, 12), fur, root, 0, 0.45, 0)
  body.scale.set(1.15, 0.8, 1)
  // a mouth that splits the whole front open
  const mouth = part(new THREE.SphereGeometry(0.3, 16, 10, 0, Math.PI * 2, Math.PI * 0.35, Math.PI * 0.3), std(0x5a0a14, 0.6, { side: THREE.DoubleSide }), root, 0, 0.45, 0.12)
  mouth.rotation.x = Math.PI / 2
  for (let k = 0; k < 14; k++) {
    const a = (k / 14) * Math.PI * 2
    const tooth = part(new THREE.ConeGeometry(0.02, 0.09, 5), std(0xf4f0e6, 0.3), root, Math.cos(a) * 0.2, 0.45 + Math.sin(a) * 0.12, 0.3)
    tooth.rotation.z = a + Math.PI / 2
  }
  // little toy eyes, mismatched
  part(new THREE.SphereGeometry(0.06, 10, 8), std(0xffffff, 0.2), root, -0.18, 0.7, 0.2)
  part(new THREE.SphereGeometry(0.03, 8, 6), std(0x000000), root, -0.18, 0.7, 0.26)
  part(new THREE.SphereGeometry(0.09, 10, 8), std(0xffffff, 0.2), root, 0.16, 0.72, 0.18)
  part(new THREE.SphereGeometry(0.035, 8, 6), std(0x000000), root, 0.17, 0.72, 0.26)
  const legs = []
  for (let k = 0; k < 6; k++) {
    const side = k < 3 ? -1 : 1
    const leg = joint(root, side * 0.3, 0.45, -0.2 + (k % 3) * 0.2)
    part(new THREE.CapsuleGeometry(0.03, 0.45, 3, 6), fur, leg, side * 0.22, 0.1, 0).rotation.z = side * -1.1
    part(new THREE.CapsuleGeometry(0.025, 0.45, 3, 6), fur, leg, side * 0.48, -0.15, 0).rotation.z = side * 0.4
    legs.push(leg)
  }
  // the disguise: a play token
  const token = tokenMesh()
  token.position.y = 0.0
  root.add(token)
  return {
    root, token, mouth,
    animate (dt, st) {
      const disguised = st.state === 'disguised'
      token.visible = disguised
      body.visible = mouth.visible = !disguised
      for (const c of root.children) if (c !== token) c.visible = !disguised
      if (disguised) { token.rotation.y -= dt * 1.4; token.position.y = 0.15 + Math.sin(performance.now() / 600) * 0.03; return }
      const t = performance.now() / 1000
      legs.forEach((l, k) => { l.rotation.x = Math.sin(t * 18 + k) * (st.state === 'scuttle' ? 0.5 : 0.15) })
      mouth.scale.y = st.state === 'reveal' ? 1 + Math.sin(t * 30) * 0.2 : 1
    },
  }
}

export function stalkerModel () {
  const root = new THREE.Group()
  const fur = std(0x7a5a3a, 0.98)
  const furDark = std(0x4f3a26, 0.98)
  const patch = std(0x6a7aa0, 0.95)
  const hips = joint(root, 0, 1.3, 0)
  part(new THREE.SphereGeometry(0.5, 16, 12), fur, hips, 0, 0, 0).scale.set(1.1, 0.9, 0.85)
  const spine = joint(hips, 0, 0.2, 0)
  const belly = part(new THREE.SphereGeometry(0.58, 18, 14), fur, spine, 0, 0.45, 0.05)
  belly.scale.set(1, 1.15, 0.9)
  part(new THREE.CircleGeometry(0.3, 18), std(0xc9b08a, 1), spine, 0, 0.4, 0.57)
  part(new THREE.PlaneGeometry(0.22, 0.18), patch, spine, 0.28, 0.65, 0.5).rotation.y = 0.4
  const neck = joint(spine, 0, 1.0, 0.1)
  const head = joint(neck, 0, 0.25, 0.05)
  const skull = part(new THREE.SphereGeometry(0.42, 20, 16), fur, head, 0, 0.1, 0)
  skull.scale.set(1.05, 0.95, 0.95)
  for (const sx of [-0.33, 0.33]) {
    part(new THREE.SphereGeometry(0.15, 12, 10), fur, head, sx, 0.45, -0.05).scale.set(1, 1, 0.5)
    part(new THREE.CircleGeometry(0.08, 12), std(0xc9b08a), head, sx, 0.45, 0.03)
  }
  // muzzle with the stitches torn: a real mouth inside
  const muzzle = part(new THREE.SphereGeometry(0.2, 14, 10), std(0xc9b08a, 1), head, 0, -0.02, 0.33)
  muzzle.scale.set(1.2, 0.85, 0.9)
  const jaw = joint(head, 0, -0.08, 0.3)
  part(new THREE.BoxGeometry(0.3, 0.06, 0.2), std(0x3a0a0e, 0.6), jaw, 0, -0.04, 0.05)
  for (let k = 0; k < 7; k++) part(new THREE.ConeGeometry(0.018, 0.07, 5), std(0xefe6d2, 0.3), jaw, -0.12 + k * 0.04, 0.01, 0.14)
  for (let k = 0; k < 7; k++) part(new THREE.ConeGeometry(0.018, 0.07, 5), std(0xefe6d2, 0.3), head, -0.12 + k * 0.04, -0.06, 0.45).rotation.x = Math.PI
  part(new THREE.SphereGeometry(0.05, 10, 8), std(0x111111, 0.2), head, 0, 0.06, 0.52) // nose
  // one button eye, one empty socket with something glinting inside
  const button = part(new THREE.CylinderGeometry(0.08, 0.08, 0.03, 16), std(0x1a1a1a, 0.3), head, -0.17, 0.2, 0.36)
  button.rotation.x = Math.PI / 2
  part(new THREE.SphereGeometry(0.075, 10, 8), std(0x050505, 1), head, 0.17, 0.2, 0.34)
  const glint = part(new THREE.SphereGeometry(0.022, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff2a1a }), head, 0.17, 0.2, 0.39)
  // long arms, oversized paws with claws pushed through the felt
  const arms = []
  for (const side of [-1, 1]) {
    const sh = joint(spine, side * 0.55, 0.8, 0)
    part(new THREE.CapsuleGeometry(0.15, 0.6, 4, 10), fur, sh, 0, -0.4, 0)
    const el = joint(sh, 0, -0.85, 0)
    part(new THREE.CapsuleGeometry(0.13, 0.6, 4, 10), furDark, el, 0, -0.38, 0)
    const paw = part(new THREE.SphereGeometry(0.18, 12, 10), fur, el, 0, -0.8, 0.02)
    paw.scale.set(1, 1.1, 0.8)
    for (let k = 0; k < 4; k++) part(new THREE.ConeGeometry(0.02, 0.14, 5), std(0x1d1d1d, 0.4), el, -0.08 + k * 0.055, -0.98, 0.08).rotation.x = Math.PI * 0.85
    arms.push({ sh, el })
  }
  const legs = []
  for (const side of [-1, 1]) {
    const hip = joint(hips, side * 0.28, -0.2, 0)
    part(new THREE.CapsuleGeometry(0.18, 0.45, 4, 10), fur, hip, 0, -0.35, 0)
    const kn = joint(hip, 0, -0.65, 0)
    part(new THREE.CapsuleGeometry(0.16, 0.3, 4, 10), furDark, kn, 0, -0.2, 0)
    part(new THREE.SphereGeometry(0.2, 12, 10), fur, kn, 0, -0.45, 0.1).scale.set(1, 0.6, 1.3)
    legs.push({ hip, kn })
  }
  root.traverse(o => { if (o.isMesh && o !== glint) o.castShadow = true })
  let phase = 0
  return {
    root, head, jaw, glint,
    animate (dt, st) {
      const speed = st.speed ?? 0
      const running = speed > 2.8
      phase += dt * (speed > 0.1 ? (running ? 7.5 : 4.5) : 0)
      const s = Math.sin(phase)
      const amp = speed > 0.1 ? (running ? 0.75 : 0.45) : 0
      legs.forEach((l, i) => { const ph = i ? -s : s; l.hip.rotation.x = -ph * amp; l.kn.rotation.x = Math.max(0, i ? Math.cos(phase) : -Math.cos(phase)) * amp })
      arms.forEach((a, i) => {
        const ph = i ? s : -s
        a.sh.rotation.x = running ? -1.2 + ph * 0.3 : ph * amp * 0.6
        a.el.rotation.x = running ? -0.4 : -0.15
        a.sh.rotation.z = (i ? -1 : 1) * 0.12
      })
      spine.rotation.x = running ? 0.35 : 0.12 + Math.sin(performance.now() / 1400) * 0.03
      head.rotation.z = Math.sin(performance.now() / 900) * 0.15 + (st.state === 'search' ? Math.sin(performance.now() / 200) * 0.2 : 0)
      jaw.rotation.x = st.state === 'chase' || st.state === 'lunge' ? 0.5 + Math.sin(performance.now() / 90) * 0.1 : 0.15
      hips.position.y = 1.3 + (speed > 0.1 ? Math.abs(Math.cos(phase)) * 0.06 : 0)
      glint.visible = st.alert > 0.4
    },
  }
}

export function tokenMesh () {
  const g = new THREE.Group()
  const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.03, 24), std(0xe8b923, 0.25, { metalness: 0.8, emissive: 0x6a4a00, emissiveIntensity: 0.6 }))
  coin.rotation.x = Math.PI / 2
  const star = new THREE.Mesh(starGeometry(0.075, 0.034, 0.02), std(0xfff1b0, 0.3, { emissive: 0x806020, emissiveIntensity: 0.5 }))
  star.position.z = 0.016
  const star2 = star.clone()
  star2.position.z = -0.016
  star2.rotation.y = Math.PI
  g.add(coin, star, star2)
  return g
}

function starGeometry (r, r2, depth) {
  const s = new THREE.Shape()
  for (let i = 0; i < 10; i++) {
    const a = Math.PI / 2 + i * Math.PI / 5
    const rr = i % 2 ? r2 : r
    if (i === 0) s.moveTo(Math.cos(a) * rr, Math.sin(a) * rr)
    else s.lineTo(Math.cos(a) * rr, Math.sin(a) * rr)
  }
  s.closePath()
  return new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: false }).translate(0, 0, -depth / 2)
}

export function catModel (color = 0x2b2b2b) {
  const root = new THREE.Group()
  const fur = std(color, 0.95)
  const body = part(new THREE.CapsuleGeometry(0.09, 0.22, 4, 10), fur, root, 0, 0.17, 0)
  body.rotation.x = Math.PI / 2
  const head = joint(root, 0, 0.26, 0.17)
  part(new THREE.SphereGeometry(0.075, 12, 10), fur, head)
  for (const sx of [-0.045, 0.045]) {
    part(new THREE.ConeGeometry(0.028, 0.06, 4), fur, head, sx, 0.07, -0.01)
    part(new THREE.SphereGeometry(0.012, 8, 6), new THREE.MeshBasicMaterial({ color: 0xc8e86a }), head, sx * 0.8, 0.015, 0.065)
  }
  const tail = joint(root, 0, 0.2, -0.17)
  part(new THREE.CapsuleGeometry(0.018, 0.22, 3, 6), fur, tail, 0, 0.11, -0.02).rotation.x = -0.4
  const legs = []
  for (const [x, z] of [[-0.05, 0.1], [0.05, 0.1], [-0.05, -0.1], [0.05, -0.1]]) {
    const l = joint(root, x, 0.12, z)
    part(new THREE.CapsuleGeometry(0.018, 0.09, 3, 6), fur, l, 0, -0.06, 0)
    legs.push(l)
  }
  let phase = 0
  return {
    root, head,
    animate (dt, { speed = 0, alert = 0 }) {
      phase += dt * speed * 9
      legs.forEach((l, k) => { l.rotation.x = Math.sin(phase + (k % 2 ? Math.PI : 0) + (k > 1 ? Math.PI / 2 : 0)) * Math.min(0.7, speed * 0.4) })
      tail.rotation.z = Math.sin(performance.now() / 300) * (alert ? 0.1 : 0.4)
      tail.rotation.x = alert ? -0.9 : -0.2
      root.scale.y = alert ? 1.12 : 1 // hackles up
    },
  }
}

// ═════════════ AI (host only) ═════════════

/** 2D segment vs. wall boxes: is there a clear line between a and b? */
export function lineOfSight (F, ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az
  for (const c of F.colliders) {
    if (!c.wall) continue
    // slab test
    let t0 = 0, t1 = 1
    for (const [p, d, lo, hi] of [[ax, dx, c.minX, c.maxX], [az, dz, c.minZ, c.maxZ]]) {
      if (Math.abs(d) < 1e-9) { if (p < lo || p > hi) { t0 = 2; break } continue }
      let ta = (lo - p) / d, tb = (hi - p) / d
      if (ta > tb) [ta, tb] = [tb, ta]
      t0 = Math.max(t0, ta); t1 = Math.min(t1, tb)
      if (t0 > t1) break
    }
    if (t0 <= t1 && t0 < 1 && t1 > 0) return false
  }
  return true
}

/** Path through the room graph: list of points (door midpoints, then the target) */
export function pathTo (F, from, to) {
  if (!to) return []
  const a = F.cellAt(from.x, from.z), b = F.cellAt(to.x, to.z)
  if (!a || !b || a === b) return [to]
  const prev = new Map([[a, null]])
  const q = [a]
  while (q.length) {
    const c = q.shift()
    if (c === b) break
    for (const o of c.links) if (!prev.has(o)) { prev.set(o, c); q.push(o) }
  }
  if (!prev.has(b)) return [to]
  const chain = []
  for (let c = b; c; c = prev.get(c)) chain.unshift(c)
  const pts = []
  for (let k = 0; k < chain.length - 1; k++) {
    const c = chain[k], n = chain[k + 1]
    const mx = (c.i + n.i) / 2 * ROOM, mz = (c.j + n.j) / 2 * ROOM
    // approach the doorway straight on so it doesn't clip the frame
    pts.push({ x: mx - (n.i - c.i) * 0.9, z: mz - (n.j - c.j) * 0.9 }, { x: mx + (n.i - c.i) * 0.9, z: mz + (n.j - c.j) * 0.9 })
  }
  pts.push(to)
  return pts
}

/**
 * hooks: { kill(playerId, type), fx(kind, data), isHidden(spotId) -> {playerId, holdingBreath, seen} , glowAt(x,z) -> bool, roomLit(cell) -> 0..1 }
 */
export class Entities {
  constructor (F, hooks, params) {
    this.F = F
    this.hooks = hooks
    this.params = params
    this.list = []
    const rng = F.rng
    // mannequins: frozen where they were placed
    for (const m of F.mannequins) this.list.push({ id: m.id, type: 'mannequin', x: m.x, z: m.z, yaw: m.yaw, state: 'still', visible: true, speed: 0, alert: 0, path: [], soundAt: 0, poseTick: 0 })
    for (const m of F.mimics) this.list.push({ id: m.id, type: 'mimic', x: m.x, z: m.z, y: m.y, yaw: 0, state: 'disguised', visible: true, speed: 0, timer: 0, alert: 0 })
    for (let k = 0; k < params.peekers; k++) this.list.push({ id: `p${k}`, type: 'peeker', x: 0, z: 0, yaw: 0, state: 'lurk', visible: false, timer: 8 + k * 9 + rng() * 10, lit: 0, speed: 0, alert: 0 })
    if (params.stalker) {
      const far = F.layout.exit.center
      this.list.push({ id: 's0', type: 'stalker', x: far.x, z: far.z, yaw: 0, state: 'patrol', visible: true, speed: 0, alert: 0, path: [], timer: 0, sight: new Map(), target: null })
    }
    this.cooldown = 0
  }

  snapshot () {
    return this.list.map(e => [e.id, +e.x.toFixed(2), +e.z.toFixed(2), +e.yaw.toFixed(2), e.state, e.visible ? 1 : 0, +(e.speed ?? 0).toFixed(2), +(e.alert ?? 0).toFixed(2), +(e.y ?? 0).toFixed(2), e.type])
  }

  /** a noise the stalker (and mimics) can hear */
  hear (x, z, radius) {
    for (const e of this.list) {
      if (e.type !== 'stalker' || e.state === 'chase' || e.state === 'retreat') continue
      const walls = lineOfSight(this.F, e.x, e.z, x, z) ? 1 : 0.55
      if (Math.hypot(x - e.x, z - e.z) < radius * walls) {
        e.state = 'investigate'
        e.target = { x, z }
        e.path = pathTo(this.F, e, e.target)
        e.timer = 0
      }
    }
  }

  moveAlong (e, speed, dt) {
    if (!e.path.length) { e.speed = 0; return true }
    const p = e.path[0]
    const dx = p.x - e.x, dz = p.z - e.z
    const d = Math.hypot(dx, dz)
    const step = speed * dt
    if (d <= step) { e.x = p.x; e.z = p.z; e.path.shift() } else { e.x += dx / d * step; e.z += dz / d * step }
    if (d > 0.01) {
      let dy = Math.atan2(dx, dz) - e.yaw
      while (dy > Math.PI) dy -= Math.PI * 2
      while (dy < -Math.PI) dy += Math.PI * 2
      e.yaw += dy * Math.min(1, dt * 8)
    }
    e.speed = speed
    return !e.path.length
  }

  /** players: [{ id, x, z, yaw, pitch, crouch, flashlight, hidden, hiddenSeen, holdingBreath, dead }] */
  update (dt, players, now) {
    const alive = players.filter(p => !p.dead && !p.hidden)
    for (const e of this.list) {
      if (e.type === 'mannequin') this.mannequin(e, dt, players, alive, now)
      else if (e.type === 'peeker') this.peeker(e, dt, alive, now)
      else if (e.type === 'mimic') this.mimic(e, dt, alive, now)
      else if (e.type === 'stalker') this.stalker(e, dt, players, alive, now)
    }
  }

  seenBy (e, p, halfFov = 0.95, range = 32) {
    const dx = e.x - p.x, dz = e.z - p.z
    const d = Math.hypot(dx, dz)
    if (d > range) return false
    if (d < 0.6) return true
    const fx = -Math.sin(p.yaw), fz = -Math.cos(p.yaw)
    const ang = Math.acos(Math.max(-1, Math.min(1, (dx * fx + dz * fz) / d)))
    if (ang > halfFov) return false
    return lineOfSight(this.F, p.x, p.z, e.x, e.z)
  }

  mannequin (e, dt, players, alive, now) {
    const watched = players.some(p => !p.dead && !p.hidden && this.seenBy(e, p))
    let nearest = null
    for (const p of alive) { const d = Math.hypot(p.x - e.x, p.z - e.z); if (d < 20 && (!nearest || d < nearest.d)) nearest = { p, d } }
    if (watched || !nearest) {
      if (e.state === 'moving') { e.state = 'still'; e.poseTick++ }
      e.speed = 0
      return
    }
    e.state = 'moving'
    if (!e.path.length || now - (e.repath ?? 0) > 700) { e.path = pathTo(this.F, e, nearest.p); e.repath = now }
    this.moveAlong(e, 3.1, dt)
    e.yaw = Math.atan2(nearest.p.x - e.x, nearest.p.z - e.z)
    if (now - e.soundAt > 650) { e.soundAt = now; this.hooks.fx('scrape', { x: e.x, z: e.z }) }
    if (Math.hypot(nearest.p.x - e.x, nearest.p.z - e.z) < 0.85) { this.hooks.kill(nearest.p.id, 'mannequin', e.id); this.knockBack(e, nearest.p) }
  }

  peeker (e, dt, alive, now) {
    if (e.state === 'lurk') {
      e.visible = false
      e.timer -= dt
      if (e.timer > 0 || !alive.length) return
      // find a doorway near a player, in view but not too close
      const p = alive[Math.floor(Math.random() * alive.length)]
      const opts = this.F.doorways.filter(d => {
        const dist = Math.hypot(d.x - p.x, d.z - p.z)
        return dist > 5 && dist < 14 && lineOfSight(this.F, p.x, p.z, d.x, d.z) && !this.hooks.glowAt(d.x, d.z, 6)
      })
      if (!opts.length) { e.timer = 3; return }
      const d = opts[Math.floor(Math.random() * opts.length)]
      // stand just round the frame, on the far side from the player
      const side = Math.random() < 0.5 ? -1 : 1
      const across = d.axis === 'x' ? Math.sign(d.x - p.x) || 1 : Math.sign(d.z - p.z) || 1
      if (d.axis === 'x') { e.x = d.x + across * 0.45; e.z = d.z + side * (DOOR_W / 2 + 0.25) } else { e.x = d.x + side * (DOOR_W / 2 + 0.25); e.z = d.z + across * 0.45 }
      e.yaw = Math.atan2(p.x - e.x, p.z - e.z)
      e.state = 'peek'
      e.visible = true
      e.timer = 5.5 + Math.random() * 2.5
      e.lit = 0
      e.targetId = p.id
      this.hooks.fx('giggle', { x: e.x, z: e.z })
      return
    }
    if (e.state === 'peek') {
      const p = alive.find(q => q.id === e.targetId) ?? alive[0]
      if (!p) { e.state = 'lurk'; e.timer = 10; return }
      e.yaw = Math.atan2(p.x - e.x, p.z - e.z)
      // shining a flashlight on it drives it off
      for (const q of alive) {
        if (!q.flashlight) continue
        const dx = e.x - q.x, dz = e.z - q.z
        const d = Math.hypot(dx, dz)
        const fx = -Math.sin(q.yaw), fz = -Math.cos(q.yaw)
        if (d < 16 && Math.acos(Math.max(-1, Math.min(1, (dx * fx + dz * fz) / d))) < 0.3 && lineOfSight(this.F, q.x, q.z, e.x, e.z)) e.lit += dt
      }
      if (e.lit > 1.0) { this.hooks.fx('peekerFlee', { x: e.x, z: e.z }); e.state = 'lurk'; e.visible = false; e.timer = 22 + Math.random() * 20; return }
      e.timer -= dt
      const dist = Math.hypot(p.x - e.x, p.z - e.z)
      if (e.timer <= 0 || dist < 3.2) { e.state = 'lunge'; e.timer = 2.2; this.hooks.fx('peekerLunge', { x: e.x, z: e.z }) }
      return
    }
    if (e.state === 'lunge') {
      const p = alive.find(q => q.id === e.targetId) ?? alive[0]
      e.timer -= dt
      if (!p || e.timer <= 0) { e.state = 'lurk'; e.visible = false; e.timer = 20; return }
      e.path = [{ x: p.x, z: p.z }]
      this.moveAlong(e, 7.5, dt)
      if (Math.hypot(p.x - e.x, p.z - e.z) < 0.9) { this.hooks.kill(p.id, 'peeker', e.id); e.state = 'lurk'; e.visible = false; e.timer = 25 }
    }
  }

  mimic (e, dt, alive, now) {
    if (e.state === 'gone') {
      e.visible = false
      e.timer -= dt
      if (e.timer <= 0) {
        // re-disguise somewhere new, out of sight of everyone
        const cells = this.F.layout.cells.filter(c => c !== this.F.layout.start)
        const c = cells[Math.floor(Math.random() * cells.length)]
        const x = c.center.x + (Math.random() - 0.5) * 6, z = c.center.z + (Math.random() - 0.5) * 6
        if (this.F.free(x, z, 0.4) && !alive.some(p => Math.hypot(p.x - x, p.z - z) < 14)) { Object.assign(e, { x, z, y: 0, state: 'disguised', visible: true }) } else e.timer = 2
      }
      return
    }
    let nearest = null
    for (const p of alive) { const d = Math.hypot(p.x - e.x, p.z - e.z); if (!nearest || d < nearest.d) nearest = { p, d } }
    if (e.state === 'disguised') {
      e.alert = 0
      if (nearest && nearest.d < 1.5) { e.state = 'reveal'; e.timer = 0.75; e.targetId = nearest.p.id; this.hooks.fx('mimic', { x: e.x, z: e.z }) }
      return
    }
    const p = alive.find(q => q.id === e.targetId) ?? nearest?.p
    if (e.state === 'reveal') {
      e.alert = 1
      e.y = 0
      if (p) e.yaw = Math.atan2(p.x - e.x, p.z - e.z)
      e.timer -= dt
      if (e.timer <= 0) {
        if (p && Math.hypot(p.x - e.x, p.z - e.z) < 2.0) { this.hooks.kill(p.id, 'mimic', e.id); e.state = 'gone'; e.timer = 25 }
        else { e.state = 'scuttle'; e.timer = 5 }
      }
      return
    }
    if (e.state === 'scuttle') {
      e.timer -= dt
      if (!p || e.timer <= 0) { e.state = 'gone'; e.timer = 20; this.hooks.fx('mimicGone', { x: e.x, z: e.z }); return }
      if (!e.path.length || now - (e.repath ?? 0) > 500) { e.path = pathTo(this.F, e, p); e.repath = now }
      this.moveAlong(e, 3.6, dt)
      if (Math.hypot(p.x - e.x, p.z - e.z) < 0.8) { this.hooks.kill(p.id, 'mimic', e.id); e.state = 'gone'; e.timer = 25 }
    }
  }

  stalkerCanSee (e, p) {
    if (p.hidden || p.dead) return false
    const dx = p.x - e.x, dz = p.z - e.z
    const d = Math.hypot(dx, dz)
    const lit = Math.max(this.hooks.roomLit(p.x, p.z), p.flashlight ? 1 : 0, this.hooks.glowAt(p.x, p.z, 5) ? 0.8 : 0)
    let range = 7 + lit * 11
    if (p.crouch) range *= 0.55
    if (d > range) return false
    if (e.state !== 'chase' && d > 2.2) {
      const fx = Math.sin(e.yaw), fz = Math.cos(e.yaw)
      if ((dx * fx + dz * fz) / d < Math.cos(1.2)) return false
    }
    return lineOfSight(this.F, e.x, e.z, p.x, p.z)
  }

  stalker (e, dt, players, alive, now) {
    if (this.cooldown > 0) this.cooldown -= dt
    // perception
    if (e.state !== 'retreat' && e.state !== 'search' && this.cooldown <= 0) {
      let best = null
      for (const p of alive) {
        const seen = this.stalkerCanSee(e, p)
        const t = seen ? (e.sight.get(p.id) ?? 0) + dt : 0
        e.sight.set(p.id, t)
        if (seen && t > (e.state === 'chase' ? 0 : 0.4)) { const d = Math.hypot(p.x - e.x, p.z - e.z); if (!best || d < best.d) best = { p, d } }
      }
      if (best) {
        if (e.state !== 'chase') this.hooks.fx('roar', { x: e.x, z: e.z })
        e.state = 'chase'
        e.chaseId = best.p.id
        e.lastSeen = { x: best.p.x, z: best.p.z }
        e.lost = 0
      }
    }
    switch (e.state) {
      case 'patrol': {
        e.alert = Math.max(0, e.alert - dt * 0.3)
        if (!e.path.length) {
          if ((e.pause ?? 0) > 0) { e.pause -= dt; e.speed = 0; break }
          // drift toward the players, but not straight at them
          const p = alive[Math.floor(Math.random() * alive.length)]
          const cells = this.F.layout.cells
          let c = cells[Math.floor(Math.random() * cells.length)]
          if (p && Math.random() < 0.6) { const pc = this.F.cellAt(p.x, p.z); const ns = [...(pc?.links ?? [])]; if (ns.length) c = ns[Math.floor(Math.random() * ns.length)] }
          e.path = pathTo(this.F, e, { x: c.center.x + (Math.random() - 0.5) * 6, z: c.center.z + (Math.random() - 0.5) * 6 })
          e.pause = 1.5 + Math.random() * 3
          if (Math.random() < 0.4) this.hooks.fx('stalkerSound', { x: e.x, z: e.z })
        }
        this.moveAlong(e, 1.7, dt)
        break
      }
      case 'investigate': {
        e.alert = Math.min(0.6, e.alert + dt)
        if (this.moveAlong(e, 2.7, dt)) {
          e.timer += dt
          e.yaw += Math.sin(e.timer * 2) * dt * 1.5
          if (e.timer > 3) {
            const spot = this.F.hideSpots.filter(h => Math.hypot(h.exit.x - e.x, h.exit.z - e.z) < 6 && now - (h.searchedAt ?? 0) > 25000)[0]
            if (spot && Math.random() < 0.6) { e.state = 'search'; e.spot = spot; e.path = pathTo(this.F, e, spot.exit); e.timer = 0; e.certain = false }
            else { e.state = 'patrol'; e.path = [] }
          }
        }
        break
      }
      case 'chase': {
        e.alert = 1
        const p = players.find(q => q.id === e.chaseId)
        const visible = p && this.stalkerCanSee(e, p)
        if (visible) { e.lastSeen = { x: p.x, z: p.z }; e.lost = 0 } else {
          e.lost += dt
          if (p?.hidden && p.hiddenSeen) {
            const spot = this.F.hideSpots.find(h => h.id === p.hidden)
            if (spot) { e.state = 'search'; e.spot = spot; e.path = pathTo(this.F, e, spot.exit); e.timer = 0; e.certain = true; break }
          }
        }
        if (!e.lastSeen && p) e.lastSeen = { x: p.x, z: p.z }
        if (!e.path.length || now - (e.repath ?? 0) > 400) { e.path = pathTo(this.F, e, e.lastSeen); e.repath = now }
        const arrived = this.moveAlong(e, this.params.stalkerSpeed, dt)
        if (visible && Math.hypot(p.x - e.x, p.z - e.z) < 1.0) { this.hooks.kill(p.id, 'stalker', e.id); this.retreat(e, alive); break }
        if (!visible && (arrived || e.lost > 5)) { e.state = 'investigate'; e.target = e.lastSeen; e.path = []; e.timer = 0 }
        break
      }
      case 'search': {
        e.alert = e.certain ? 1 : 0.6
        if (this.moveAlong(e, e.certain ? this.params.stalkerSpeed : 2.4, dt)) {
          if (e.timer === 0) this.hooks.fx('rattle', { spot: e.spot.id, x: e.spot.inside.x, z: e.spot.inside.z })
          e.speed = 0
          e.yaw = Math.atan2(e.spot.inside.x - e.x, e.spot.inside.z - e.z)
          e.timer += dt
          if (e.timer > 2.6) {
            e.spot.searchedAt = now
            const inside = this.hooks.isHidden(e.spot.id)
            if (inside && (e.certain || !inside.holdingBreath)) { this.hooks.kill(inside.playerId, 'stalker', e.id); this.retreat(e, alive) } else { e.state = 'patrol'; e.path = []; this.hooks.fx('stalkerSound', { x: e.x, z: e.z }) }
          }
        }
        break
      }
      case 'retreat': {
        e.alert = 0
        if (this.moveAlong(e, 2.4, dt) || (e.timer += dt) > 12) { e.state = 'patrol'; e.path = [] }
        break
      }
    }
  }

  retreat (e, alive) {
    e.state = 'retreat'
    e.timer = 0
    this.cooldown = 6
    e.sight.clear()
    // go somewhere far from everyone
    const cells = this.F.layout.cells.slice().sort((a, b) => {
      const da = Math.min(...alive.map(p => Math.hypot(p.x - a.center.x, p.z - a.center.z)), 99)
      const db = Math.min(...alive.map(p => Math.hypot(p.x - b.center.x, p.z - b.center.z)), 99)
      return db - da
    })
    e.path = pathTo(this.F, e, cells[0].center)
  }

  knockBack (e, p) {
    // a mannequin that has killed steps back to where it stood
    e.state = 'still'
    e.path = []
    const dx = e.x - p.x, dz = e.z - p.z, d = Math.hypot(dx, dz) || 1
    e.x += dx / d * 3; e.z += dz / d * 3
    if (!this.F.free(e.x, e.z, 0.2)) { e.x -= dx / d * 3; e.z -= dz / d * 3 }
  }

  /** where the nearest threat is (for the cat) */
  nearestThreat (x, z) {
    let best = null
    for (const e of this.list) {
      if (!e.visible && e.type !== 'peeker') continue
      if (e.type === 'peeker' && e.state === 'lurk') continue
      const d = Math.hypot(e.x - x, e.z - z)
      if (!best || d < best.d) best = { e, d }
    }
    return best
  }
}

export { HALF }
