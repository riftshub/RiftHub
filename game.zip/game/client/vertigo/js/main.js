// Vertigo Freight: game loop, story, co-op glue, rendering.
import * as THREE from 'three'
import { buildWorld, CARS, carAt, laneX, HALF_W, glowSpriteMaterial } from './world.js'
const NOTE_COUNT = 16
import { createMonsterModel, MonsterBrain } from './monster.js'
import { createPlayer, updatePlayer, takePills, eyeHeight } from './player.js'
import { input, initInput, initTouchControls, consumePressed, consumeLook } from './input.js'
import { net, on, connect, disconnect, sendAll, sendHost, sendTo } from './net.js'
import * as A from './audio.js'
import * as UI from './ui.js'
import { NOTES, OBJECTIVES, ENDINGS } from './story.js'
import { createAvatar } from '../../gamekit/avatar.js'
import { bindFullscreenButtons } from '../../gamekit/fullscreen.js'
import { DEFAULT_SETTINGS, isTouchDevice, BLEED_OUT_SECONDS, REVIVE_SECONDS, FINAL_PHASE_SECONDS } from './config.js'

// ═════════════ settings ═════════════
const SETTINGS_KEY = 'vertigoFreight.settings'
const NAME_KEY = 'vertigoFreight.name'
const loadJSON = (k, fallback) => { try { return { ...fallback, ...JSON.parse(localStorage.getItem(k) || '{}') } } catch { return { ...fallback } } }
const settings = loadJSON(SETTINGS_KEY, DEFAULT_SETTINGS)
const saveSettings = () => { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)) } catch {} }
const touch = isTouchDevice()
UI.ui.touch = touch
const quality = settings.quality === 'auto' ? (touch ? 'low' : 'high') : settings.quality
const HIGH = quality === 'high'

let myName = (() => { try { return localStorage.getItem(NAME_KEY) || '' } catch { return '' } })() || `Conductor ${Math.floor(100 + Math.random() * 900)}`

// ═════════════ renderer + post ═════════════
const canvas = document.getElementById('view')
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' })
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, HIGH ? 1.5 : 1))
renderer.shadowMap.enabled = HIGH
renderer.shadowMap.type = THREE.PCFSoftShadowMap
const RENDER_SCALE = HIGH ? 1 : 0.75

const scene = new THREE.Scene()
scene.background = new THREE.Color(0x070b12)
scene.fog = new THREE.FogExp2(0x06090e, 0.05)
const camera = new THREE.PerspectiveCamera(72, 1, 0.05, 900)
camera.rotation.order = 'YXZ'
scene.add(camera)

const rt = new THREE.WebGLRenderTarget(4, 4, { type: THREE.HalfFloatType, samples: HIGH ? 4 : 0 })
const post = new THREE.ShaderMaterial({
  uniforms: {
    tDiffuse: { value: rt.texture }, time: { value: 0 }, dizzy: { value: 0 }, fear: { value: 0 }, flash: { value: 0 },
    grain: { value: HIGH ? 0.055 : 0.04 }, exposure: { value: 1.15 }, res: { value: new THREE.Vector2(1, 1) }, lightning: { value: 0 },
  },
  defines: { TAPS: HIGH ? 8 : 5 },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
  fragmentShader: /* glsl */`
    uniform sampler2D tDiffuse; uniform float time, dizzy, fear, flash, grain, exposure, lightning; uniform vec2 res;
    varying vec2 vUv;
    float rand(vec2 c){ return fract(sin(dot(c, vec2(12.9898, 78.233))) * 43758.5453); }
    vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0); }
    void main(){
      vec2 uv = vUv;
      uv += dizzy * 0.007 * vec2(sin(uv.y * 9.0 + time * 1.7), cos(uv.x * 8.0 + time * 1.3));
      vec2 dir = vec2(cos(time * 0.73), sin(time * 0.91)) * dizzy * 0.016;
      vec3 col = vec3(0.0);
      for (int i = 0; i < TAPS; i++) { float t = float(i) / float(TAPS - 1) - 0.5; col += texture2D(tDiffuse, uv + dir * t * 2.0).rgb; }
      col /= float(TAPS);
      // double vision: a drifting second image
      vec3 ghost = texture2D(tDiffuse, uv + vec2(0.024 * sin(time * 0.6), 0.008 * cos(time * 0.8)) * dizzy).rgb;
      col = mix(col, (col + ghost) * 0.5, dizzy * 0.75);
      float ca = 0.0012 + dizzy * 0.005 + fear * 0.0025;
      vec2 c = (uv - 0.5) * ca;
      col.r = mix(col.r, texture2D(tDiffuse, uv + c).r, 0.75);
      col.b = mix(col.b, texture2D(tDiffuse, uv - c).b, 0.75);
      col *= exposure * (1.0 + lightning * 0.6);
      col = aces(col);
      // grade: lift shadows toward steel blue, warm the highlights, pull saturation
      float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
      col = mix(vec3(l), col, 0.85);
      col += vec3(-0.004, 0.004, 0.014) * (1.0 - smoothstep(0.0, 0.35, l));
      col *= mix(vec3(1.0), vec3(1.05, 0.99, 0.9), smoothstep(0.35, 1.0, l));
      float v = smoothstep(0.82, 0.18 - fear * 0.1 - dizzy * 0.08, length((vUv - 0.5) * vec2(1.0, 0.82)));
      col *= mix(0.28, 1.0, v);
      col = mix(col, vec3(0.42, 0.02, 0.02), flash * (0.85 - v * 0.4));
      col = pow(col, vec3(1.0 / 2.2));
      col += (rand(vUv * res + fract(time) * 37.0) - 0.5) * grain;
      gl_FragColor = vec4(col, 1.0);
    }`,
  depthTest: false,
  depthWrite: false,
})
const postScene = new THREE.Scene()
const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1)
postScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), post))

const resize = () => {
  const w = window.innerWidth, h = window.innerHeight
  renderer.setSize(w, h, false)
  const pr = renderer.getPixelRatio()
  rt.setSize(Math.max(2, Math.floor(w * pr * RENDER_SCALE)), Math.max(2, Math.floor(h * pr * RENDER_SCALE)))
  post.uniforms.res.value.set(w, h)
  camera.aspect = w / h
  camera.updateProjectionMatrix()
}
window.addEventListener('resize', resize)
resize()

// ═════════════ world ═════════════
UI.setLoading('Loading the train…')
const world = buildWorld(scene, { quality })
const hemi = new THREE.HemisphereLight(0x22324a, 0x0b0907, 0.32)
scene.add(hemi)

const flashlight = new THREE.SpotLight(0xffe8c4, 0, 26, 0.52, 0.8, 1.5)
flashlight.position.set(0.12, -0.12, 0)
flashlight.castShadow = HIGH
flashlight.shadow.mapSize.set(1024, 1024)
flashlight.shadow.bias = -0.0008
flashlight.shadow.camera.near = 0.1
camera.add(flashlight)
camera.add(flashlight.target)
flashlight.target.position.set(0.05, -0.08, -1)

const lampPool = Array.from({ length: HIGH ? 4 : 2 }, () => {
  const l = new THREE.PointLight(0xffc27a, 0, 9, 1.7)
  scene.add(l)
  return l
})

const monsterModel = createMonsterModel()
monsterModel.root.visible = false
scene.add(monsterModel.root)
const apparition = createMonsterModel() // for the face at the window
apparition.root.visible = false
scene.add(apparition.root)

const doorByIndex = i => world.doors[i]
const CAR7_DOOR = world.doors.findIndex(d => d.locked)

// ═════════════ game state ═════════════
const freshFlags = () => ({
  ch: 1, knocked: false, powerOut: false, crossed: false, monsterActive: false, fuses: 0, key: false, car7Open: false, car7Visited: false,
  fusesInstalled: false, powerOn: false, final: false, inCab: false, ending: null, windowScare: false,
  chase: 0, chase1Done: false, rearVisited: false, wrench: false, valves: [], pressureOk: false,
  parts: [], radioCalled: false, coupling: false, chase2Done: false, uncoupled: false,
})
const DEFAULT_LOCKS = () => world.doors.map(d => d.carId === 'car7' || d.carId === 'dining')
const doorIdx = carId => world.doors.findIndex(d => d.carId === carId)
const clone = o => JSON.parse(JSON.stringify(o))
const G = {
  mode: 'loading', // loading | title | playing | caught | down | ending
  coop: false,
  flags: freshFlags(),
  taken: new Set(),
  checkpoint: 'start',
  snapshot: null,
  finalTimer: null,
  speed: 1, speedTarget: 1,
  power: 'flicker',
  monster: { x: 0.85, z: -110, yaw: 0, speed: 0, anim: 'idle', alert: 0, visible: false, state: 'dormant' },
  monsterTarget: null,
  registry: new Map(), // host: id -> player state used by the AI
  avatars: new Map(), // others' visuals
  statusById: new Map(), // id -> { down, downLeft, dead }
  stats: { start: 0, spells: 0, hides: 0, notes: new Set() },
  sessionTime: 0,
  paused: false,
  invSnapshot: null,
  lastWorldSend: 0,
  lastStateSend: 0,
  scripts: { nextAmbient: 30, nextLightning: 20, crossingAt: 0, monsterWakeAt: 0, knocks: 0 },
  lightning: 0,
  car7Cascade: 0,
  hiddenSpot: null,
  reviveProgress: 0,
  jumpscare: null,
  fear: 0,
  heartbeatAt: 0,
  breath: null,
}
const P = createPlayer()
const myId = () => net.id ?? 'local'
const isHost = () => net.isHost

const brain = new MonsterBrain(world, {
  openDoor: i => hostOpenDoor(i, true),
  isDoorOpen: i => world.doors[i].open > 0.7,
  isDoorLocked: i => !!world.doors[i].locked,
  onCatch: id => hostCatch(id),
  onSearchSpot: (spot, phase) => fx(phase === 'start' ? 'rattle' : 'rattleEnd', { spot }),
  isHidden: spotId => {
    for (const p of G.registry.values()) {
      if (p.hidden === spotId) return { playerId: p.id, holdingBreath: p.holdingBreath, seenEntering: p.hiddenSeen }
    }
    return null
  },
  litAt: z => {
    const car = carAt(z)
    const g = car && world.lampGroups.get(car.id)
    return g ? Math.min(1, g.level * 1.2) : 0
  },
  onRoar: () => fx('roar', { x: brain.x, z: brain.z }),
  onSound: (kind, x, z) => fx('creature', { kind, x, z }),
})

// ═════════════ effects (host originates, everyone plays) ═════════════
function fx (kind, data = {}) {
  playFx(kind, data)
  if (net.online && isHost()) sendAll('fx', { kind, data }) // wrapped: data may have its own 'kind'
}

const monsterPos = () => ({ x: G.monster.x, y: 1.6, z: G.monster.z })

function playFx (kind, d) {
  switch (kind) {
    case 'knock':
      A.knock({ x: 0, y: 1.4, z: -4.6 })
      setTimeout(() => UI.toast('Three knocks, from behind the cab door.'), 1600)
      break
    case 'door': A.doorSlide({ x: 0, y: 1.2, z: world.doors[d.i].z }, { slam: d.slam }); break
    case 'locked': A.locked({ x: 0, y: 1.1, z: world.doors[d.i]?.z ?? P.z }); break
    case 'powerOut':
      A.powerDown()
      G.power = 'out'
      UI.toast(touch ? 'The lights die. Tap Light for your flashlight.' : 'The lights die. Press F for your flashlight.', 4500)
      break
    case 'powerOn':
      A.powerUp()
      G.power = 'on'
      break
    case 'pickup': {
      if (d.by === myId()) {
        A.pickup()
        if (d.item === 'wrench') UI.toast('A heavy valve wrench. Now the bleed valves can be closed.')
        if (d.parts) UI.toast(`A radio part (${d.parts} of 3).`)
        if (d.fuses) UI.toast(`A fuse (${d.fuses} of 3).`)
      }
      if (d.by !== myId()) {
        const who = playerName(d.by)
        if (d.item.startsWith('fuse')) UI.toast(`${who} found a fuse (${d.fuses}/3).`)
        if (d.item === 'key') UI.toast(`${who} found the conductor's key.`)
        if (d.item === 'wrench') UI.toast(`${who} found the valve wrench.`)
        if (d.parts) UI.toast(`${who} found a radio part (${d.parts}/3).`)
      }
      break
    }
    case 'unlock': A.click({ x: 0, y: 1.1, z: world.doors[CAR7_DOOR].z }); UI.toast('The door to Car 7 unlocks.'); break
    case 'fusesIn': A.click({ x: 1.3, y: 1.3, z: -127 }); UI.toast('All three fuses are in. Now the lever.'); break
    case 'radio': A.radioStatic(2.2); if (d.by === myId()) UI.toast(d.text ?? 'Nothing but static. Then, under it, someone breathing.'); break
    case 'roar': A.roar({ x: d.x, y: 1.7, z: d.z }); A.stinger(0.4); bumpFear(0.5); break
    case 'creature':
      if (d.kind === 'drag') A.drag({ x: d.x, y: 0.4, z: d.z })
      else if (d.kind === 'growl') A.growl({ x: d.x, y: 1.7, z: d.z }, 0.55, 1.3)
      else if (d.kind === 'knock') { for (let i = 0; i < 3; i++) setTimeout(() => A.creatureStep({ x: d.x, y: 1.4, z: d.z }, 0.8), i * 380) }
      else if (d.kind === 'whisper') A.whisper({ x: d.x, y: 1.5, z: d.z })
      break
    case 'rattle': {
      const spot = world.hideSpots.find(s => s.id === d.spot)
      if (spot) { spot.rattle = 2.6; A.growl({ x: spot.exit.x, y: 1.6, z: spot.exit.z }, 0.35, 2.2) }
      if (G.hiddenSpot === d.spot) { bumpFear(0.6); UI.toast(touch ? 'It\'s right outside. Hold your breath!' : 'It\'s right outside. Hold Space!', 2500) }
      break
    }
    case 'rattleEnd': { const spot = world.hideSpots.find(s => s.id === d.spot); if (spot) spot.rattle = 0; break }
    case 'crossing': A.stinger(0.55); bumpFear(0.6); G.flicker = { car: 'coach', until: performance.now() + 2200 }; break
    case 'windowScare':
      G.lightning = 1
      A.thunder()
      setTimeout(() => A.stinger(0.7), 60)
      apparition.root.visible = true
      apparition.root.position.set(-2.05, -0.15, -49.4)
      apparition.root.rotation.y = Math.PI / 2
      setTimeout(() => { apparition.root.visible = false }, 650)
      bumpFear(0.7)
      break
    case 'car7':
      G.car7Cascade = 1
      A.whisper({ x: 1, y: 1.5, z: -75 })
      setTimeout(() => A.whisper({ x: 1, y: 1.5, z: -95 }), 1800)
      break
    case 'lightning': G.lightning = 1; A.thunder(); break
    case 'lurch': A.brakes(); A.creak({ x: P.x, y: 2, z: P.z }); P.lurch = 1; P.shake = 0.8; P.balance += 25; UI.toast('The whole train lurches. The brakes are screaming.', 3000); break
    case 'chapter': showChapter(d.n); break
    case 'run': UI.toast('RUN.', 2500); A.stinger(0.9); bumpFear(0.8); break
    case 'pound': {
      const z = world.doors[d.i].z
      for (let i = 0; i < 6; i++) setTimeout(() => { A.knock({ x: 0, y: 1.3, z }); P.shake = Math.max(P.shake, 0.35) }, i * 650)
      setTimeout(() => A.growl({ x: 0, y: 1.6, z: z + (d.side ?? 1) * 1.2 }, 1), 1300)
      break
    }
    case 'valve': {
      A.valve({ x: d.x, y: 1, z: d.z })
      const v = world.interactables.find(i => i.id === d.id)
      if (v) v.closed = true
      UI.toast(`Valve closed (${d.n} of 4). The squeal carries a long way...`)
      break
    }
    case 'pressureOk':
      A.powerUp(); A.brakes()
      UI.toast('The needles climb back up. The brakes bite and the train slows.', 4500)
      setTimeout(() => showChapter(3), 4500)
      break
    case 'radioCall': radioCall(); break
    case 'roofSteps': {
      for (let i = 0; i < 7; i++) setTimeout(() => { A.creatureStep({ x: 0, y: 3.2, z: d.z0 + (d.z1 - d.z0) * i / 6 }, 1.2); P.shake = Math.max(P.shake, 0.25) }, i * 520)
      break
    }
    case 'smash': A.stinger(1); A.roar({ x: d.x, y: 1.7, z: d.z }); A.doorSlide({ x: d.x, y: 1.5, z: d.z }, { slam: true }); bumpFear(1); G.lightning = 1; break
    case 'uncouple':
      A.lever({ x: 0, y: 1, z: -135 }); A.brakes()
      P.shake = 1
      UI.toast('A crash of iron. The back of the train tears away into the dark, and the thing on the roof goes with it... for now.', 6000)
      break
    case 'roofReturn':
      for (let i = 0; i < 6; i++) setTimeout(() => A.creatureStep({ x: 0, y: 3.2, z: -110 + i * 8 }, 1.3), i * 600)
      setTimeout(() => { A.roar({ x: 0, y: 2, z: -64 }); UI.toast('Something heavy drops through a hatch into Car 7. It got back on.', 5000) }, 3800)
      break
    case 'caught': onCaught(d.id); break
    case 'toast': if (!d.to || d.to === myId()) UI.toast(d.text, d.ms ?? 3200); break
  }
}

function bumpFear (v) {
  G.fear = Math.min(1, G.fear + v)
  P.balance += v * 18
}

const playerName = id => (id === myId() ? myName : net.players.get(id)?.name ?? 'Someone')

// ═════════════ host logic ═════════════
function hostOpenDoor (i, byMonster = false) {
  const d = world.doors[i]
  if (d.target === 1) return
  d.target = 1
  d.lastOpened = performance.now()
  fx('door', { i, slam: byMonster })
}

function setCheckpoint (name) {
  G.checkpoint = name
  G.snapshot = { flags: clone(G.flags), taken: [...G.taken], locks: world.doors.map(d => d.locked), power: G.power, speed: G.speedTarget }
  fx('checkpoint', { name })
  onCheckpoint(name)
  if (net.online) sendAll('checkpoint', { name })
}

function onCheckpoint (name) {
  if (G.checkpoint !== name) A.checkpointChime()
  G.checkpoint = name
  G.invSnapshot = { ...P.inv, battery: P.battery }
  // fallen teammates come back at checkpoints
  if (P.down && G.statusById.get(myId())?.dead) respawnAt(name)
}

function hostCatch (id) {
  const st = G.statusById.get(id) ?? {}
  st.down = true
  st.downLeft = BLEED_OUT_SECONDS
  st.dead = false
  G.statusById.set(id, st)
  const p = G.registry.get(id)
  if (p) { p.down = true; p.hidden = null }
  fx('caught', { id })
}

function hostInteract (pid, id) {
  const f = G.flags
  const tell = (text, ms) => fx('toast', { to: pid, text, ms })
  const item = world.items.find(i => i.id === id)
  if (item) {
    if (item.kind === 'note') return
    if (G.taken.has(id)) return
    G.taken.add(id)
    if (item.kind === 'fuse') { f.fuses++; fx('pickup', { item: id, by: pid, fuses: f.fuses }) }
    else if (item.kind === 'wrench') { f.wrench = true; fx('pickup', { item: id, by: pid }) }
    else if (['tube', 'coil', 'cell'].includes(item.kind)) { f.parts.push(item.kind); fx('pickup', { item: id, by: pid, parts: f.parts.length }) }
    else if (item.kind === 'key') {
      f.key = true
      fx('pickup', { item: id, by: pid })
      if (!f.windowScare) { f.windowScare = true; setTimeout(() => fx('windowScare'), 900) }
    } else grant(pid, item.kind)
    return
  }
  if (id.startsWith('valve-')) {
    if (f.ch !== 2) { tell('A bleed valve on the brake line. It\'s fine for now.'); return }
    if (!f.wrench) { tell('Rusted solid. You need a valve wrench.'); return }
    if (f.valves.includes(id)) return
    f.valves.push(id)
    const v = world.interactables.find(i => i.id === id)
    fx('valve', { id, x: v.x, z: v.z, n: f.valves.length })
    brain.hear(v.x, v.z, 10) // the valve squeals as it closes
    return
  }
  switch (id) {
    case 'radio':
      if (f.ch === 3 && !f.radioCalled) {
        if (f.parts.length < 3) { fx('radio', { by: pid, text: `The radio is dead. It needs a valve tube, an aerial coil and a battery cell (${f.parts.length} of 3 found).` }); return }
        f.radioCalled = true
        fx('radioCall')
        return
      }
      fx('radio', { by: pid, text: f.final ? 'A voice, very calm: "Don\'t stop. You\'re nearly home."' : undefined })
      break
    case 'pressure':
      if (f.ch !== 2 || f.pressureOk) { tell('The needles sit where they should.'); return }
      if (f.valves.length < 4) { tell(`The pressure won't hold. ${4 - f.valves.length} bleed valve${f.valves.length === 3 ? ' is' : 's are'} still open.`); return }
      f.pressureOk = true
      fx('pressureOk')
      G.speedTarget = 1
      f.ch = 3
      setTimeout(() => setCheckpoint('radio'), 600)
      break
    case 'coupling':
      if (f.ch !== 3 || !f.radioCalled) { tell('A heavy release lever. It isn\'t time for that.'); return }
      if (f.coupling) return
      f.coupling = true
      setCheckpoint('chase2')
      runChase2()
      break
    case 'door-sealed': tell('Sealed shut. Through the little window there\'s nothing but dark.'); fx('locked', { i: doorIdx('dining') }); break
    case 'door-bulkhead': tell('It\'s jammed. Something heavy is holding it from the other side.'); fx('locked', { i: doorIdx('sleeper') }); break
    case 'breaker':
      if (!f.powerOut) triggerPowerOut()
      else tell('The breaker is dead. All three fuse sockets are empty.')
      break
    case 'door-car7':
      if (!world.doors[CAR7_DOOR].locked) return
      if (f.key) { world.doors[CAR7_DOOR].locked = false; f.car7Open = true; fx('unlock'); hostOpenDoor(CAR7_DOOR) } else { fx('locked', { i: CAR7_DOOR }); tell('Locked. The conductor\'s key would open it.') }
      break
    case 'fusePanel':
      if (!f.powerOut || f.fusesInstalled) return
      if (f.fuses < 3) { tell(`Three empty sockets. You've found ${f.fuses} of the fuses.`); return }
      f.fusesInstalled = true
      fx('fusesIn')
      setCheckpoint('fusesIn')
      break
    case 'mainLever':
      if (!f.fusesInstalled || f.powerOn) return
      startChase1()
      break
    case 'brake': if (f.final && !f.ending) hostEnding('brake'); break
    case 'driverSeat': if (f.final && !f.ending) hostEnding('arrive'); break
  }
}

function grant (pid, kind) {
  if (pid === myId()) applyGrant(kind)
  else sendTo(pid, 'grant', { kind })
}

function applyGrant (kind) {
  A.pickup()
  if (kind === 'battery') { P.inv.batteries++; UI.toast('A flashlight battery.') }
  if (kind === 'pills') { P.inv.pills++; UI.toast(touch ? 'Motion-sickness pills. Tap Pill when dizzy.' : 'Motion-sickness pills. Press R when dizzy.') }
}

function triggerPowerOut () {
  if (G.flags.powerOut) return
  G.flags.powerOut = true
  fx('powerOut')
  setTimeout(() => setCheckpoint('powerOut'), 400)
}

// ── Chapter 1 ends: power returns, the sealed door opens, and it comes for you (chase scene 1) ──
function startChase1 () {
  const f = G.flags
  f.powerOn = true
  fx('powerOn')
  G.speedTarget = 1.35
  brain.rearLimit = -206
  setCheckpoint('chase1')
  runChase1()
}

function runChase1 () {
  const f = G.flags
  const di = doorIdx('dining')
  world.doors[di].locked = false
  hostOpenDoor(di, true)
  f.chase = 0
  setTimeout(() => {
    if (G.checkpoint !== 'chase1' || f.chase1Done) return
    // It's in the doorway between you and the front of the train.
    brain.placeAt(0, -121.6, 'scripted')
    brain.yaw = Math.PI
    brain.script([{ x: 0, z: -122.3 }], 0.8, () => {
      fx('roar', { x: brain.x, z: brain.z })
      fx('run')
      f.chase = 1
      G.chaseStart = performance.now()
      setTimeout(() => { if (f.chase === 1) brain.hunt(3.55) }, 1400)
    })
  }, 1600)
}

function endChase1 (sealed) {
  const f = G.flags
  f.chase = 0
  f.chase1Done = true
  f.ch = 2
  if (sealed) {
    const si = doorIdx('sleeper')
    world.doors[si].target = 0
    world.doors[si].locked = true
    fx('door', { i: si, slam: true })
    fx('pound', { i: si, side: 1 })
    setTimeout(() => { world.doors[si].locked = false }, 45000)
  }
  // it gives up and slinks back toward the long car
  brain.script([{ x: 0, z: -140 }, { x: 1, z: -100 }], 2.6, () => brain.setState('patrol', { target: null }))
  setTimeout(() => {
    fx('chapter', { n: 2 })
    setCheckpoint('brakeLine')
  }, 5000)
}

// ── Chapter 3 ends: the coupling release, and it comes over the roof (chase scene 2) ──
function runChase2 () {
  const f = G.flags
  f.chase = 0
  brain.state = 'dormant'
  brain.visible = false
  fx('toast', { text: 'The lever won\'t budge... and something is running along the roof toward you.', ms: 4000 })
  fx('roofSteps', { z0: -180, z1: -204 })
  setTimeout(() => {
    if (G.checkpoint !== 'chase2' || f.chase2Done) return
    fx('smash', { x: 0, z: -206.6 })
    brain.placeAt(0, -206.2, 'scripted')
    brain.yaw = Math.PI
    f.chase = 2
    fx('run')
    setTimeout(() => { if (f.chase === 2) brain.hunt(3.5) }, 900)
  }, 4200)
}

function endChase2 () {
  const f = G.flags
  f.chase = 0
  f.chase2Done = true
  f.uncoupled = true
  const di = doorIdx('dining')
  world.doors[di].target = 0
  world.doors[di].locked = true
  fx('door', { i: di, slam: true })
  fx('pound', { i: di, side: -1 })
  brain.state = 'dormant'
  brain.visible = false
  brain.rearLimit = -133
  setTimeout(() => fx('uncouple'), 2600)
  setTimeout(() => startFinal(), 9000)
}

// ── Chapter 4: the run home ──
function startFinal () {
  const f = G.flags
  f.ch = 4
  f.final = true
  G.finalTimer = FINAL_PHASE_SECONDS
  G.speedTarget = 1.65
  brain.final = true
  fx('chapter', { n: 4 })
  fx('roofReturn')
  setTimeout(() => {
    brain.placeAt(1, -64, 'patrol')
    setCheckpoint('finalPhase')
  }, 4200)
}

/** The dispatcher answers... */
function radioCall () {
  const lines = [
    ['Static. Then a click, and a voice you know.', 3500],
    ['"Route Zero, this is dispatch. We read you, Conductor."', 4500],
    ['"You\'ve been reported missing since the night of the flood. Forty years. Every night you call, and every night you ask the same thing."', 6500],
    ['"There\'s something riding with you. It isn\'t trying to eat you. It\'s trying to keep you from getting home."', 6000],
    ['"Go to the very back. Pull the coupling release. Leave it behind with the cars that shouldn\'t be there."', 6000],
    ['The voice stops. When it starts again, it is your own voice: "Don\'t."', 5000],
  ]
  A.radioStatic()
  let t = 0
  for (const [text, ms] of lines) {
    setTimeout(() => { UI.toast(text, ms - 200); A.radioStatic() }, t)
    t += ms
  }
}

function showChapter (n) {
  const names = ['The Dead Line', 'The Brake Line', 'Radio Silence', 'Arrival']
  UI.chapterCard?.(`Chapter ${n}`, names[n - 1])
  A.objectiveChime()
}

function hostEnding (kind) {
  G.flags.ending = kind
  fx('ending', { kind })
  showEnding(kind)
  if (net.online) sendAll('ending', { kind })
}

const respawnIndex = () => {
  const ids = [...new Set([...net.players.keys(), myId()])].sort()
  return Math.max(0, ids.indexOf(myId())) % 4
}

function respawnAt (checkpoint) {
  const spawns = world.spawns[checkpoint] ?? world.spawns.start
  const s = spawns[respawnIndex()]
  Object.assign(P, { x: s.x, z: s.z, yaw: s.yaw, pitch: 0, seated: !!s.seated, down: false, alive: true, hidden: null, spell: 0, warning: 0, balance: 10, crouch: false })
  G.hiddenSpot = null
  UI.setSlits(null)
  G.breath?.stop?.()
  G.breath = null
  if (G.mode !== 'playing') { G.mode = 'playing'; UI.showScreen(null); UI.setHud(true) }
  G.statusById.set(myId(), { down: false, downLeft: 0, dead: false })
  input.enabled = true
}

function hostRestart () {
  const snap = G.snapshot
  G.flags = snap ? clone(snap.flags) : freshFlags()
  G.taken = new Set(snap?.taken ?? [])
  const locks = snap ? snap.locks : DEFAULT_LOCKS()
  world.doors.forEach((d, i) => { d.locked = locks[i]; d.target = 0 })
  G.power = snap?.power ?? 'flicker'
  G.speedTarget = snap?.speed ?? 1
  G.statusById.clear()
  for (const p of G.registry.values()) { p.down = false; p.hidden = null }
  placeMonsterForCheckpoint(G.checkpoint)
  if (G.checkpoint === 'finalPhase') { G.finalTimer = FINAL_PHASE_SECONDS; G.speedTarget = 1.65; brain.final = true } else { G.finalTimer = null; brain.final = false }
  sendAll('restart', restartPayload())
  applyRestart(G.checkpoint)
  // chase scenes replay from their start
  if (G.checkpoint === 'chase1') setTimeout(runChase1, 1200)
  if (G.checkpoint === 'chase2') setTimeout(runChase2, 1200)
}

const restartPayload = () => ({ checkpoint: G.checkpoint, flags: G.flags, taken: [...G.taken], locks: world.doors.map(d => d.locked), power: G.power })

function placeMonsterForCheckpoint (cp) {
  brain.sightTime.clear()
  brain.chaseId = null
  brain.rearLimit = G.flags.uncoupled ? -133 : G.flags.powerOn ? -206 : -134
  if (cp === 'start' || cp === 'powerOut') {
    brain.state = 'dormant'
    brain.visible = false
    if (cp === 'powerOut' && G.flags.crossed) { brain.placeAt(1, -100, 'patrol') }
  } else if (cp === 'fusesIn') brain.placeAt(1, -88, 'patrol')
  else if (cp === 'chase1' || cp === 'chase2') { brain.state = 'dormant'; brain.visible = false }
  else if (cp === 'brakeLine') brain.placeAt(1, -95, 'patrol')
  else if (cp === 'radio') brain.placeAt(0.35, -186, 'patrol')
  else if (cp === 'finalPhase') brain.placeAt(1, -66, 'patrol')
}

function applyRestart (checkpoint) {
  if (G.invSnapshot) { P.inv = { batteries: G.invSnapshot.batteries, pills: G.invSnapshot.pills }; P.battery = G.invSnapshot.battery }
  respawnAt(checkpoint)
  G.jumpscare = null
  UI.fade(0, 900)
  UI.toast('Back at the last checkpoint.')
}

/** Everyone down (or the only player)? Then it's over: restart from the checkpoint. */
function hostCheckWipe () {
  const ids = [...new Set([...G.registry.keys()])]
  if (!ids.length) return
  const allDown = ids.every(id => G.statusById.get(id)?.down)
  if (allDown && !G.wipeAt) G.wipeAt = performance.now() + 2600
}

// ═════════════ networking glue ═════════════
on('state', (d, from) => {
  // a teammate's own position (everyone renders it; the host also feeds it to the AI)
  const p = G.registry.get(from) ?? { id: from }
  Object.assign(p, d, { id: from, alive: true })
  const st = G.statusById.get(from)
  p.down = !!st?.down
  G.registry.set(from, p)
  let av = G.avatars.get(from)
  if (!av) {
    const model = createAvatar(from, { outfit: 'conductor', name: playerName(from), shadows: HIGH })
    scene.add(model.group)
    av = { model, target: null, x: d.x, z: d.z, yaw: d.yaw, speed: 0, lastX: d.x, lastZ: d.z }
    G.avatars.set(from, av)
  }
  av.target = d
})

on('noise', d => { if (isHost()) brain.hear(d.x, d.z, d.r) })
on('req', (d, from) => {
  if (!isHost()) return
  if (d.kind === 'interact') hostInteract(from, d.id)
  else if (d.kind === 'hide') hostHide(from, d.spot)
  else if (d.kind === 'revive') hostRevive(from, d.target)
})
on('grant', d => applyGrant(d.kind))
on('fx', d => { if (!isHost()) playFx(d.kind, d.data ?? {}) })
on('hideOk', d => enterHide(d.spot, d.seen))
on('hideNo', () => UI.toast('Someone is already in there.'))
on('checkpoint', d => { if (!isHost()) onCheckpoint(d.name) })
on('restart', d => {
  if (isHost()) return
  G.flags = d.flags
  G.taken = new Set(d.taken)
  d.locks?.forEach((l, i) => { world.doors[i].locked = l })
  G.power = d.power
  G.statusById.clear()
  applyRestart(d.checkpoint)
})
on('ending', d => { if (!isHost()) showEnding(d.kind) })
on('world', d => {
  if (isHost()) return
  G.monsterTarget = d.m
  d.doors.forEach(([target, locked], i) => { world.doors[i].target = target; world.doors[i].locked = !!locked })
  G.flags = d.flags
  G.taken = new Set(d.taken)
  G.power = d.power
  G.finalTimer = d.timer
  G.speedTarget = d.speed
  G.checkpoint = d.cp
  G.statusById = new Map(Object.entries(d.status ?? {}))
})
on('start', d => {
  if (isHost()) return
  startSession({ coop: true, late: d.late, checkpoint: d.checkpoint })
})
on('revived', d => {
  const st = G.statusById.get(d.id)
  if (st) { st.down = false; st.dead = false }
  if (d.id === myId()) {
    P.down = false
    input.enabled = true
    G.mode = 'playing'
    UI.showScreen(null)
    UI.setHud(true)
    UI.fade(0, 600)
    UI.toast(`${playerName(d.by)} pulled you up.`)
    P.balance = 70
  } else UI.toast(`${playerName(d.by)} helped ${playerName(d.id)} up.`)
})
on('peerJoin', d => {
  UI.toast(`${d.name} joined.`)
  if (isHost() && G.mode !== 'title' && G.mode !== 'loading') {
    // late joiner: drop them in at the current checkpoint
    sendTo(d.id, 'restart', restartPayload())
    sendTo(d.id, 'start', { late: true, checkpoint: G.checkpoint })
  }
  refreshLobby()
})
on('peerLeave', d => {
  UI.toast(`${playerName(d.id)} left.`)
  G.registry.delete(d.id)
  G.statusById.delete(d.id)
  const av = G.avatars.get(d.id)
  if (av) { av.model.dispose(); G.avatars.delete(d.id) }
  refreshLobby()
})
on('hostChange', ({ isHost: me }) => {
  if (me && G.mode !== 'title') {
    // we inherit the creature from the last thing the old host told us
    brain.restore(G.monster)
    UI.toast('You are now the host.')
  }
  refreshLobby()
})
on('disconnected', () => {
  if (G.mode === 'title' || G.mode === 'loading') { UI.setStatus('#lobby-status', 'Disconnected from the co-op server.', true); return }
  UI.toast('Lost the connection. Carrying on alone.', 4500)
  brain.restore(G.monster)
  for (const id of [...G.registry.keys()]) if (id !== myId() && id !== 'local') G.registry.delete(id)
  for (const av of G.avatars.values()) av.model.dispose()
  G.avatars.clear()
  G.coop = false
})
on('roster', () => refreshLobby())
on('name', (d, from) => { const p = net.players.get(from); if (p) p.name = d.name; refreshLobby() })

function hostHide (pid, spotId) {
  const occupied = [...G.registry.values()].some(p => p.hidden === spotId && p.id !== pid)
  if (occupied) { if (pid === myId()) UI.toast('Someone is already in there.'); else sendTo(pid, 'hideNo'); return }
  const rp = G.registry.get(pid)
  const seen = brain.state === 'chase' && brain.chaseId === pid && rp && brain.canSee({ ...rp, hidden: null })
  if (rp) { rp.hidden = spotId; rp.hiddenSeen = seen }
  if (pid === myId()) enterHide(spotId, seen)
  else sendTo(pid, 'hideOk', { spot: spotId, seen })
}

function hostRevive (by, target) {
  const st = G.statusById.get(target)
  if (!st?.down || st.dead) return
  const a = G.registry.get(by), b = G.registry.get(target)
  if (!a || !b || Math.hypot(a.x - b.x, a.z - b.z) > 2.2) return
  st.down = false
  if (b) b.down = false
  G.wipeAt = 0
  sendAll('revived', { id: target, by })
  // apply locally too (sendAll skips ourselves)
  if (target === myId()) {
    P.down = false; input.enabled = true; G.mode = 'playing'; UI.showScreen(null); UI.setHud(true); UI.fade(0, 600); UI.toast(`${playerName(by)} pulled you up.`)
  } else UI.toast(`${playerName(by)} helped ${playerName(target)} up.`)
}

// ═════════════ local actions ═════════════
const request = (kind, data = {}) => {
  if (isHost()) {
    if (kind === 'interact') hostInteract(myId(), data.id)
    else if (kind === 'hide') hostHide(myId(), data.spot)
    else if (kind === 'revive') hostRevive(myId(), data.target)
  } else sendHost('req', { kind, ...data })
}

function enterHide (spotId, seen) {
  const spot = world.hideSpots.find(s => s.id === spotId)
  if (!spot) return
  P.hidden = spotId
  P.hiddenSeen = !!seen
  G.hiddenSpot = spotId
  P.flashlight = false
  P.crouch = false
  P.pitch = 0
  P.yaw = spot.yaw
  G.hideYaw = spot.yaw
  spot.openAnim = 1
  A.doorSlide({ x: spot.inside.x, y: 1, z: spot.inside.z })
  UI.setSlits(spot.type === 'compartment' ? null : 'slits')
  G.stats.hides++
  G.breath = A.breathLoop()
}

function leaveHide () {
  const spot = world.hideSpots.find(s => s.id === P.hidden)
  P.hidden = null
  G.hiddenSpot = null
  if (spot) { P.x = spot.exit.x; P.z = spot.exit.z; spot.openAnim = 1; A.doorSlide({ x: spot.inside.x, y: 1, z: spot.inside.z }) }
  UI.setSlits(null)
  G.breath?.stop()
  G.breath = null
  const rp = G.registry.get(myId())
  if (rp) rp.hidden = null
}

function onCaught (id) {
  const pos = id === myId() ? { x: P.x, y: 1.4, z: P.z } : (G.registry.get(id) ?? G.avatars.get(id)?.target)
  if (id !== myId()) {
    A.scream(0.55)
    if (pos) A.growl({ x: pos.x, y: 1.5, z: pos.z }, 1, 1.2)
    UI.toast(`${playerName(id)} was taken.`, 4000)
    return
  }
  // ── the jump scare ──
  if (P.hidden) leaveHide()
  G.mode = 'caught'
  input.enabled = false
  G.jumpscare = { t: 0 }
  A.scream(1)
  UI.redFlash(1)
  P.shake = 1
  G.stats.caught = (G.stats.caught ?? 0) + 1
  setTimeout(() => {
    UI.fade(1, 500)
    setTimeout(() => {
      G.jumpscare = null
      P.down = true
      G.mode = 'down'
      UI.setHud(false)
      const solo = !net.online || net.players.size <= 1
      document.getElementById('down-title').textContent = solo ? 'Taken' : 'Down'
      document.getElementById('down-text').textContent = solo ? 'It found you. The train rolls on without its driver.' : 'You\'re down. A teammate can still pull you up before it\'s too late.'
      document.getElementById('down-menu').style.display = solo || isHost() ? '' : 'none'
      document.querySelector('#down-menu [data-go=retry]').parentElement.style.display = solo ? '' : 'none'
      UI.showScreen('down')
      UI.fade(solo ? 0.6 : 0.35, 800)
      if (solo && isHost()) hostCheckWipe()
    }, 550)
  }, 1250)
}

// ═════════════ avatars (other players) ═════════════
// ═════════════ session flow ═════════════
function startSession ({ coop = false, late = false, checkpoint = 'start' } = {}) {
  A.initAudio()
  A.setVolume(settings.volume)
  A.startTrainAmbience()
  G.coop = coop
  G.flags = late ? G.flags : freshFlags()
  if (!late) {
    G.taken = new Set()
    G.checkpoint = 'start'
    G.snapshot = null
    const locks = DEFAULT_LOCKS()
    world.doors.forEach((d, i) => { d.locked = locks[i] })
    G.power = 'flicker'
    G.finalTimer = null
    G.speedTarget = 1
    brain.final = false
    brain.state = 'dormant'
    brain.visible = false
    brain.rearLimit = -134
    for (const it of world.interactables) if (it.valve) it.closed = false
    setTimeout(() => showChapter(1), 2600)
  }
  G.lastObjective = null
  for (const d of world.doors) { d.target = 0; d.open = 0 }
  G.statusById.clear()
  G.registry.clear()
  Object.assign(G.scripts, { nextAmbient: 40, nextLightning: 25, knocks: 0, crossingAt: 0, monsterWakeAt: 0 })
  G.stats = { start: performance.now(), spells: 0, hides: 0, notes: new Set(), caught: 0 }
  G.sessionTime = 0
  Object.assign(P, createPlayer())
  P.inv = { batteries: 0, pills: 0 }
  respawnAt(late ? checkpoint : 'start')
  if (late && checkpoint === 'start') { /* already seated */ } else if (late) P.seated = false
  G.invSnapshot = { ...P.inv, battery: P.battery }
  G.mode = 'playing'
  UI.clearStack()
  UI.showScreen(null)
  UI.setHud(true)
  UI.fade(1, 0)
  setTimeout(() => UI.fade(0, 2200), 150)
  input.enabled = true
  if (!touch) void canvas.requestPointerLock?.()
  G.introAt = performance.now()
  G.firstStand = true
}

function showEnding (kind) {
  const e = ENDINGS[kind]
  G.flags.ending = kind
  G.mode = 'ending'
  input.enabled = false
  if (kind === 'brake') { A.brakes(7); G.speedTarget = 0 } else { G.speedTarget = 0.2 }
  document.exitPointerLock?.()
  setTimeout(() => {
    UI.fade(1, 2500)
    setTimeout(() => {
      UI.setHud(false)
      document.getElementById('ending-title').textContent = e.title
      document.getElementById('ending-text').textContent = e.text
      const mins = Math.floor(G.sessionTime / 60)
      document.getElementById('ending-stats').textContent = `${mins} min ${Math.floor(G.sessionTime % 60)} s on the train. ${G.stats.notes.size} of ${NOTE_COUNT} pages read. Hid ${G.stats.hides} times. ${G.stats.spells} dizzy spells.${kind === 'brake' ? ' There is another way this can end.' : ' There is another way this can end.'}`
      UI.showScreen('ending')
      UI.fade(0, 1500)
    }, 2600)
  }, kind === 'brake' ? 4000 : 2500)
}

function quitToTitle () {
  disconnect()
  G.mode = 'title'
  G.coop = false
  input.enabled = false
  document.exitPointerLock?.()
  for (const av of G.avatars.values()) av.model.dispose()
  G.avatars.clear()
  G.registry.clear()
  if (P.hidden) leaveHide()
  UI.setHud(false)
  UI.setSlits(null)
  UI.clearStack()
  UI.showScreen('title')
  UI.fade(0, 800)
  G.paused = false
}

function pause (reason) {
  if (G.mode !== 'playing' || UI.ui.screen === 'pause') return
  if (UI.noteOpen()) return
  G.paused = !net.online
  input.pressed.clear()
  UI.showScreen('pause')
  document.getElementById('pause-note').textContent = net.online ? 'The train keeps moving. In co-op, so does everything else.' : 'The train waits for you.'
  void reason
}

function resume () {
  G.paused = false
  input.pressed.clear()
  UI.showScreen(null)
  if (!touch) void canvas.requestPointerLock?.()
}

// ═════════════ menus ═════════════
function refreshLobby () {
  if (!net.online) return
  const roster = [...net.players.values()].map(p => ({ name: p.name, host: p.id === net.hostId, me: p.id === net.id }))
  UI.setLobby({ code: net.code, roster, isHost: isHost() })
}

async function openRoom () {
  UI.showScreen('lobby', { push: true })
  document.getElementById('host-name-field').style.display = ''
  const nameInput = document.getElementById('host-name')
  nameInput.value = myName
  UI.setLobby({ code: '', roster: [], isHost: true, status: 'Opening a room… (the server may take up to a minute to wake up)' })
  try {
    await connect({ mode: 'create', name: myName })
    UI.setLobby({ status: '' })
    refreshLobby()
  } catch (err) {
    UI.setLobby({ status: err.message })
    document.getElementById('lobby-status').classList.add('bad')
  }
}

async function joinRoom () {
  const name = document.getElementById('join-name').value.trim() || myName
  const code = document.getElementById('join-code').value.trim().toUpperCase()
  if (code.length !== 4) { UI.setStatus('#join-status', 'Room codes are four letters.', true); return }
  setName(name)
  UI.setStatus('#join-status', 'Joining… (the server may take up to a minute to wake up)')
  try {
    await connect({ mode: 'join', code, name: myName })
    UI.setStatus('#join-status', '')
    UI.showScreen('lobby', { push: true })
    document.getElementById('host-name-field').style.display = 'none'
    refreshLobby()
  } catch (err) {
    UI.setStatus('#join-status', err.message, true)
  }
}

function setName (n) {
  myName = n.slice(0, 14)
  try { localStorage.setItem(NAME_KEY, myName) } catch {}
}

document.addEventListener('click', e => {
  const btn = e.target.closest('[data-go]')
  if (!btn) return
  A.initAudio()
  const go = btn.dataset.go
  switch (go) {
    case 'solo': disconnect(); startSession({ coop: false }); break
    case 'host': void openRoom(); break
    case 'join': UI.showScreen('join', { push: true }); document.getElementById('join-name').value = myName; break
    case 'join-go': void joinRoom(); break
    case 'howto': UI.showScreen('howto', { push: true }); break
    case 'settings': UI.showScreen('settings', { push: true }); syncSettingsUi(); break
    case 'back': UI.backScreen(); break
    case 'leave': disconnect(); UI.clearStack(); UI.showScreen('title'); break
    case 'lobby-start':
      if (!isHost()) return
      sendAll('start', {})
      startSession({ coop: true })
      break
    case 'resume': resume(); break
    case 'quit': quitToTitle(); break
    case 'retry': if (isHost()) { G.wipeAt = 0; hostRestart() } break
    case 'again': quitToTitle(); break
    case 'close-note': closeNoteReader(); break
  }
})
document.getElementById('host-name').addEventListener('change', e => {
  setName(e.target.value.trim() || myName)
  if (net.online) {
    const me = net.players.get(net.id)
    if (me) me.name = myName
    sendAll('name', { name: myName })
    refreshLobby()
  }
})
document.getElementById('join-code').addEventListener('keydown', e => { if (e.key === 'Enter') void joinRoom() })

function syncSettingsUi () {
  document.getElementById('set-sens').value = settings.sensitivity
  document.getElementById('set-vol').value = settings.volume
  for (const b of document.querySelectorAll('#set-quality button')) b.setAttribute('aria-pressed', String(b.dataset.q === settings.quality))
  for (const b of document.querySelectorAll('#set-invert button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.invertY)))
}
document.getElementById('set-sens').addEventListener('input', e => { settings.sensitivity = +e.target.value; saveSettings() })
document.getElementById('set-vol').addEventListener('input', e => { settings.volume = +e.target.value; A.setVolume(settings.volume); saveSettings() })
document.getElementById('set-quality').addEventListener('click', e => {
  const q = e.target.dataset.q
  if (!q) return
  settings.quality = q
  saveSettings()
  syncSettingsUi()
  UI.setStatus('#settings-status', 'Graphics change when you next load the page.')
})
document.getElementById('set-invert').addEventListener('click', e => {
  const v = e.target.dataset.v
  if (!v) return
  settings.invertY = v === 'true'
  saveSettings()
  syncSettingsUi()
})

function openNoteReader (id) {
  if (!UI.openNote(id)) return
  G.stats.notes.add(id)
  if (!net.online) G.paused = true
  document.exitPointerLock?.()
  input.enabled = false
}
function closeNoteReader () {
  UI.closeNote()
  G.paused = false
  input.enabled = G.mode === 'playing'
  if (!touch && G.mode === 'playing') void canvas.requestPointerLock?.()
}
window.addEventListener('keydown', e => {
  if (UI.noteOpen() && (e.code === 'KeyE' || e.code === 'Escape' || e.code === 'Space')) { e.preventDefault(); closeNoteReader() }
})

// ═════════════ interaction targeting ═════════════
const tmpV = new THREE.Vector3()
function findInteraction () {
  if (P.down || G.mode !== 'playing') return null
  if (P.hidden) return { kind: 'unhide', label: 'Get out' }
  if (P.seated) return { kind: 'stand', label: 'Stand up' }
  const eye = new THREE.Vector3(P.x, eyeHeight(P), P.z)
  const fwd = new THREE.Vector3(-Math.sin(P.yaw) * Math.cos(P.pitch), Math.sin(P.pitch), -Math.cos(P.yaw) * Math.cos(P.pitch))
  let best = null
  const consider = (pos, reach, label, data, angleLimit = 0.55) => {
    tmpV.set(pos.x, pos.y, pos.z).sub(eye)
    const d = tmpV.length()
    if (d > reach) return
    const ang = tmpV.normalize().angleTo(fwd)
    if (ang > angleLimit + (d < 0.8 ? 0.4 : 0)) return
    const score = d + ang * 2
    if (!best || score < best.score) best = { ...data, label, score }
  }
  const f = G.flags
  for (const it of world.items) {
    if (it.kind !== 'note' && G.taken.has(it.id)) continue
    const label = { fuse: 'Take the fuse', battery: 'Take the battery', pills: 'Take the pills', key: 'Take the key', note: 'Read', wrench: 'Take the valve wrench', tube: 'Take the radio valve tube', coil: 'Take the aerial coil', cell: 'Take the battery cell' }[it.kind]
    consider(it, 1.9, label, { kind: it.kind === 'note' ? 'note' : 'item', id: it.id })
  }
  for (const it of world.interactables) {
    let ok = true
    if (it.id === 'fusePanel') ok = f.powerOut && !f.fusesInstalled
    if (it.id === 'mainLever') ok = f.fusesInstalled && !f.powerOn
    if (it.id === 'brake' || it.id === 'driverSeat') ok = f.final && !f.ending
    if (it.id === 'breaker') ok = true
    if (it.id === 'pressure') ok = f.ch === 2
    if (it.id === 'coupling') ok = f.ch === 3 && !f.coupling
    if (it.valve) {
      ok = f.ch === 2 && !it.closed
      if (ok && f.wrench) { consider(it, 1.9, 'Hold to close the valve', { kind: 'hold', id: it.id, time: 2.4 }, 0.7); continue }
    }
    if (it.id === 'radio' && f.ch === 3 && !f.radioCalled) { consider(it, 1.9, f.parts.length >= 3 ? 'Fit the parts and call the dispatcher' : 'Use the radio', { kind: 'interact', id: it.id }, 0.7); continue }
    if (ok) consider(it, 1.9, it.label, { kind: 'interact', id: it.id }, 0.7)
  }
  for (const d of world.doors) {
    if (!d.locked) continue
    const id = d.carId === 'car7' ? 'door-car7' : d.carId === 'dining' ? 'door-sealed' : 'door-bulkhead'
    const label = d.carId === 'car7' ? (f.key ? 'Unlock Car 7' : 'Try the door') : 'Try the door'
    consider({ x: 0, y: 1.1, z: d.z }, 1.8, label, { kind: 'interact', id }, 0.8)
  }
  for (const s of world.hideSpots) {
    if (Math.hypot(P.x - s.exit.x, P.z - s.exit.z) > 1.15) continue
    consider({ x: s.inside.x, y: 1.1, z: s.inside.z }, 2.0, s.label, { kind: 'hide', id: s.id }, 0.9)
  }
  for (const [id, st] of G.statusById) {
    if (id === myId() || !st.down || st.dead) continue
    const p = G.registry.get(id) ?? G.avatars.get(id)?.target
    if (!p) continue
    if (Math.hypot(p.x - P.x, p.z - P.z) < 1.7) best = { kind: 'revive', id, label: `Hold to help ${playerName(id)} up`, score: 0, time: REVIVE_SECONDS }
  }
  return best
}

function useInteraction (target) {
  if (!target) return
  switch (target.kind) {
    case 'unhide': leaveHide(); break
    case 'stand': input.pressed.add('crouch'); break
    case 'note': openNoteReader(target.id); break
    case 'item': case 'interact': request('interact', { id: target.id }); break
    case 'hide': request('hide', { spot: target.id }); break
  }
}

// ═════════════ visuals per frame ═════════════
const lampPos = new THREE.Vector3()
function updateLamps (dt, now) {
  const mpos = G.monster.visible ? G.monster : null
  for (const [carId, g] of world.lampGroups) {
    let target
    const rearCar = ['dining', 'sleeper', 'mail', 'obs'].includes(carId)
    if (rearCar && (G.flags.uncoupled || !G.flags.powerOn)) target = 0
    else if (G.power === 'on') target = 1
    else if (G.power === 'out') target = carId === 'cab' ? 0.45 : 0
    else target = carId === 'cab' ? 0.6 : 0.42 // failing power at the start
    let level = target
    // failing supply: ragged flicker
    if (G.power === 'flicker' && carId !== 'cab') level *= 0.65 + 0.35 * Math.sin(now * 0.013 + carId.length) * Math.sin(now * 0.0071) + (Math.random() < 0.02 ? -0.5 : 0)
    // it makes the lights stutter when it's close (a fair warning)
    if (mpos && level > 0.05) {
      const near = g.lamps.some(l => Math.abs(l.z - mpos.z) < 9)
      if (near && Math.random() < 0.35) level *= Math.random() * 0.6
    }
    if (G.flicker && G.flicker.car === carId && now < G.flicker.until) level = Math.random() < 0.5 ? 0 : level * 1.4
    if (carId === 'car7' && G.car7Cascade > 0) level = G.car7Cascade > 0.55 ? 0 : level
    if (G.power === 'on' && G.flags.final && Math.random() < 0.002) g.blackout = now + 900 + Math.random() * 900
    if (g.blackout && now < g.blackout) level = 0.04
    g.level += (Math.max(0, level) - g.level) * Math.min(1, dt * 18)
    const cabRed = carId === 'cab' && G.power === 'out'
    g.material.emissive.setHex(cabRed ? 0xff3a22 : g.car.lampColor)
    g.material.emissiveIntensity = g.level * 2.4
    g.haloMat.opacity = g.level * 0.42
    g.haloMat.color.setHex(cabRed ? 0xff3a22 : g.car.lampColor)
  }
  if (G.car7Cascade > 0) G.car7Cascade = Math.max(0, G.car7Cascade - dt * 0.22)
  // point-light pool: nearest lit lamps to the camera
  const cands = []
  for (const g of world.lampGroups.values()) {
    if (g.level < 0.04) continue
    for (const l of g.lamps) {
      const d = Math.abs(l.z - camera.position.z) + Math.abs(l.x - camera.position.x)
      if (d < 26) cands.push({ l, g, d })
    }
  }
  cands.sort((a, b) => a.d - b.d)
  lampPool.forEach((light, i) => {
    const c = cands[i]
    if (!c) { light.intensity = 0; return }
    const red = c.g.car.id === 'cab' && G.power === 'out'
    light.color.setHex(red ? 0xff3a22 : c.g.car.lampColor)
    light.position.set(c.l.x, c.l.y - 0.25, c.l.z)
    light.intensity = c.g.level * (red ? 3.5 : 6.5)
  })
  void lampPos
}

function updateDoors (dt, now) {
  for (const d of world.doors) {
    if (isHost() && G.mode !== 'title') {
      const near = [...G.registry.values()].some(p => !p.hidden && !p.down && Math.abs(p.z - d.z) < 1.7 && Math.abs(p.x) < 1)
      if (!d.locked && near && d.target === 0) hostOpenDoor(d.index)
      const monsterNear = G.monster.visible && Math.abs(G.monster.z - d.z) < 2.2
      if (d.target === 1 && !near && !monsterNear && now - d.lastOpened > 2600) { d.target = 0; fx('door', { i: d.index }) }
      if (near || monsterNear) d.lastOpened = now
    }
    d.open += (d.target - d.open) * Math.min(1, dt * 5)
    d.leaf.position.x = d.open * 0.93
  }
  for (const s of world.hideSpots) {
    if (!s.door) continue
    let off = 0
    if (s.rattle > 0) { s.rattle -= dt; off = Math.sin(now * 0.08) * 0.012 * Math.min(1, s.rattle) }
    if (s.openAnim > 0) { s.openAnim = Math.max(0, s.openAnim - dt * 2.5); off += Math.sin(s.openAnim * Math.PI) * 0.06 }
    s.door.rotation.y = off
  }
}

function updateItems (now) {
  for (const it of world.items) {
    const taken = it.kind !== 'note' && G.taken.has(it.id)
    it.mesh.visible = !taken
    if (it.glint) {
      it.glint.visible = !taken
      it.glint.material.opacity = 0.35 + Math.sin(now * 0.004 + it.x * 3) * 0.2
    }
  }
  world.fuseSlots.forEach(s => { s.visible = G.flags.fusesInstalled })
  world.mainLever.rotation.z += ((G.flags.powerOn ? -0.6 : 0.6) - world.mainLever.rotation.z) * 0.1
  world.brakeHandle.rotation.x += ((G.flags.ending === 'brake' ? 0.6 : -0.5) - world.brakeHandle.rotation.x) * 0.1
  world.flywheel.rotation.x += G.power === 'on' ? 0.25 : 0.0
  for (const it of world.interactables) {
    if (!it.valve) continue
    it.closed = G.flags.valves.includes(it.id)
    it.wheel.rotation.z += ((it.closed ? Math.PI * 3 : 0) - it.wheel.rotation.z) * 0.06
  }
}

function updateMonsterVisual (dt, now) {
  // clients: smooth toward the host's snapshot
  if (!isHost() && G.monsterTarget) {
    const t = G.monsterTarget
    const m = G.monster
    const jump = Math.hypot(t.x - m.x, t.z - m.z)
    const k = jump > 6 ? 1 : Math.min(1, dt * 10)
    m.x += (t.x - m.x) * k
    m.z += (t.z - m.z) * k
    let dy = t.yaw - m.yaw
    while (dy > Math.PI) dy -= Math.PI * 2
    while (dy < -Math.PI) dy += Math.PI * 2
    m.yaw += dy * Math.min(1, dt * 10)
    Object.assign(m, { speed: t.speed, anim: t.anim, alert: t.alert, visible: t.visible, state: t.state })
  }
  if (isHost() && G.mode !== 'title' && G.mode !== 'loading') Object.assign(G.monster, brain.snapshot())
  const m = G.monster
  const root = monsterModel.root
  if (G.jumpscare) {
    // lunge into the camera
    const js = G.jumpscare
    js.t += dt
    const dist = Math.max(0.42, 1.5 - js.t * 4)
    const fwd = new THREE.Vector3(-Math.sin(P.yaw), 0, -Math.cos(P.yaw))
    root.visible = true
    root.position.set(camera.position.x + fwd.x * dist, camera.position.y - 1.95 + Math.sin(js.t * 40) * 0.03, camera.position.z + fwd.z * dist)
    root.rotation.y = Math.atan2(-fwd.x, -fwd.z)
    monsterModel.animate({ speed: 0, state: 'lunge', dt, alert: 1 })
    monsterModel.head.rotation.set(-0.2, (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.5)
    return
  }
  root.visible = m.visible
  if (!m.visible) return
  root.position.set(m.x, 0, m.z)
  root.rotation.y = m.yaw
  const step = monsterModel.animate({ speed: m.speed, state: m.anim, dt, alert: m.alert })
  if (step) {
    const d = Math.hypot(m.x - P.x, m.z - P.z)
    if (d < 45) A.creatureStep({ x: m.x, y: 0.3, z: m.z }, m.anim === 'run' ? 1 : 0.6)
  }
  void now
}

function updateAvatars (dt) {
  for (const [id, av] of G.avatars) {
    const t = av.target
    if (!t) continue
    const jump = Math.hypot(t.x - av.x, t.z - av.z)
    const k = jump > 4 ? 1 : Math.min(1, dt * 12)
    const ox = av.x, oz = av.z
    av.x += (t.x - av.x) * k
    av.z += (t.z - av.z) * k
    let dy = t.yaw - av.yaw
    while (dy > Math.PI) dy -= Math.PI * 2
    while (dy < -Math.PI) dy += Math.PI * 2
    av.yaw += dy * Math.min(1, dt * 12)
    const v = jump > 4 ? 0 : Math.hypot(av.x - ox, av.z - oz) / Math.max(dt, 1e-3)
    av.speed += (v - av.speed) * Math.min(1, dt * 8)
    const st = G.statusById.get(id)
    av.model.setName(playerName(id))
    av.model.update(dt, { x: av.x, z: av.z, yaw: av.yaw, pitch: t.pitch, speed: av.speed, crouch: t.crouch, down: !!st?.down, hidden: !!t.hidden, gone: !!st?.dead, flashlight: t.flashlight })
  }
}

// ═════════════ camera ═════════════
let trainJolt = 0
let nextJolt = 6
function updateCamera (dt, now) {
  const t = now / 1000
  if (G.mode === 'title' || G.mode === 'loading') {
    // slow drift down the dark passenger car
    const z = -23 - (t * 0.35) % 13
    camera.position.set(0.02 + Math.sin(t * 0.3) * 0.05, 1.5 + Math.sin(t * 0.8) * 0.01, z)
    camera.rotation.set(-0.04 + Math.sin(t * 0.25) * 0.02, Math.sin(t * 0.18) * 0.12, Math.sin(t * 0.9) * 0.008)
    return
  }
  nextJolt -= dt
  if (nextJolt <= 0) { trainJolt = 1; nextJolt = 6 + Math.random() * 10 }
  trainJolt = Math.max(0, trainJolt - dt * 2.5)
  let x = P.x, z = P.z, y = eyeHeight(P), yaw = P.yaw, pitch = P.pitch
  if (P.hidden) {
    const spot = world.hideSpots.find(s => s.id === P.hidden)
    if (spot) {
      x = spot.inside.x + Math.sin(spot.yaw) * -0.15
      z = spot.inside.z + Math.cos(spot.yaw) * -0.15
      y = 1.55
      let dy = P.yaw - spot.yaw
      while (dy > Math.PI) dy -= Math.PI * 2
      while (dy < -Math.PI) dy += Math.PI * 2
      dy = Math.max(-0.7, Math.min(0.7, dy))
      P.yaw = spot.yaw + dy
      yaw = P.yaw
      pitch = Math.max(-0.5, Math.min(0.4, pitch))
    }
  }
  if (P.down) { y = 0.28; pitch = 0.2 }
  const bob = P.moving ? Math.sin(P.bob * Math.PI) * (P.sprinting ? 0.045 : 0.025) : 0
  const swayAmt = P.spellLevel
  const roll = Math.sin(t * 0.9) * 0.006 + Math.sin(t * 2.3) * 0.003 + swayAmt * (Math.sin(t * 1.1) * 0.13 + Math.sin(t * 2.7) * 0.05) + (P.down ? 1.1 : 0)
  const shake = P.shake * 0.04 + trainJolt * 0.012
  camera.position.set(x + (Math.random() - 0.5) * shake, y + bob + (Math.random() - 0.5) * shake, z + (Math.random() - 0.5) * shake)
  camera.rotation.set(pitch + swayAmt * Math.sin(t * 0.8) * 0.05 + P.lurch * 0.1, yaw + swayAmt * Math.sin(t * 0.6) * 0.05, roll)
  camera.fov = 72 + swayAmt * (6 + Math.sin(t * 1.3) * 3) + (P.sprinting ? 4 : 0)
  camera.updateProjectionMatrix()
  P.shake = Math.max(0, P.shake - dt * 1.5)
}

// ═════════════ main loop ═════════════
let last = performance.now()
let frames = 0
function frame () {
  requestAnimationFrame(frame)
  const now = performance.now()
  const dt = Math.min(0.05, (now - last) / 1000)
  last = now
  frames++
  window.__frames = frames

  if (G.mode !== 'title' && G.mode !== 'loading' && !G.paused) step(dt, now)
  else if (G.mode === 'title' || G.mode === 'loading') titleStep(dt, now)

  updateCamera(dt, now)
  updateDoors(dt, now)
  updateLamps(dt, now)
  updateItems(now)
  updateMonsterVisual(dt, now)
  updateAvatars(dt)
  world.outside.update(dt, G.speed * 22)
  G.speed += (G.speedTarget - G.speed) * Math.min(1, dt * 0.25)

  // lightning
  if (G.lightning > 0) {
    G.lightning = Math.max(0, G.lightning - dt * 2.2)
    const l = G.lightning > 0.7 || (G.lightning > 0.3 && G.lightning < 0.45) ? 1 : G.lightning * 0.3
    world.outside.flash(l)
    hemi.intensity = 0.32 + l * 2.5
    post.uniforms.lightning.value = l * 0.6
  } else { hemi.intensity = 0.32; post.uniforms.lightning.value = 0 }

  // flashlight
  const flick = P.battery < 15 ? (Math.random() < 0.08 ? 0.15 : 1) : 1
  const monsterClose = G.monster.visible && Math.hypot(G.monster.x - P.x, G.monster.z - P.z) < 6
  const mFlick = monsterClose && Math.random() < 0.3 ? Math.random() * 0.5 : 1
  flashlight.intensity = P.flashlight && !P.hidden && !P.down ? 38 * flick * mFlick * (0.55 + Math.min(1, P.battery / 40) * 0.45) : 0

  // post
  post.uniforms.time.value = now / 1000
  post.uniforms.dizzy.value = G.mode === 'playing' || G.mode === 'caught' ? P.spellLevel : 0
  post.uniforms.fear.value = G.fear
  post.uniforms.flash.value = G.jumpscare ? 0.5 + Math.random() * 0.35 : Math.max(0, post.uniforms.flash.value - dt * 1.5)

  renderer.setRenderTarget(rt)
  renderer.render(scene, camera)
  renderer.setRenderTarget(null)
  renderer.render(postScene, postCam)
}

function titleStep (dt, now) {
  G.power = 'flicker'
  // rare glimpse at the far end of the car
  if (!G.titleGlimpse || now > G.titleGlimpse.until + 9000 + Math.random() * 30000) {
    G.titleGlimpse = { until: now + 1400 }
  }
  const glimpse = now < G.titleGlimpse.until && now > G.titleGlimpse.until - 1000
  G.monster.visible = glimpse
  if (glimpse) Object.assign(G.monster, { x: 0.2, z: -39.2, yaw: 0, speed: 0, anim: 'idle', alert: 0 })
}

function step (dt, now) {
  const look = consumeLook()
  G.sessionTime += dt
  const events = []

  // ── local input ──
  const canAct = G.mode === 'playing' && input.enabled && !UI.noteOpen()
  if (consumePressed('pause')) { if (G.mode === 'playing') pause() }
  if (canAct) {
    if (consumePressed('flashlight') && !P.hidden && !P.down) {
      if (P.battery <= 0 && P.inv.batteries > 0) { P.inv.batteries--; P.battery = 100; UI.toast('Fresh battery in.') }
      P.flashlight = !P.flashlight && P.battery > 0
      A.click({ x: P.x, y: 1.4, z: P.z })
    }
    if (consumePressed('pills')) {
      if (takePills(P)) { UI.toast('You swallow a pill. The world settles.'); A.gasp() } else if (P.spell > 0) UI.toast('No pills left.')
    }
  } else { input.pressed.delete('flashlight'); input.pressed.delete('pills') }

  const crouchPressed = canAct && consumePressed('crouch')
  const wasSeated = P.seated
  updatePlayer(P, dt, {
    input: canAct ? input : { move: { x: 0, y: 0 }, held: {} },
    look: canAct || P.hidden ? look : { x: 0, y: 0 },
    world, settings, events, crouchPressed,
    monsterDanger: (G.monster.state === 'chase' || G.monster.state === 'hunt') && Math.hypot(G.monster.x - P.x, G.monster.z - P.z) < 14,
    adrenaline: G.flags.chase > 0,
    inLitArea: (() => { const c = carAt(P.z); const g = c && world.lampGroups.get(c.id); return !!g && g.level > 0.35 })(),
  })
  if (wasSeated && !P.seated && G.firstStand) {
    // standing up after hours at the controls: the first dizzy spell
    G.firstStand = false
    P.warning = 0.6
    setTimeout(() => UI.toast(touch ? 'Dizzy. Hold Steady while next to something solid.' : 'Dizzy. Hold Q while next to something solid to steady yourself.', 5000), 900)
  }

  // ── flashlight battery ──
  if (P.flashlight) {
    P.battery = Math.max(0, P.battery - dt * 0.6)
    if (P.battery <= 0) {
      if (P.inv.batteries > 0) { P.inv.batteries--; P.battery = 100; UI.toast('The light dies. You swap in a fresh battery.') } else { P.flashlight = false; UI.toast('The flashlight is dead. Find a battery.') }
    }
  }

  // ── events from the player ──
  for (const ev of events) {
    if (ev.type === 'step') {
      const surface = carAt(P.z)?.surface ?? 'metal'
      A.footstep({ x: P.x, y: 0.1, z: P.z }, { loud: ev.loud, surface })
      noise(ev.x, ev.z, ev.radius)
    } else if (ev.type === 'stumble') {
      A.creatureStep({ x: P.x + 0.4, y: 0.8, z: P.z }, 0.45)
      noise(ev.x, ev.z, ev.radius)
    } else if (ev.type === 'spellWarning') {
      A.heartbeat(0.5)
    } else if (ev.type === 'spellStart') {
      G.stats.spells++
      A.gasp()
    }
  }

  // ── interaction ──
  const target = canAct ? findInteraction() : null
  if (target?.kind === 'revive' || target?.kind === 'hold') {
    const holding = input.held.interact || input.pressed.has('interact')
    if (G.holdId !== target.id) { G.holdId = target.id; G.reviveProgress = 0 }
    G.reviveProgress = holding ? G.reviveProgress + dt / target.time : 0
    input.pressed.delete('interact')
    UI.setPrompt(`${target.label}${G.reviveProgress > 0 ? ` ${Math.floor(G.reviveProgress * 100)}%` : ''}`)
    if (holding && target.kind === 'hold' && Math.random() < dt * 3) noise(P.x, P.z, 3)
    if (G.reviveProgress >= 1) {
      G.reviveProgress = 0
      if (target.kind === 'revive') request('revive', { target: target.id })
      else request('interact', { id: target.id })
    }
  } else {
    G.reviveProgress = 0
    UI.setPrompt(target?.label ?? '')
    if (canAct && consumePressed('interact')) useInteraction(target)
  }
  input.pressed.delete('interact')

  // ── host simulation ──
  if (isHost()) hostStep(dt, now)

  // ── send our state ──
  if (net.online && now - G.lastStateSend > 66) {
    G.lastStateSend = now
    sendAll('state', {
      x: +P.x.toFixed(2), z: +P.z.toFixed(2), yaw: +P.yaw.toFixed(2), pitch: +P.pitch.toFixed(2), crouch: P.crouch, flashlight: P.flashlight,
      hidden: P.hidden, hiddenSeen: P.hiddenSeen, holdingBreath: P.holdingBreath, seated: P.seated, inCover: inCover(),
    })
  }

  // ── fear, heartbeat, breathing ──
  const m = G.monster
  const md = m.visible ? Math.hypot(m.x - P.x, m.z - P.z) : 99
  let fearTarget = m.visible && md < 16 && !closedDoorBetween(m.z, P.z) ? (1 - md / 16) * (m.state === 'chase' ? 1 : 0.6) : 0
  if (P.hidden && G.hiddenSpot && world.hideSpots.find(s => s.id === G.hiddenSpot)?.rattle > 0) fearTarget = 1
  G.fear += (fearTarget - G.fear) * Math.min(1, dt * (fearTarget > G.fear ? 3 : 0.4))
  P.fear = G.fear
  if (G.fear > 0.25 && now > G.heartbeatAt) {
    A.heartbeat(0.25 + G.fear * 0.5)
    G.heartbeatAt = now + (1100 - G.fear * 600)
  }
  if (G.breath) G.breath.setLevel(P.holdingBreath ? 0 : 0.4 + G.fear)

  // ── audio ──
  const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
  A.updateListener(camera.position, fwd)
  const cargoOpen = Math.max(0, 1 - Math.abs(P.z + 49.4) / 5)
  const chasing = G.flags.chase > 0 || (G.monster.state === 'chase' && md < 20) || G.monster.state === 'hunt'
  A.updateAmbience(dt, { speed: G.speed, fear: G.fear, outsideOpen: cargoOpen, chase: chasing })

  updateHud()
}

const closedDoorBetween = (z0, z1) => world.doors.some(d => d.z < Math.max(z0, z1) && d.z > Math.min(z0, z1) && d.open < 0.5)
const inCover = () => world.covers.some(c => P.x > c.minX - 0.6 && P.x < c.maxX + 0.6 && P.z > c.minZ - 0.6 && P.z < c.maxZ + 0.6)

function noise (x, z, r) {
  if (isHost()) brain.hear(x, z, r)
  else sendHost('noise', { x: +x.toFixed(1), z: +z.toFixed(1), r })
}

function hostStep (dt, now) {
  const f = G.flags
  // our own entry in the registry
  G.registry.set(myId(), {
    id: myId(), x: P.x, z: P.z, crouch: P.crouch, flashlight: P.flashlight, hidden: P.hidden, hiddenSeen: P.hiddenSeen,
    holdingBreath: P.holdingBreath, down: P.down || !!G.statusById.get(myId())?.down, alive: true, seated: P.seated, inCover: inCover(),
  })
  const players = [...G.registry.values()].map(p => ({ ...p, down: !!G.statusById.get(p.id)?.down }))
  brain.update(dt, players)

  // bleed-out timers and wipes
  for (const [id, st] of G.statusById) {
    if (st.down && !st.dead) { st.downLeft -= dt; if (st.downLeft <= 0) { st.dead = true; st.downLeft = 0 } }
    void id
  }
  if ([...G.statusById.values()].some(s => s.down)) hostCheckWipe()
  if (G.wipeAt && now > G.wipeAt) {
    G.wipeAt = 0
    const solo = !net.online || net.players.size <= 1
    if (!solo) hostRestart()
  }

  // ── story triggers ──
  const anyone = fn => players.some(p => !p.down && fn(p))
  const t = (now - G.introAt) / 1000
  if (!f.knocked && t > 4) { f.knocked = true; fx('knock') }
  if (!f.powerOut && anyone(p => p.z < -6.2)) triggerPowerOut()
  if (f.powerOut && !f.crossed && anyone(p => p.z < -21.8)) {
    f.crossed = true
    brain.placeAt(-1.0, -38.6, 'scripted')
    brain.script([{ x: 1.0, z: -38.8 }, { x: 0, z: -43 }], 3.4, () => {
      brain.visible = false
      brain.state = 'dormant'
      G.scripts.monsterWakeAt = now + 22000
    })
    fx('crossing')
  }
  if (f.crossed && !f.monsterActive && G.scripts.monsterWakeAt && now > G.scripts.monsterWakeAt) {
    f.monsterActive = true
    brain.placeAt(1.0, -104, 'patrol')
  }
  // if players skip ahead, wake it anyway
  if (f.powerOut && !f.monsterActive && !f.crossed && anyone(p => p.z < -41)) { f.monsterActive = true; f.crossed = true; brain.placeAt(1, -100, 'patrol') }
  if (!f.car7Visited && anyone(p => p.z < -61)) { f.car7Visited = true; fx('car7') }
  if (f.final && !f.inCab && anyone(p => p.z > -3.6)) { f.inCab = true }
  // chase scenes: when everyone still standing is past the line, the door slams behind them
  const runners = players.filter(p => !p.down && !G.statusById.get(p.id)?.dead)
  if (f.chase === 1) {
    const behindDoor = !brain.visible || brain.z > -154.4
    if (runners.length && behindDoor && runners.every(p => p.z < -157.2 || p.hidden)) { if (runners.some(p => !p.hidden)) endChase1(true); else if (brain.state !== 'hunt') endChase1(false) }
    else if (brain.state !== 'hunt' && brain.state !== 'scripted' && performance.now() - (G.chaseStart ?? 0) > 20000) endChase1(false)
  }
  if (f.chase === 2) {
    if (brain.state === 'hunt' || brain.state === 'scripted') G.huntLostAt = 0
    else if (brain.visible) {
      // lost them (everyone hid, or it caught someone): it climbs back onto the roof
      G.huntLostAt = G.huntLostAt || now
      if (now - G.huntLostAt > 12000) { brain.state = 'dormant'; brain.visible = false; fx('roofSteps', { z0: brain.z, z1: brain.z + 30 }) }
    }
    const behindDoor = !brain.visible || brain.z < -137
    if (runners.length && behindDoor && runners.every(p => p.z > -134.4 || p.hidden) && runners.some(p => !p.hidden)) endChase2()
  }
  if (f.ch === 2 && !f.rearVisited && anyone(p => p.z < -137)) { f.rearVisited = true; fx('creature', { kind: 'whisper', x: 0, z: -150 }) }
  // chapter 2: the brakes are failing; every so often the whole train lurches
  if (f.ch === 2 && !f.pressureOk) {
    G.scripts.nextLurch = (G.scripts.nextLurch ?? 20) - dt
    if (G.scripts.nextLurch <= 0) { G.scripts.nextLurch = 25 + Math.random() * 20; fx('lurch') }
  }
  if (G.finalTimer != null && !f.ending) {
    G.finalTimer -= dt
    if (G.finalTimer <= 0) hostEnding('arrive')
  }

  // ambience: distant sounds when it's far away
  if (f.powerOut && !f.ending) {
    G.scripts.nextAmbient -= dt
    if (G.scripts.nextAmbient <= 0) {
      G.scripts.nextAmbient = 22 + Math.random() * 28
      const p = players[Math.floor(Math.random() * players.length)]
      if (p) {
        const z = p.z + (Math.random() < 0.5 ? -1 : 1) * (8 + Math.random() * 10)
        const kinds = ['drag', 'knock', f.car7Visited ? 'whisper' : 'drag']
        fx('creature', { kind: kinds[Math.floor(Math.random() * kinds.length)], x: (Math.random() - 0.5) * 2.4, z })
      }
    }
    G.scripts.nextLightning -= dt
    if (G.scripts.nextLightning <= 0) { G.scripts.nextLightning = 25 + Math.random() * 35; fx('lightning') }
  }

  // ── broadcast the world ──
  if (net.online && now - G.lastWorldSend > 100) {
    G.lastWorldSend = now
    sendAll('world', {
      m: brain.snapshot(),
      doors: world.doors.map(d => [d.target, d.locked ? 1 : 0]),
      flags: f, taken: [...G.taken], power: G.power, timer: G.finalTimer, speed: G.speedTarget, cp: G.checkpoint,
      status: Object.fromEntries([...G.statusById].map(([id, s]) => [id, { down: s.down, downLeft: +s.downLeft.toFixed(1), dead: s.dead }])),
    })
  }
}

function updateHud () {
  const f = G.flags
  let obj = OBJECTIVES.wake
  let extra = ''
  if (P.seated) obj = OBJECTIVES.wake
  else if (!f.powerOut) obj = OBJECTIVES.noise
  else if (!f.fusesInstalled) {
    obj = f.fuses >= 3 ? OBJECTIVES.install : OBJECTIVES.power
    extra = `Fuses found: ${f.fuses} of 3.${!f.car7Open ? (f.key ? ' You have the key to Car 7.' : ' Car 7 is locked; find the conductor\'s key.') : ''}`
  } else if (!f.powerOn) obj = OBJECTIVES.lever
  else if (f.chase === 1 || (f.ch === 1)) obj = OBJECTIVES.chase1
  else if (f.ch === 2) {
    if (!f.wrench) obj = OBJECTIVES.wrench
    else if (f.valves.length < 4) { obj = OBJECTIVES.valves; extra = `Valves closed: ${f.valves.length} of 4.` }
    else obj = OBJECTIVES.pressure
  } else if (f.ch === 3) {
    if (f.chase === 2 || f.coupling) obj = OBJECTIVES.chase2
    else if (f.radioCalled) obj = OBJECTIVES.coupling
    else if (f.parts.length < 3) { obj = OBJECTIVES.parts; extra = `Radio parts found: ${f.parts.length} of 3.` }
    else obj = OBJECTIVES.radio
  } else if (f.inCab) obj = OBJECTIVES.choice
  else obj = OBJECTIVES.final
  if (f.ending) obj = null
  if (obj !== G.lastObjective) { if (G.lastObjective && obj) A.objectiveChime(); G.lastObjective = obj }
  UI.setObjective(obj, extra)
  UI.setTimer(G.finalTimer != null && !f.ending ? G.finalTimer : null)
  UI.setInventory({ fuses: f.ch === 1 ? f.fuses : null, key: f.ch === 1 ? f.key : null, batteries: P.inv.batteries, pills: P.inv.pills, coop: G.coop, extra: f.ch === 2 ? [['Wrench', f.wrench ? 'yes' : 'no']] : f.ch === 3 ? [['Radio parts', `${f.parts.length}/3`]] : [] })
  UI.setBattery(P.battery, P.flashlight)
  const state = P.spell > 0 ? 'spell' : P.warning > 0 ? 'warn' : ''
  const wobble = Math.sin(performance.now() / 260) * (state === 'warn' ? 0.25 : 0)
  UI.setLevel(Math.max(-1, Math.min(1, (P.balance / 100) * (Math.sin(performance.now() / 900) >= 0 ? 1 : -1) * 0.9 + wobble)), state)
  const spotRattle = P.hidden && world.hideSpots.find(s => s.id === P.hidden)?.rattle > 0
  UI.setBreath(!!P.hidden, P.breath, spotRattle)
  if (G.coop && net.online) {
    UI.setTeam([...net.players.values()].map(p => {
      const st = G.statusById.get(p.id)
      return { name: p.id === net.id ? `${p.name} (you)` : p.name, down: !!st?.down, dead: !!st?.dead, downLeft: st?.downLeft ?? 0 }
    }))
  } else UI.setTeam([])
}

// ═════════════ boot ═════════════
initInput(canvas, { onPause: reason => { if (reason === 'unlock' && UI.noteOpen()) return; pause(reason) } })
if (touch) initTouchControls(document.getElementById('touch'))
window.addEventListener('keydown', e => { if (e.code === 'KeyE') input.held.interact = true })
window.addEventListener('keyup', e => { if (e.code === 'KeyE') input.held.interact = false })
input.pressed.clear()

bindFullscreenButtons()
G.mode = 'title'
UI.setLoading('')
UI.showScreen('title')
UI.fade(0, 1600)
requestAnimationFrame(frame)

// Debug / test hooks (harmless in production)
window.__vf = { G, P, world, brain, renderer, scene, camera, input, hostCatch, net, startSession, hostInteract, fx, setCheckpoint, triggerPowerOut, startFinal, startChase1, endChase1, runChase2, endChase2, myId, request }
