// Co-op networking: a thin client for the relay on the Render server (path /vertigo).
// One player is the host and runs the creature and the world; everyone sends their own position.
import { coopServerUrl } from './config.js'

export const net = {
  ws: null,
  connected: false,
  id: null,
  code: null,
  hostId: null,
  players: new Map(), // id -> { id, name }
  handlers: new Map(),
  get isHost () { return !this.ws || this.hostId === this.id },
  get online () { return !!this.ws && this.connected },
}

export function on (type, handler) {
  if (!net.handlers.has(type)) net.handlers.set(type, new Set())
  net.handlers.get(type).add(handler)
}

const emit = (type, payload, from) => {
  for (const h of net.handlers.get(type) ?? []) {
    try { h(payload, from) } catch (err) { console.error('[net] handler failed', type, err) }
  }
}

const raw = msg => { if (net.ws?.readyState === WebSocket.OPEN) net.ws.send(JSON.stringify(msg)) }

/** Game message to everyone else */
export const sendAll = (type, data = {}) => raw({ t: 'all', d: { type, ...data } })
/** Game message to the host only (no-op when we are the host) */
export const sendHost = (type, data = {}) => { if (!net.isHost) raw({ t: 'to-host', d: { type, ...data } }) }
/** Host → one player */
export const sendTo = (id, type, data = {}) => raw({ t: 'to', id, d: { type, ...data } })

/**
 * Connect and create or join a room.
 * mode: 'create' | 'join'. Resolves with { code } or rejects with a readable message.
 */
export function connect ({ mode, code, name }) {
  disconnect()
  return new Promise((resolve, reject) => {
    let settled = false
    let ws
    try {
      ws = new WebSocket(coopServerUrl())
    } catch {
      reject(new Error("Couldn't reach the co-op server."))
      return
    }
    net.ws = ws
    const fail = message => { if (!settled) { settled = true; reject(new Error(message)) } }
    const timer = setTimeout(() => { fail('The co-op server took too long to answer. If it was asleep, try again in a minute.'); ws.close() }, 25000)
    ws.addEventListener('open', () => {
      net.connected = true
      raw(mode === 'create' ? { t: 'create', name } : { t: 'join', code: String(code || '').toUpperCase().trim(), name })
    })
    ws.addEventListener('message', e => {
      let msg
      try { msg = JSON.parse(e.data) } catch { return }
      switch (msg.t) {
        case 'welcome':
          net.id = msg.id
          net.code = msg.code
          net.hostId = msg.hostId
          net.players = new Map(msg.players.map(p => [p.id, p]))
          clearTimeout(timer)
          if (!settled) { settled = true; resolve({ code: msg.code }) }
          emit('roster', [...net.players.values()])
          break
        case 'peer-join':
          net.players.set(msg.id, { id: msg.id, name: msg.name })
          emit('peerJoin', { id: msg.id, name: msg.name })
          emit('roster', [...net.players.values()])
          break
        case 'peer-leave':
          net.players.delete(msg.id)
          emit('peerLeave', { id: msg.id })
          emit('roster', [...net.players.values()])
          break
        case 'host':
          net.hostId = msg.hostId
          emit('hostChange', { hostId: msg.hostId, isHost: net.isHost })
          break
        case 'msg':
          if (msg.d?.type) emit(msg.d.type, msg.d, msg.from)
          break
        case 'error':
          clearTimeout(timer)
          fail(msg.message || 'The co-op server refused the request.')
          emit('error', msg.message)
          break
      }
    })
    ws.addEventListener('close', () => {
      clearTimeout(timer)
      const was = net.connected
      net.connected = false
      fail("Couldn't connect to the co-op server.")
      if (was) emit('disconnected')
    })
    ws.addEventListener('error', () => fail("Couldn't connect to the co-op server."))
  })
}

export function disconnect () {
  if (net.ws) {
    const ws = net.ws
    net.ws = null
    try { ws.close() } catch {}
  }
  net.connected = false
  net.id = null
  net.code = null
  net.hostId = null
  net.players = new Map()
}
