// The local player: movement, collision, crouching, flashlight, vertigo, hiding and breath.
import {
  WALK_SPEED, SPRINT_SPEED, CROUCH_SPEED, PLAYER_RADIUS, EYE_HEIGHT, CROUCH_EYE_HEIGHT,
} from './config.js'
import { HALF_W } from './world.js'

export function createPlayer () {
  return {
    x: 0.4, z: 2.3, yaw: Math.PI, pitch: -0.05,
    crouch: false, crouchT: 0, crouchSince: 0,
    seated: true,
    moving: false, sprinting: false, speed: 0,
    flashlight: false, battery: 100,
    inv: { batteries: 0, pills: 0 },
    // vertigo
    balance: 12, // 0 = steady, 100 = a spell hits
    spell: 0, // seconds left in the current spell (0 = none)
    spellLevel: 0, // smoothed 0..1 visual intensity
    warning: 0, // seconds left in the pre-spell warning
    sway: 0, swayPhase: 0, drift: { x: 0, z: 0 }, lurch: 0,
    steadying: false, nearSupport: false,
    // hiding
    hidden: null, hiddenSeen: false, breath: 1, holdingBreath: false,
    // health / co-op
    down: false, downTimer: 0, alive: true,
    stepDist: 0, bob: 0,
    fear: 0,
    shake: 0,
  }
}

const collideCircle = (p, colliders, doors) => {
  for (let iter = 0; iter < 3; iter++) {
    let pushed = false
    for (const c of colliders) {
      if (c.doorIndex !== undefined && doors[c.doorIndex].open > 0.75) continue
      // closest point on box
      const cx = Math.max(c.minX, Math.min(p.x, c.maxX))
      const cz = Math.max(c.minZ, Math.min(p.z, c.maxZ))
      const dx = p.x - cx, dz = p.z - cz
      const d2 = dx * dx + dz * dz
      if (d2 >= PLAYER_RADIUS * PLAYER_RADIUS) continue
      if (d2 > 1e-8) {
        const d = Math.sqrt(d2)
        const push = PLAYER_RADIUS - d
        p.x += (dx / d) * push
        p.z += (dz / d) * push
      } else {
        // centre inside the box: push out along the shallowest axis
        const opts = [[c.minX - PLAYER_RADIUS - p.x, 0], [c.maxX + PLAYER_RADIUS - p.x, 0], [0, c.minZ - PLAYER_RADIUS - p.z], [0, c.maxZ + PLAYER_RADIUS - p.z]]
        opts.sort((a, b) => Math.abs(a[0] + a[1]) - Math.abs(b[0] + b[1]))
        p.x += opts[0][0]; p.z += opts[0][1]
      }
      pushed = true
    }
    if (!pushed) break
  }
}

const distToBox = (x, z, c) => {
  const cx = Math.max(c.minX, Math.min(x, c.maxX))
  const cz = Math.max(c.minZ, Math.min(z, c.maxZ))
  return Math.hypot(x - cx, z - cz)
}

/**
 * Per-frame update. ctx: { input, look, world, doors, monsterDanger, inLitArea, events }
 * events receives { type: 'noise', x, z, radius } and { type: 'stumble' } etc.
 */
export function updatePlayer (p, dt, ctx) {
  const { input, look, world, settings } = ctx
  const events = ctx.events

  // ── look ──
  const sens = 0.0022 * (settings?.sensitivity ?? 1)
  const swayDamp = p.spell > 0 ? 0.65 : 1
  p.yaw -= look.x * sens * swayDamp
  p.pitch -= look.y * sens * swayDamp * (settings?.invertY ? -1 : 1)
  p.pitch = Math.max(-1.35, Math.min(1.35, p.pitch))

  if (p.down || !p.alive) { p.moving = false; p.speed = 0; return }

  // hidden: no movement, breath management
  if (p.hidden) {
    p.moving = false
    p.speed = 0
    p.holdingBreath = input.held.breath && p.breath > 0
    if (p.holdingBreath) p.breath = Math.max(0, p.breath - dt / 7)
    else p.breath = Math.min(1, p.breath + dt / 4)
    p.balance = Math.max(0, p.balance - dt * 10)
    p.spell = Math.max(0, p.spell - dt * 2)
    p.spellLevel += (0 - p.spellLevel) * Math.min(1, dt * 2)
    return
  }
  p.holdingBreath = false
  p.breath = Math.min(1, p.breath + dt / 4)

  // ── crouch / stand ──
  if (ctx.crouchPressed) {
    if (p.seated) { p.seated = false } else {
      p.crouch = !p.crouch
      if (!p.crouch) {
        // standing up fast makes the head spin (more so after a long crouch)
        const long = Math.min(1, (performance.now() - p.crouchSince) / 2500)
        p.balance += 8 + long * 10
      } else p.crouchSince = performance.now()
    }
  }
  p.crouchT += ((p.crouch ? 1 : 0) - p.crouchT) * Math.min(1, dt * 9)

  // ── movement ──
  let mx = input.move.x, my = input.move.y
  const len = Math.hypot(mx, my)
  if (len > 1) { mx /= len; my /= len }
  if (p.seated && (len > 0.2)) { p.seated = false; ctx.onStandUp?.() }
  if (p.seated) { p.moving = false; p.speed = 0; return }

  p.steadying = input.held.steady
  const wantSprint = input.held.sprint && !p.crouch && my > 0.3 && p.spell <= 0
  let speed = p.crouch ? CROUCH_SPEED : wantSprint ? SPRINT_SPEED : WALK_SPEED
  if (p.steadying) speed *= 0.25
  if (p.spell > 0) speed *= 0.45
  const fx = -Math.sin(p.yaw), fz = -Math.cos(p.yaw)
  const rx = Math.cos(p.yaw), rz = -Math.sin(p.yaw)
  let vx = (fx * my + rx * mx) * speed
  let vz = (fz * my + rz * mx) * speed
  // vertigo drift: the floor seems to tilt
  if (p.spell > 0) {
    vx += p.drift.x * 0.9
    vz += p.drift.z * 0.9
  }
  const ox = p.x, oz = p.z
  p.x += vx * dt
  p.z += vz * dt
  collideCircle(p, world.colliders, world.doors)
  const moved = Math.hypot(p.x - ox, p.z - oz)
  p.speed = moved / Math.max(dt, 1e-4)
  p.moving = len > 0.15 && p.speed > 0.2
  p.sprinting = wantSprint && p.moving

  // ── footsteps → noise the creature can hear ──
  if (p.moving) {
    p.stepDist += moved
    p.bob += moved * (p.sprinting ? 2.6 : 3.2)
    const stride = p.sprinting ? 0.75 : p.crouch ? 0.55 : 0.65
    if (p.stepDist >= stride) {
      p.stepDist = 0
      const radius = p.sprinting ? 13 : p.crouch ? 1.2 : 5.5
      events.push({ type: 'step', x: p.x, z: p.z, radius, loud: p.sprinting ? 0.9 : p.crouch ? 0.25 : 0.55 })
    }
  }

  // ── near something to hold on to? (walls, seats, rails) ──
  p.nearSupport = Math.abs(p.x) > HALF_W - 0.6 || world.colliders.some(c => c.doorIndex === undefined && distToBox(p.x, p.z, c) < 0.55)

  // ── vertigo ──
  const danger = ctx.monsterDanger // creature hunting this player nearby: no random spells (fair)
  if (p.sprinting) p.balance += dt * (ctx.adrenaline ? 1.5 : 7) // adrenaline: chase scenes don't punish running
  if (!ctx.inLitArea && !p.flashlight) p.balance += dt * 1.2
  p.balance += p.fear * dt * 2.5
  const recover = p.spell > 0 ? 0 : (p.steadying && p.nearSupport ? 14 : p.crouch && !p.moving ? 12 : p.moving ? 2.5 : 5)
  p.balance = Math.max(0, p.balance - recover * dt)

  if (p.warning > 0) {
    p.warning -= dt
    if (p.warning <= 0) {
      p.spell = 5 + Math.random() * 3
      p.balance = Math.max(p.balance, 85)
      const a = Math.random() * Math.PI * 2
      p.drift = { x: Math.cos(a) * 0.6, z: Math.sin(a) * 0.6 }
      events.push({ type: 'spellStart' })
    }
  } else if (p.spell <= 0) {
    const random = p.balance > 55 && !danger && Math.random() < dt * 0.05
    if (p.balance >= 100 || random) {
      p.warning = 2.2
      events.push({ type: 'spellWarning' })
    }
  }
  if (p.spell > 0) {
    const steady = p.steadying && p.nearSupport
    p.spell -= dt * (steady ? 2.6 : p.crouch && !p.moving ? 1.8 : 1)
    p.balance = Math.max(30, p.balance - dt * (steady ? 18 : 6))
    // the drift wanders
    const a = Math.atan2(p.drift.z, p.drift.x) + (Math.random() - 0.5) * dt * 3
    const mag = steady ? 0.15 : 0.6
    p.drift = { x: Math.cos(a) * mag, z: Math.sin(a) * mag }
    // moving while dizzy can make you stumble into things (noise)
    if (p.moving && Math.random() < dt * 0.35) {
      p.lurch = 1
      events.push({ type: 'stumble', x: p.x, z: p.z, radius: 7 })
    }
    if (p.spell <= 0) { p.spell = 0; events.push({ type: 'spellEnd' }) }
  }
  const target = p.spell > 0 ? (p.steadying && p.nearSupport ? 0.35 : 1) : p.warning > 0 ? 0.25 : Math.max(0, (p.balance - 40) / 120)
  p.spellLevel += (target - p.spellLevel) * Math.min(1, dt * 2.5)
  p.lurch = Math.max(0, p.lurch - dt * 2)
  p.swayPhase += dt
  p.balance = Math.min(110, p.balance)
}

/** Use motion-sickness pills: clears dizziness */
export function takePills (p) {
  if (p.inv.pills <= 0) return false
  p.inv.pills--
  p.balance = 0
  p.spell = 0
  p.warning = 0
  return true
}

export const eyeHeight = p => (p.seated ? 1.18 : EYE_HEIGHT + (CROUCH_EYE_HEIGHT - EYE_HEIGHT) * p.crouchT)
