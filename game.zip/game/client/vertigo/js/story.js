// Notes, objectives and endings. The story is told through what you find.

export const NOTES = {
  n1: {
    title: 'Driver\'s logbook, tonight\'s page',
    body: [
      'Route 0. Night freight. Departed Harlow Junction 23:10.',
      'Destination: the dispatcher left that line blank. Said I\'d "know it when I see it."',
      'Orders: do not stop for signals. Do not stop for anything. Do not go back into the cars.',
      '02:40. Something knocked. Three times, from behind the cab door.',
    ],
  },
  n2: {
    title: 'Maintenance tag, wired to the breaker box',
    body: [
      'Main breaker tripped AGAIN. Third time this run.',
      'All three fuses are gone. Not blown. Gone. Spares are scattered through the train like somebody hid them.',
      'Power can only be restored at the generator car, the last car on the manifest. Take the fuses there and throw the main lever.',
      'The conduit along the ceiling has been chewed through. Teeth marks. Big ones.',
    ],
  },
  n3: {
    title: 'Scrap of paper tucked in a seat',
    body: [
      'Freight runs don\'t carry passengers. The coach should be empty.',
      'So why do I keep hearing someone breathing in row nine?',
      'I checked. Nobody there. The seat cushion was warm.',
      '— E. Marsh, conductor',
    ],
  },
  n4: {
    title: 'Torn page from a railway atlas',
    body: [
      'Someone has circled the river crossing in red pen and written underneath:',
      '"The line ends HERE. There is no bridge. There never was a bridge."',
      '"We crossed it an hour ago."',
      'The rest of the map has been carefully cut out.',
    ],
  },
  n5: {
    title: 'Shipping manifest, stapled to a crate',
    body: [
      'Cargo: one (1) crate, chained.',
      'Contents: [this line has been scratched out until the paper tore]',
      'Handling: DO NOT OPEN. DO NOT LISTEN TO IT.',
      'Consignee: "Home."',
    ],
  },
  n6: {
    title: 'Pencil on the corridor floor',
    body: [
      'From outside, Car 7 is twenty metres long. I measured it on the platform.',
      'I paced it from inside: sixty-one metres.',
      'I paced it again on the way back: seventy-four.',
      'Don\'t count the doors. It doesn\'t like being counted.',
    ],
  },
  n7: {
    title: 'Conductors\' register',
    body: [
      'E. Marsh. Did not arrive.',
      'T. Okafor. Did not arrive.',
      'R. Vance. Did not arrive.',
      'The next line is already filled in, in your own handwriting. You don\'t remember writing it.',
      'It says: "This time, let it stop us."',
    ],
  },
  n8: {
    title: 'Scrawled on the generator housing',
    body: [
      'It isn\'t chasing us. Not really.',
      'Every time it gets close, it\'s between us and the front of the train. Between us and wherever we\'re going.',
      'It doesn\'t want us to get there.',
      'If the power comes back on, the train speeds up. Then there are only two ways this ends: the brake, or the station.',
    ],
  },
  n9: {
    title: 'Chalk on the generator car\'s back wall',
    body: [
      'THIS IS THE LAST CAR.',
      'Underneath, in different chalk: "It was."',
      'Underneath that, scratched into the paint with something sharp: "Don\'t open the back door when the lights come on."',
    ],
  },
  n10: {
    title: 'Dining car menu, tonight\'s date',
    body: [
      'Soup of the evening. Roast, potatoes, gravy. Rice pudding.',
      'Covers laid: 4. Covers served: 0.',
      'Someone has written along the margin: "The cook says the plates are still warm every morning. Nobody eats here. Nobody has eaten here in years."',
    ],
  },
  n11: {
    title: 'Sleeper berth 4, a letter never posted',
    body: [
      'Dear Ma,',
      'They\'ve given me the night freight. Good money. The other conductors don\'t talk about it much, except to say: when the brakes start to fail, close the valves, all four, and reset the pressure in the cab.',
      'They say it speeds up when it\'s hungry. I think they\'re joking.',
      '— T. Okafor',
    ],
  },
  n12: {
    title: 'Card slipped under a berth door',
    body: [
      'PLEASE DO NOT DISTURB.',
      'On the back, in pencil: "It sleeps in the long car. It walks the whole train when it\'s awake. It hates the noise of the wheels and it hates the light. Crouch. Be quiet. Hold your breath when it comes to the door."',
    ],
  },
  n13: {
    title: 'A parcel label, addressed to you',
    body: [
      'To: The Conductor, Route 0 Night Freight.',
      'Contents: one radio valve tube, one aerial coil, one battery cell. "Spares, for when the radio goes quiet."',
      'The postmark is from a town that was flooded when they built the reservoir. Forty years ago.',
    ],
  },
  n14: {
    title: 'Brass plate beside the coupling release',
    body: [
      'EMERGENCY COUPLING RELEASE. Separates the rear carriages from the train.',
      'Somebody has scratched beneath it: "It rides the roof. If you uncouple, it has to choose. Run for the front and don\'t look back."',
    ],
  },
  n15: {
    title: 'Passenger\'s ticket stub',
    body: [
      'ROUTE 0. SINGLE. NO RETURN.',
      'Class: Night. Seat: 9. Destination: (blank).',
      'The ticket has been punched four times. Each hole is a little bigger than the last, as if something was in a hurry.',
    ],
  },
  n16: {
    title: 'A page from the conductor\'s manual',
    body: [
      '§12. If the radio is restored, contact the dispatcher and follow their instructions exactly.',
      '§13. If the dispatcher\'s voice is your own voice, do not follow their instructions.',
      '§14. (This section has been torn out.)',
    ],
  },
}

export const CHAPTERS = ['The Dead Line', 'The Brake Line', 'Radio Silence', 'Arrival']

export const OBJECTIVES = {
  wake: { step: 'Chapter 1: The Dead Line', text: 'Get up and find out what made that noise.' },
  noise: { step: 'Chapter 1: The Dead Line', text: 'Something knocked behind the cab door. Go and look.' },
  power: { step: 'Chapter 1: The Dead Line', text: 'Find the 3 fuses hidden in the train and restore power in the generator car.' },
  install: { step: 'Generator car', text: 'Install the fuses in the panel.' },
  lever: { step: 'Generator car', text: 'Throw the main power lever.' },
  chase1: { step: 'RUN', text: 'Get through the door at the back of the generator car and keep running.' },
  wrench: { step: 'Chapter 2: The Brake Line', text: 'The train is speeding up and the brakes are bleeding air. Find a valve wrench in the new cars.' },
  valves: { step: 'Chapter 2: The Brake Line', text: 'Close the four bleed valves along the train (engine room, passenger car, cargo car, sleeping car).' },
  pressure: { step: 'Chapter 2: The Brake Line', text: 'Go back to the cab and reset the brake pressure at the gauges.' },
  parts: { step: 'Chapter 3: Radio Silence', text: 'The radio is dead. Find a valve tube, an aerial coil and a battery cell in the rear cars.' },
  radio: { step: 'Chapter 3: Radio Silence', text: 'Bring the radio parts to the cab and call the dispatcher.' },
  coupling: { step: 'Chapter 3: Radio Silence', text: 'Go to the observation car, the very back of the train, and pull the coupling release.' },
  chase2: { step: 'RUN', text: 'It\'s on the roof. Run for the front of the train. Get past the generator car.' },
  final: { step: 'Chapter 4: Arrival', text: 'Get back to the cab. Pull the emergency brake, or let the train arrive.' },
  choice: { step: 'The cab', text: 'Pull the emergency brake, or sit down and let the train arrive.' },
}

export const ENDINGS = {
  brake: {
    title: 'Still',
    text: 'The brakes scream for a full minute. When the train finally shudders to a stop, the creature is standing in the doorway behind you. It doesn\'t come closer. It lowers its long head, almost gently, and walks back into the dark of the cars. Outside there is nothing: no track, no lights, no map. Only quiet. For the first time in years, nobody is waiting for you to arrive.',
  },
  arrive: {
    title: 'Arrival',
    text: 'The train doesn\'t slow. It arrives. A platform slides out of the dark, lit like a summer noon, and the sign over it reads HOME. The doors open by themselves. Somewhere behind you something screams, not at you, for you, and then the sound is gone. You step off. The platform is warm. You can\'t remember where you were going before this, and it doesn\'t seem to matter anymore.',
  },
}
