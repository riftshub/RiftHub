// Little Lantern: shared settings

/** Co-op relay on the same Render server as the Minecraft world (path /lantern) */
export const COOP_SERVER = 'wss://gl-tahx.onrender.com/lantern'

export const coopServerUrl = () => {
  const { hostname, protocol, host } = window.location
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    const port = new URLSearchParams(location.search).get('relayPort') || '8080'
    return `${protocol === 'https:' ? 'wss' : 'ws'}://${hostname}:${port}/lantern`
  }
  if (hostname.endsWith('.onrender.com')) return `wss://${host}/lantern`
  return COOP_SERVER
}
