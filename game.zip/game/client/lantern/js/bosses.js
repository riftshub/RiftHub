// Little Lantern: the four bosses and the small things that serve them.
// The host runs every fight (Fight.update) and sends a snapshot; everyone draws from it (BossView.apply).
import * as THREE from 'three'

const placed = (m, x, y, z) => { m.position.set(x, y, z); return m }
import { ISLANDS, islandOrigin, haloTex } from './world.js'

export const BEAM_RANGE = 18
export const BEAM_DPS = 22

/** is point p (with radius r) inside a player's beam? beam: { o:{x,y,z}, d:{x,y,z} } */
export function inBeam (beam, p, r = 0.6) {
  const dx = p.x - beam.o.x, dy = p.y - beam.o.y, dz = p.z - beam.o.z
  const dist = Math.hypot(dx, dy, dz)
  if (dist > BEAM_RANGE + r || dist < 1e-3) return false
  const cos = (dx * beam.d.x + dy * beam.d.y + dz * beam.d.z) / dist
  const ang = Math.acos(Math.max(-1, Math.min(1, cos)))
  return ang < 0.16 + Math.atan(r / dist)
}

const rand = (a, b) => a + Math.random() * (b - a)
const pick = arr => arr[Math.floor(Math.random() * arr.length)]
let nextId = 1
const uid = p => `${p}${nextId++}`

export const BOSS_INFO = {
  gardener: { name: 'The Marionette Gardener', line: 'He prunes children like roses. His strings go up into the dark.', hint: 'Shine your lantern on the knots that hold his strings.' },
  hostess: { name: 'The Porcelain Hostess', line: 'She pours tea for guests who never leave.', hint: 'Her face is too hard to hurt. Wait until she stops to rethread her needles, then shine on the crack.' },
  ringmaster: { name: 'The Ringmaster of Moths', line: 'Five of him stand on five podiums. Only one of him is there.', hint: 'The real one carries a glowing pocket watch. The others are made of moths.' },
  witch: { name: 'The Spindle Witch', line: 'She winds the children into thread and keeps them forever.', hint: 'Break the three spindles to bring down her shield, then shine on her.' },
}
export const BOSS_FOR = { garden: 'gardener', parlour: 'hostess', bigtop: 'ringmaster', tower: 'witch' }

/**
 * Host-side fight.
 * hooks: players() -> [{id, x, y, z, beam, down}], fx(kind, data), hurt(id, hearts), soul(id), minion(kind, x, z), done()
 */
export class Fight {
  constructor (kind, k, hooks) {
    this.kind = kind
    this.k = k
    this.h = hooks
    const a = ISLANDS[k].arena
    this.ax = a.x + islandOrigin(k)
    this.az = a.z
    this.ar = a.r
    this.t = 0
    this.state = 'idle'
    this.next = 2
    this.started = false
    this.dead = false
    this.offerDone = false
    this.x = this.ax; this.y = 3; this.z = this.az
    if (kind === 'gardener') {
      this.max = 4; this.hp = 4
      this.anchors = [0, 1, 2, 3].map(i => ({ a: i / 4 * Math.PI * 2, hp: 40, max: 40 }))
    } else if (kind === 'hostess') {
      this.max = this.hp = 150
      this.z = this.az - 8; this.y = 0; this.slide = 0
    } else if (kind === 'ringmaster') {
      this.max = this.hp = 170
      this.podiums = [0, 1, 2, 3, 4].map(i => ({ a: i / 5 * Math.PI * 2 + 0.3, decoy: true, popped: false, lit: 0 }))
      this.real = 0
      this.hurtSince = 0
      this.y = 1.2
      this.teleport()
    } else if (kind === 'witch') {
      this.max = this.hp = 240
      this.y = 5
      this.spindles = [0, 1, 2].map(i => ({ a: i / 3 * Math.PI * 2 - Math.PI / 2, hp: 70, max: 70 }))
      this.lashes = []
    }
  }

  get name () { return BOSS_INFO[this.kind].name }
  anchorPos (an) { return { x: this.ax + Math.cos(an.a) * 8, y: 7.5, z: this.az + Math.sin(an.a) * 8 } }
  podiumPos (p) { return { x: this.ax + Math.cos(p.a) * 9, y: 1.6, z: this.az + Math.sin(p.a) * 9 } }
  spindlePos (s) { return { x: this.ax + Math.cos(s.a) * 10.5, y: 1.4, z: this.az + Math.sin(s.a) * 10.5 } }
  teleport () {
    const old = this.real
    do this.real = Math.floor(Math.random() * 5); while (this.real === old && Math.random() < 0.9)
    for (const p of this.podiums) { p.popped = false; p.lit = 0 }
    const p = this.podiumPos(this.podiums[this.real])
    this.x = p.x; this.z = p.z
    this.hurtSince = 0
    this.tpAt = this.t + rand(6, 8)
    this.h.fx('poof', { x: this.x, z: this.z })
  }

  playersIn () { return this.h.players().filter(p => !p.down && Math.hypot(p.x - this.ax, p.z - this.az) < this.ar + 1) }
  target () { const ps = this.playersIn(); return ps.length ? pick(ps) : null }

  /** damage from all beams this frame: returns the dps hitting point p */
  beamOn (p, r, dt) {
    let n = 0
    for (const pl of this.h.players()) if (pl.beam && !pl.down && inBeam(pl.beam, p, r)) n++
    return n * BEAM_DPS * dt
  }

  update (dt) {
    if (this.dead) return
    const ps = this.playersIn()
    if (!this.started) {
      if (!ps.length) return
      this.started = true
      this.h.fx('bossStart', { kind: this.kind })
      this.next = 2.5
    }
    // everyone in the arena is down or gone: the fight resets
    if (!ps.length) {
      this.idleFor = (this.idleFor ?? 0) + dt
      if (this.idleFor > 6) this.reset()
      return
    }
    this.idleFor = 0
    this.t += dt
    this[this.kind](dt, ps)
  }

  reset () {
    this.started = false
    this.idleFor = 0
    if (this.kind === 'gardener') { for (const an of this.anchors) if (an.hp > 0) an.hp = an.max } else this.hp = Math.min(this.max, this.hp + this.max * 0.35)
    if (this.kind === 'witch') { for (const s of this.spindles) if (s.hp > 0) s.hp = s.max; this.lashes = []; if (this.state === 'offer') this.state = 'idle' }
    this.h.fx('bossReset', { kind: this.kind })
  }

  // ── the Marionette Gardener: four strings, four knots ──
  gardener (dt, ps) {
    const alive = this.anchors.filter(a => a.hp > 0)
    for (const an of this.anchors) {
      an.a += dt * (0.12 + (4 - alive.length) * 0.05)
      if (an.hp <= 0) continue
      an.hp -= this.beamOn(this.anchorPos(an), 0.7, dt)
      if (an.hp <= 0) {
        an.hp = 0
        this.hp = this.anchors.filter(a => a.hp > 0).length
        this.h.fx('snip', { x: this.x, z: this.z, left: this.hp })
        for (let k = 0; k < 2; k++) this.h.minion('puppet', this.x + rand(-2, 2), this.z + rand(-2, 2))
        if (this.hp === 0) return this.die()
      }
    }
    // he dangles, swaying toward whoever is closest
    const near = ps.reduce((b, p) => (Math.hypot(p.x - this.x, p.z - this.z) < Math.hypot(b.x - this.x, b.z - this.z) ? p : b))
    const sag = (4 - alive.length) * 0.5
    this.x += (near.x - this.x) * dt * 0.25
    this.z += (near.z - this.z) * dt * 0.25
    const off = Math.hypot(this.x - this.ax, this.z - this.az)
    if (off > 7) { this.x = this.ax + (this.x - this.ax) / off * 7; this.z = this.az + (this.z - this.az) / off * 7 }
    this.y = 3.2 - sag + Math.sin(this.t * 1.7) * 0.25
    this.next -= dt
    if (this.next <= 0) {
      const close = ps.some(p => Math.hypot(p.x - this.x, p.z - this.z) < 4.5)
      if (close && Math.random() < 0.6) {
        this.state = 'shears'
        this.h.fx('area', { x: this.x, z: this.z, r: 4.2, delay: 1.3, dmg: 1, kind: 'shears' })
        this.next = 2.4
      } else {
        this.state = 'thorns'
        const n = 3 + (4 - alive.length)
        for (let k = 0; k < n; k++) {
          const p = pick(ps)
          this.h.fx('area', { x: p.x + rand(-1.5, 1.5), z: p.z + rand(-1.5, 1.5), r: 1.4, delay: 1.2 + k * 0.15, dmg: 1, kind: 'thorn', from: { x: this.x, y: this.y + 1, z: this.z } })
        }
        this.next = rand(2.4, 3.4) - (4 - alive.length) * 0.25
      }
    }
  }

  // ── the Porcelain Hostess: needles, falling teacups, and the pause to rethread ──
  hostess (dt, ps) {
    const half = this.hp < this.max / 2
    this.slide += dt * (half ? 0.6 : 0.4)
    this.x = this.ax + Math.sin(this.slide) * 6
    this.z = this.az - 8
    if (this.state === 'thread') {
      const face = { x: this.x, y: 3.1, z: this.z }
      const dmg = this.beamOn(face, 0.7, dt)
      if (dmg > 0) { this.hp -= dmg; this.hitT = 0.15 }
      if (this.hp <= 0) return this.die()
    } else {
      // light on her face does nothing but annoy her
      if (this.beamOn({ x: this.x, y: 3.1, z: this.z }, 0.7, dt) > 0 && Math.random() < dt * 0.5) this.h.fx('clink', { x: this.x, z: this.z })
    }
    this.next -= dt
    if (this.next > 0) return
    const order = ['needles', 'needles', 'teacups', 'thread']
    this.cycle = ((this.cycle ?? -1) + 1) % order.length
    this.state = order[this.cycle]
    if (this.state === 'needles') {
      const n = half ? 11 : 7
      const p = pick(ps)
      const base = Math.atan2(p.x - this.x, p.z - this.z)
      for (let k = 0; k < n; k++) {
        const a = base + (k - (n - 1) / 2) * 0.13
        this.h.fx('shot', { id: uid('n'), kind: 'needle', x: this.x, y: 1.05, z: this.z + 0.5, vx: Math.sin(a) * 13, vy: 0, vz: Math.cos(a) * 13, g: 0, life: 2.6, r: 0.35, dmg: 1 })
      }
      this.h.fx('needles', { x: this.x, z: this.z })
      this.next = half ? 1.1 : 1.5
    } else if (this.state === 'teacups') {
      for (const p of ps) for (let k = 0; k < (half ? 3 : 2); k++) this.h.fx('area', { x: p.x + rand(-2, 2), z: p.z + rand(-2, 2), r: 1.6, delay: 1.3 + k * 0.3, dmg: 1, kind: 'teacup' })
      if (half && Math.random() < 0.5) this.h.minion('doll', this.x + rand(-3, 3), this.z + 3)
      this.next = 2.2
    } else {
      this.h.fx('rethread', { x: this.x, z: this.z })
      this.next = half ? 3.6 : 4.6
    }
  }

  // ── the Ringmaster of Moths: five podiums, one real man ──
  ringmaster (dt, ps) {
    for (let i = 0; i < 5; i++) {
      const p = this.podiums[i]
      const pos = this.podiumPos(p)
      if (i === this.real) {
        const d = this.beamOn(pos, 0.65, dt)
        if (d > 0) { this.hp -= d; this.hurtSince += d; this.hitT = 0.15 }
        if (this.hp <= 0) return this.die()
      } else if (!p.popped) {
        if (this.beamOn(pos, 0.65, dt) > 0) p.lit += dt
        if (p.lit > 0.6) { p.popped = true; this.h.fx('poof', { x: pos.x, z: pos.z }); this.h.minion('moths', pos.x, pos.z) }
      }
    }
    if (this.t > this.tpAt || this.hurtSince > 32) this.teleport()
    this.next -= dt
    if (this.next <= 0) {
      const pl = pick(ps)
      const a = Math.atan2(pl.x - this.x, pl.z - this.z)
      const n = this.hp < this.max / 2 ? 3 : 2
      for (let k = 0; k < n; k++) {
        const aa = a + (k - (n - 1) / 2) * 0.35
        this.h.fx('shot', { id: uid('h'), kind: 'hoop', x: this.x, y: 0.6, z: this.z, vx: Math.sin(aa) * 7.5, vy: 0, vz: Math.cos(aa) * 7.5, g: 0, life: 3.6, r: 0.9, dmg: 1, low: true })
      }
      this.h.fx('whip', { x: this.x, z: this.z })
      if (Math.random() < 0.35) this.h.minion('moths', this.x, this.z)
      this.next = rand(1.8, 2.8)
    }
  }

  // ── the Spindle Witch ──
  witch (dt, ps) {
    if (this.state === 'offer') return // waiting for an answer
    const shield = this.spindles.some(s => s.hp > 0)
    for (const s of this.spindles) {
      if (s.hp <= 0) continue
      s.hp -= this.beamOn(this.spindlePos(s), 0.9, dt)
      if (s.hp <= 0) {
        s.hp = 0
        const i = this.spindles.indexOf(s)
        this.h.fx('spindleBreak', { i, ...this.spindlePos(s) })
        this.h.soul(`tower-s${i}`)
        if (!this.spindles.some(x => x.hp > 0)) { this.h.fx('shieldDown', {}); this.next = 2 }
      }
    }
    // she drifts round the middle
    const r = shield ? 0 : 4
    this.x = this.ax + Math.cos(this.t * 0.4) * r
    this.z = this.az + Math.sin(this.t * 0.4) * r
    this.y += ((shield ? 5 : 2.6) - this.y) * dt
    if (!shield) {
      const d = this.beamOn({ x: this.x, y: this.y + 0.6, z: this.z }, 0.9, dt)
      if (d > 0) { this.hp -= d; this.hitT = 0.15 }
      if (this.hp < this.max * 0.3 && !this.offerDone) { this.offerDone = true; this.state = 'offer'; this.lashes = []; this.h.fx('offer', {}); return }
      if (this.hp <= 0) return this.die()
    }
    // rotating lashes of thread
    for (const l of this.lashes) l.t += dt
    this.lashes = this.lashes.filter(l => l.t < l.dur)
    const frenzy = this.offerDone
    this.next -= dt
    if (this.next <= 0) {
      const roll = Math.random()
      if (roll < 0.45 && !this.lashes.length) {
        const n = frenzy ? 3 : shield ? 1 : 2
        const a0 = Math.random() * Math.PI * 2, spd = (Math.random() < 0.5 ? -1 : 1) * (frenzy ? 1.0 : 0.75)
        const lash = { id: uid('l'), x: this.ax, z: this.az, a0, spd, n, len: this.ar, dur: 6, t: 0, warn: 1.2 }
        this.lashes.push(lash)
        this.h.fx('lash', lash)
        this.next = 7
      } else if (roll < 0.8) {
        for (const p of ps) for (let k = 0; k < (frenzy ? 4 : 3); k++) this.h.fx('area', { x: p.x + rand(-2.5, 2.5), z: p.z + rand(-2.5, 2.5), r: 1.3, delay: 1.1 + k * 0.25, dmg: 1, kind: 'needle' })
        this.next = 2.6
      } else {
        for (let k = 0; k < (frenzy ? 3 : 2); k++) this.h.minion('doll', this.ax + rand(-6, 6), this.az + rand(-6, 6))
        if (!shield) { this.h.fx('pull', { x: this.x, z: this.z, dur: 1.6 }) }
        this.next = 3
      }
      if (frenzy) this.next *= 0.75
    }
  }

  answer (accept) {
    if (this.state !== 'offer') return
    if (accept) { this.dead = true; this.h.done('spindle'); return }
    this.state = 'idle'
    this.next = 1.5
    this.h.fx('refused', {})
  }

  die () {
    this.dead = true
    this.state = 'dead'
    this.h.fx('bossDown', { kind: this.kind, x: this.x, z: this.z })
    if (this.kind !== 'witch') this.h.soul(`${ISLANDS[this.k].id}-boss`)
    this.h.done(null)
  }

  snapshot () {
    const s = { kind: this.kind, x: +this.x.toFixed(2), y: +this.y.toFixed(2), z: +this.z.toFixed(2), hp: Math.max(0, Math.round(this.hp)), max: this.max, st: this.state, on: this.started, dead: this.dead, hit: (this.hitT = Math.max(0, (this.hitT ?? 0) - 0.1)) > 0 }
    if (this.anchors) s.an = this.anchors.map(a => [+a.a.toFixed(3), Math.round(a.hp)])
    if (this.podiums) { s.real = this.real; s.pop = this.podiums.map(p => (p.popped ? 1 : 0)) }
    if (this.spindles) { s.sp = this.spindles.map(x => Math.round(x.hp)); s.lashes = this.lashes.map(l => [l.id, l.t]) }
    return s
  }
}

// ═════════════ how they look ═════════════
const std = (c, r = 0.7, e = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, ...e })
const basic = (c, e = {}) => new THREE.MeshBasicMaterial({ color: c, ...e })
const halo = (color, s) => { const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })); sp.scale.setScalar(s); return sp }

function stringLine () {
  const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(0, 1, 0)])
  return new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xefe6d2, transparent: true, opacity: 0.7 }))
}
const setLine = (line, a, b) => { const p = line.geometry.attributes.position; p.setXYZ(0, a.x, a.y, a.z); p.setXYZ(1, b.x, b.y, b.z); p.needsUpdate = true; line.geometry.computeBoundingSphere() }

/** a tall, thin figure: the base for every boss */
function figure ({ coat, skin, height = 3, head = 0.42, faceless = true }) {
  const g = new THREE.Group()
  const body = new THREE.Mesh(new THREE.ConeGeometry(height * 0.2, height * 0.68, 10), std(coat, 0.8))
  body.position.y = height * 0.34
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, height * 0.12, 6), std(skin))
  neck.position.y = height * 0.72
  const hd = new THREE.Mesh(new THREE.SphereGeometry(head, 16, 12), std(skin, 0.35))
  hd.scale.y = 1.25
  hd.position.y = height * 0.82
  const arms = []
  for (const s of [-1, 1]) {
    const arm = new THREE.Group()
    arm.position.set(s * height * 0.12, height * 0.64, 0)
    const a = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.03, height * 0.5, 5), std(coat))
    a.position.y = -height * 0.25
    arm.add(a)
    arm.rotation.z = s * 0.25
    g.add(arm)
    arms.push(arm)
  }
  g.add(body, neck, hd)
  return { g, head: hd, arms, body }
}

export class BossView {
  constructor (kind, k, scene) {
    this.kind = kind
    this.scene = scene
    const a = ISLANDS[k].arena
    this.ax = a.x + islandOrigin(k); this.az = a.z
    this.root = new THREE.Group()
    scene.add(this.root)
    this.light = new THREE.PointLight(0xff4060, 0, 10, 1.6)
    this.root.add(this.light)
    this.cage = new THREE.Group()
    const bars = std(0x15121f, 0.4, { metalness: 0.5 })
    for (let i = 0; i < 10; i++) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.6, 4), bars); const an = i / 10 * Math.PI * 2; b.position.set(Math.cos(an) * 0.55, 0.8, Math.sin(an) * 0.55); this.cage.add(b) }
    this.cage.add(placed(new THREE.Mesh(new THREE.ConeGeometry(0.7, 0.5, 10), bars), 0, 1.85, 0))
    this.soul = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 8), basic(0xffe6b0))
    this.soul.position.y = 0.8
    this.soul.add(halo(0xffd28a, 1.6))
    this.cage.add(this.soul)
    if (kind !== 'witch') { this.cage.position.set(this.ax, 0, this.az - a.r + 4.5); scene.add(this.cage) }
    if (kind === 'gardener') {
      const f = figure({ coat: 0x2a3a1e, skin: 0xc8b08a, height: 3.2 })
      this.fig = f
      // a watering-can head and shears for hands
      const can = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.5, 12), std(0x5a6a5a, 0.4, { metalness: 0.6 }))
      can.position.y = 2.7
      f.g.add(can)
      f.head.visible = false
      for (const arm of f.arms) { const blade = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.7, 0.12), std(0xa8a8b0, 0.3, { metalness: 0.9 })); blade.position.y = -1.85; arm.add(blade) }
      this.root.add(f.g)
      this.strings = [0, 1, 2, 3].map(() => { const l = stringLine(); scene.add(l); return l })
      this.knots = [0, 1, 2, 3].map(() => {
        const m = new THREE.Mesh(new THREE.TorusKnotGeometry(0.28, 0.09, 40, 6), basic(0xffd28a))
        m.add(halo(0xffb547, 2.2))
        scene.add(m)
        return m
      })
    } else if (kind === 'hostess') {
      const f = figure({ coat: 0x3a2a4a, skin: 0xf4efe6, height: 3.8, head: 0.5 })
      this.fig = f
      // a painted smile and a crack that glows when she's open
      const smile = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.025, 4, 12, Math.PI), basic(0x8a1626))
      smile.rotation.z = Math.PI
      smile.position.set(0, -0.12, 0.47)
      f.head.add(smile)
      const crackMat = basic(0x301018)
      this.crack = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.5, 0.04), crackMat)
      this.crack.position.set(0.12, 0.12, 0.46)
      this.crack.rotation.z = 0.5
      f.head.add(this.crack)
      const skirt = new THREE.Mesh(new THREE.ConeGeometry(1.2, 1.6, 16, 1, true), std(0xefe6d2, 0.6, { side: THREE.DoubleSide }))
      skirt.position.y = 0.8
      f.g.add(skirt)
      this.root.add(f.g)
    } else if (kind === 'ringmaster') {
      this.figs = []
      for (let i = 0; i < 5; i++) {
        const f = figure({ coat: 0x7a1414, skin: 0xd8c0a0, height: 2.6, head: 0.34 })
        const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.6, 12), std(0x111111))
        hat.position.y = 2.6
        f.g.add(hat)
        const watch = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.04, 12).rotateX(Math.PI / 2), basic(0xffd040))
        watch.position.set(0.25, 1.35, 0.4)
        watch.add(halo(0xffc040, 1.2))
        f.g.add(watch)
        f.watch = watch
        const podium = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.95, 1.2, 14), std(i % 2 ? 0x9a1f1f : 0xefe6d2, 0.6))
        podium.position.y = 0.6
        const pg = new THREE.Group()
        pg.add(podium)
        f.g.position.y = 1.2
        pg.add(f.g)
        scene.add(pg)
        this.figs.push({ pg, f })
      }
    } else if (kind === 'witch') {
      const f = figure({ coat: 0x1a1426, skin: 0xd8d0e0, height: 4.2, head: 0.45 })
      this.fig = f
      // a hood of thread and too-long fingers
      const hood = new THREE.Mesh(new THREE.ConeGeometry(0.62, 1.3, 12, 1, true), std(0x3a1020, 0.9, { side: THREE.DoubleSide }))
      hood.position.y = 3.6
      f.g.add(hood)
      for (const arm of f.arms) for (let k = 0; k < 4; k++) { const fin = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.004, 0.9, 3), std(0xd8d0e0)); fin.position.set((k - 1.5) * 0.05, -2.4, 0); fin.rotation.z = (k - 1.5) * 0.15; arm.add(fin) }
      // her eyes: two needles' eyes, bright slits
      for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.02), basic(0xffe0f0)); e.position.set(s * 0.15, 0.05, 0.43); f.head.add(e) }
      this.root.add(f.g)
      this.shield = new THREE.Mesh(new THREE.SphereGeometry(2.6, 24, 16), new THREE.MeshBasicMaterial({ color: 0xb3243a, transparent: true, opacity: 0.18, depthWrite: false, wireframe: true }))
      this.shield.position.y = 2.2
      this.root.add(this.shield)
      this.spindles = [0, 1, 2].map(i => {
        const sg = new THREE.Group()
        const an = i / 3 * Math.PI * 2 - Math.PI / 2
        sg.position.set(this.ax + Math.cos(an) * 10.5, 0, this.az + Math.sin(an) * 10.5)
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.5, 2.6, 10), std(0x4a2a1a, 0.6))
        body.position.y = 1.3
        const wound = new THREE.Mesh(new THREE.SphereGeometry(0.62, 14, 10), std(0xb3243a, 0.6, { emissive: 0x300010 }))
        wound.scale.y = 1.3
        wound.position.y = 1.4
        const soul = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), basic(0xffe6b0))
        soul.position.y = 1.4
        soul.visible = false
        soul.add(halo(0xffd28a, 1.5))
        sg.add(body, wound, soul)
        scene.add(sg)
        return { sg, wound, soul }
      })
      this.lashMeshes = new Map()
    }
    this.hpShown = 1
  }

  apply (s, dt, t, lashes) {
    if (!s) return
    const dead = s.dead
    if (this.fig) {
      this.root.position.set(s.x, s.kind === 'gardener' ? s.y - 1.6 : s.kind === 'witch' ? s.y - 1.5 : 0, s.z)
      this.root.rotation.y = Math.sin(t * 0.4) * 0.3
      if (dead) { this.fig.g.rotation.x = Math.min(Math.PI / 2, (this.fig.g.rotation.x ?? 0) + dt * 1.5); this.fig.g.position.y = Math.max(-1.2, this.fig.g.position.y - dt * 0.8) }
      for (const [i, arm] of this.fig.arms.entries()) arm.rotation.x = Math.sin(t * 2 + i) * (s.st === 'shears' ? 1.2 : 0.3)
    }
    this.light.intensity = s.hit ? 25 : 0
    if (s.kind === 'gardener') {
      s.an.forEach(([a, hp], i) => {
        const p = { x: this.ax + Math.cos(a) * 8, y: 7.5, z: this.az + Math.sin(a) * 8 }
        const k = this.knots[i]
        k.position.set(p.x, p.y, p.z)
        k.rotation.y += dt * 2
        k.visible = hp > 0
        k.scale.setScalar(0.6 + 0.4 * hp / 40)
        const str = this.strings[i]
        str.visible = hp > 0 && !dead
        setLine(str, p, { x: s.x + (i % 2 ? 0.3 : -0.3), y: s.y + 0.8, z: s.z })
      })
    } else if (s.kind === 'hostess') {
      const open = s.st === 'thread'
      this.crack.material.color.setHex(open ? 0xffd28a : 0x301018)
      this.crack.scale.setScalar(open ? 1.6 + Math.sin(t * 10) * 0.2 : 1)
      if (this.fig.arms[0]) this.fig.arms[0].rotation.z = open ? -1.2 : -0.25
    } else if (s.kind === 'ringmaster') {
      this.figs.forEach(({ pg, f }, i) => {
        const an = i / 5 * Math.PI * 2 + 0.3
        pg.position.set(this.ax + Math.cos(an) * 9, 0, this.az + Math.sin(an) * 9)
        pg.rotation.y = -an - Math.PI / 2
        const real = i === s.real
        f.g.visible = !dead && (real || !s.pop[i])
        f.watch.visible = real
        f.g.position.y = 1.2 + Math.sin(t * 3 + i) * 0.04
        f.g.rotation.z = real ? 0 : Math.sin(t * 9 + i) * 0.03 // the fake ones shiver
      })
      this.light.position.set(0, 0, 0)
    } else if (s.kind === 'witch') {
      this.shield.visible = s.sp.some(h => h > 0) && !dead
      this.shield.rotation.y += dt * 0.4
      s.sp.forEach((hp, i) => { const sp = this.spindles[i]; sp.wound.visible = hp > 0; sp.wound.scale.set(0.5 + 0.5 * hp / 70, (0.5 + 0.5 * hp / 70) * 1.3, 0.5 + 0.5 * hp / 70); sp.soul.visible = hp <= 0 && t % 4 < 3 })
    }
    this.cage.visible = !dead || (t % 1) < 0.99
    this.soul.visible = !dead
  }

  dispose () {
    for (const o of [this.root, this.cage, ...(this.strings ?? []), ...(this.knots ?? []), ...(this.figs ?? []).map(f => f.pg), ...(this.spindles ?? []).map(s => s.sg)]) this.scene.remove(o)
  }
}

/** minions: puppets, dolls, moth swarms and the hollows that drift on every island */
export const MINIONS = {
  hollow: { hp: 30, speed: 1.4, r: 0.6, y: 1.1 },
  puppet: { hp: 22, speed: 2.4, r: 0.45, y: 0.7 },
  doll: { hp: 28, speed: 2.1, r: 0.45, y: 0.6 },
  moths: { hp: 18, speed: 3.0, r: 0.9, y: 1.4, drains: true },
}

export function minionMesh (kind) {
  const g = new THREE.Group()
  if (kind === 'hollow') {
    // a child-shaped hole in the air: black, with two pinprick lights
    const m = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 0.8, 4, 10), basic(0x050308, { transparent: true, opacity: 0.88 }))
    m.position.y = 0.2
    g.add(m)
    for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 4), basic(0xffffff)); e.position.set(s * 0.1, 0.55, 0.28); g.add(e) }
  } else if (kind === 'puppet') {
    const wood = std(0x8a6a4a, 0.8)
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.5, 0.2), wood)
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6), wood)
    head.position.y = 0.42
    g.add(body, head)
    for (const s of [-1, 1]) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.5, 4), wood); l.position.set(s * 0.1, -0.5, 0); g.add(l); g.userData.legs = (g.userData.legs ?? []).concat(l) }
    const str = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 6, 3), basic(0xefe6d2))
    str.position.y = 3.4
    g.add(str)
  } else if (kind === 'doll') {
    const p = std(0xf4efe6, 0.3)
    const body = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.6, 10), std(0x6b2e4a))
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 8), p)
    head.position.y = 0.45
    const crack = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.2, 0.02), basic(0x111111))
    crack.position.set(0.06, 0.48, 0.19); crack.rotation.z = 0.6
    g.add(body, head, crack)
  } else if (kind === 'moths') {
    const wing = new THREE.MeshBasicMaterial({ color: 0xcbb89a, side: THREE.DoubleSide })
    const geo = new THREE.PlaneGeometry(0.16, 0.1)
    g.userData.moths = []
    for (let i = 0; i < 14; i++) {
      const m = new THREE.Mesh(geo, wing)
      m.userData.o = [Math.random() * 6, Math.random() * 6, 0.4 + Math.random() * 0.6]
      g.add(m)
      g.userData.moths.push(m)
    }
  }
  return g
}

export function animateMinion (g, kind, t, dt) {
  if (kind === 'moths') for (const m of g.userData.moths) { const [a, b, r] = m.userData.o; m.position.set(Math.cos(t * 3 + a) * r, Math.sin(t * 4 + b) * 0.4, Math.sin(t * 3.4 + a) * r); m.rotation.y = t * 20 + a; m.scale.x = Math.abs(Math.sin(t * 30 + a)) + 0.2 }
  else if (kind === 'puppet') { g.rotation.z = Math.sin(t * 6) * 0.2; for (const [i, l] of (g.userData.legs ?? []).entries()) l.rotation.x = Math.sin(t * 9 + i * Math.PI) * 0.6 }
  else if (kind === 'hollow') g.children[0].material.opacity = 0.75 + Math.sin(t * 3) * 0.13
}
