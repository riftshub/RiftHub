// Little Lantern: game loop, the girl and her lantern, co-op, endings.
import * as THREE from 'three'
import { ISLANDS, buildIsland, groundAt, islandOrigin, haloTex } from './world.js'
import { Fight, BossView, BOSS_INFO, BOSS_FOR, MINIONS, minionMesh, animateMinion, inBeam, BEAM_DPS } from './bosses.js'
import { input, initInput, initTouchControls, consumePressed, consumeLook } from './input.js'
import { initGamepad, BTN } from '../../gamekit/gamepad.js'
import { net, on, connect, disconnect, sendAll, sendHost, sendTo } from '../../gamekit/net.js'
import { createAvatar } from '../../gamekit/avatar.js'
import { bindFullscreenButtons } from '../../gamekit/fullscreen.js'
import { coopServerUrl } from './config.js'
import * as A from './audio.js'

const $ = s => document.querySelector(s)
const store = {
  get (k, f) { try { const v = JSON.parse(localStorage.getItem(k) || 'null'); return v ? { ...f, ...v } : { ...f } } catch { return { ...f } } },
  set (k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} },
}
const settings = store.get('lantern.settings', { sensitivity: 1, volume: 0.8, quality: 'auto', invertY: false })
const saveSettings = () => store.set('lantern.settings', settings)
const touch = (navigator.maxTouchPoints > 0 && matchMedia('(pointer: coarse)').matches) || /Android|iPhone|iPad/i.test(navigator.userAgent)
const quality = settings.quality === 'auto' ? (touch ? 'low' : 'high') : settings.quality
const HIGH = quality === 'high'
document.body.classList.toggle('touch-ui', touch)
let myName = (() => { try { return localStorage.getItem('lantern.name') || '' } catch { return '' } })() || `Wren ${Math.floor(10 + Math.random() * 90)}`

export const TOTAL_SOULS = 12
const HEARTS = 5
const freshSave = () => ({ souls: [], beaten: [], endings: [], introSeen: false })
let save = store.get('lantern.save', freshSave())

// ═════════════ renderer + world ═════════════
const canvas = $('#view')
const renderer = new THREE.WebGLRenderer({ canvas, antialias: HIGH, powerPreference: 'high-performance' })
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, HIGH ? 1.5 : 1))
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 1.05
const scene = new THREE.Scene()
scene.fog = new THREE.Fog(0x2a2440, 18, 75)
const camera = new THREE.PerspectiveCamera(74, 1, 0.05, 400)
camera.rotation.order = 'YXZ'
scene.add(camera)
const resize = () => { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix() }
addEventListener('resize', resize)
resize()
const hemi = new THREE.HemisphereLight(0xb8b0e0, 0x2a2030, 0.9)
scene.add(hemi)
const moon = new THREE.DirectionalLight(0xc8c0ff, 0.5)
moon.position.set(-30, 50, 20)
scene.add(moon)
const islands = ISLANDS.map((_, k) => { const b = buildIsland(k, { quality }); b.group.visible = false; scene.add(b.group); return b })

// the lantern in our hand: a paper lantern on a little stick
const lantern = new THREE.Group()
const lanternGlowMat = new THREE.MeshBasicMaterial({ color: 0xffc070 })
{
  // a wire handle on top (the hand holding it is just off screen)
  const stick = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.004, 4, 16, Math.PI), new THREE.MeshStandardMaterial({ color: 0x2a1a10, metalness: 0.5 }))
  stick.position.set(0, 0.11, 0)
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.15, 12), lanternGlowMat)
  for (let i = 0; i < 4; i++) { const rib = new THREE.Mesh(new THREE.TorusGeometry(0.077, 0.004, 4, 16), new THREE.MeshBasicMaterial({ color: 0x5a2010 })); rib.rotation.x = Math.PI / 2; rib.position.y = -0.06 + i * 0.04; body.add(rib) }
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.08, 0.04, 12), new THREE.MeshStandardMaterial({ color: 0x2a1a10 }))
  cap.position.y = 0.09
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: 0xffb547, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }))
  halo.scale.setScalar(0.5)
  lantern.add(stick, body, cap, halo)
  lantern.userData.halo = halo
}
lantern.position.set(0.26, -0.27, -0.62)
lantern.scale.setScalar(0.75)
camera.add(lantern)
const lampLight = new THREE.PointLight(0xffb060, 9, 11, 1.6)
lampLight.position.set(0.24, -0.2, -0.4)
camera.add(lampLight)
const beamLight = new THREE.SpotLight(0xffd8a0, 0, BEAM_RANGE_VIS(), 0.2, 0.5, 1.2)
function BEAM_RANGE_VIS () { return 22 }
beamLight.position.set(0.24, -0.2, -0.4)
beamLight.target.position.set(0, 0, -10)
camera.add(beamLight, beamLight.target)
const beamCone = new THREE.Mesh(new THREE.ConeGeometry(2.6, 18, 24, 1, true).translate(0, -9, 0).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffd8a0, transparent: true, opacity: 0.07, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }))
beamCone.position.set(0.24, -0.2, -0.45)
camera.add(beamCone)

// ═════════════ state ═════════════
const S = { k: 0, souls: new Set(), beaten: new Set(), cocoon: {}, motes: new Set(), mins: [], boss: null, ending: null, gateOpen: false }
const G = { mode: 'title', paused: false, avatars: new Map(), registry: new Map(), fight: null, view: null, mins: new Map(), shots: [], areas: [], lashes: [], souls: [], lastState: 0, lastWorld: 0, offer: false, minionSeq: 1 }
const P = { x: 0, y: 0, z: 6, vy: 0, yaw: 0, pitch: 0, grounded: true, hearts: HEARTS, light: 100, lightWait: 0, beam: false, down: false, downAt: 0, invuln: 0, moving: false, sprinting: false, bob: 0, stepDist: 0, shake: 0, safe: { x: 0, z: 6 }, pull: null }
const myId = () => net.id ?? 'local'
const isHost = () => net.isHost
const now = () => performance.now()
const island = () => ISLANDS[S.k]

function loadIsland (k, from = null) {
  G.traveling = false
  for (const isl of islands) isl.group.visible = false
  islands[k].group.visible = true
  S.k = k
  const isl = ISLANDS[k]
  scene.fog.color.setHex(isl.fog)
  hemi.color.setHex(isl.sky[1]); hemi.groundColor.setHex(isl.fog)
  // entry point (on the Landing, next to the door you came back through)
  let ex = isl.entry.x + islandOrigin(k), ez = isl.entry.z, yaw = isl.entry.yaw
  if (k === 0 && from) { const gt = islands[0].gates.find(g => g.to === from); if (gt) { ex = gt.x * 0.7; ez = gt.z * 0.7; yaw = Math.atan2(gt.x, gt.z) } }
  P.x = ex + (Math.random() - 0.5); P.z = ez + (Math.random() - 0.5); P.y = 0; P.vy = 0; P.yaw = yaw; P.pitch = 0
  P.safe = { x: P.x, z: P.z }
  P.down = false; P.hearts = HEARTS; P.light = 100
  // fresh island state
  for (const m of G.mins.values()) scene.remove(m.mesh)
  G.mins.clear()
  G.shots.forEach(s => scene.remove(s.mesh)); G.shots = []
  G.areas.forEach(a => scene.remove(a.mesh)); G.areas = []
  G.lashes.forEach(l => scene.remove(l.mesh)); G.lashes = []
  if (G.view) { G.view.dispose(); G.view = null }
  G.fight = null
  S.boss = null
  S.motes = new Set()
  S.gateOpen = false
  const bossKind = BOSS_FOR[isl.id]
  if (bossKind && !S.beaten.has(isl.id)) G.view = new BossView(bossKind, k, scene)
  if (isHost()) {
    S.mins = []
    if (bossKind && !S.beaten.has(isl.id)) G.fight = new Fight(bossKind, k, fightHooks)
    S.gateOpen = !bossKind || S.beaten.has(isl.id)
    for (const [x, z] of isl.hollows) spawnMinion('hollow', x + islandOrigin(k), z)
  }
  for (const c of islands[k].cocoons) c.freed = S.souls.has(c.id)
  setText($('#place'), isl.name)
  if (k === 0) big('The Landing', S.souls.size ? `${S.souls.size} of ${TOTAL_SOULS} souls are home.` : 'Grandmother\'s lamp still burns. Four doors of light.')
  else big(isl.name, bossKind ? BOSS_INFO[bossKind].line : '')
  A.setScene(isl.id)
}

// ═════════════ host: the fight, the things in the dark, the souls ═════════════
const fightHooks = {
  players: () => [...G.registry.values()],
  fx: (k, d) => fx(k, d),
  hurt: (id, n) => hurtPlayer(id, n),
  soul: id => freeSoul(id),
  minion: (kind, x, z) => spawnMinion(kind, x, z),
  done: endingKind => {
    const isl = island()
    if (isl.id === 'tower') { finish(endingKind ?? (S.souls.size >= TOTAL_SOULS ? 'dawn' : 'thread')); return }
    S.beaten.add(isl.id)
    S.gateOpen = true
    S.mins = S.mins.filter(m => m.kind === 'hollow')
    fx('victory', { island: isl.id })
    writeSave()
  },
}
function hurtPlayer (id, n) { if (id === myId()) hurtMe(n); else sendTo(id, 'hurt', { n }) }
function spawnMinion (kind, x, z) {
  const def = MINIONS[kind]
  S.mins.push({ id: `e${G.minionSeq++}`, kind, x, z, y: def.y, hp: def.hp, cd: 0, wob: Math.random() * 6 })
}
function freeSoul (id) {
  if (S.souls.has(id)) return
  S.souls.add(id)
  const c = islands[S.k].cocoons.find(x => x.id === id)
  const pos = c ? { x: c.x, y: c.y, z: c.z } : S.boss ? { x: S.boss.x, y: 1.5, z: S.boss.z } : { x: P.x, y: 1.5, z: P.z }
  if (id.startsWith('tower-s')) { const i = +id.slice(7); const a = ISLANDS[4].arena; const an = i / 3 * Math.PI * 2 - Math.PI / 2; pos.x = a.x + islandOrigin(4) + Math.cos(an) * 10.5; pos.z = a.z + Math.sin(an) * 10.5; pos.y = 1.4 }
  if (id.endsWith('-boss')) { const a = island().arena; pos.x = a.x + islandOrigin(S.k); pos.z = a.z - a.r + 4.5; pos.y = 0.8 }
  fx('soul', { id, ...pos, n: S.souls.size, name: SOUL_NAMES[[...S.souls].length - 1] ?? 'a child', pip: id === 'tower-s2' })
  writeSave()
}
const SOUL_NAMES = ['Ada', 'Tomas', 'Fen', 'Lio', 'Mae', 'Odile', 'Ruben', 'Isla', 'Kit', 'Noor', 'Juno', 'Pip']

function finish (kind) {
  S.ending = kind
  fx('ending', { kind, souls: S.souls.size })
  if (G.fight) G.fight.dead = true
}

function hostTick (dt) {
  const players = [...G.registry.values()]
  if (G.fight) { G.fight.update(dt); S.boss = G.fight.snapshot() }
  // minions drift at the nearest girl; light hurts them
  for (const m of S.mins) {
    const def = MINIONS[m.kind]
    let best = null, bd = 1e9
    for (const p of players) { if (p.down) continue; const d = Math.hypot(p.x - m.x, p.z - m.z); if (d < bd) { bd = d; best = p } }
    const aggro = m.kind === 'hollow' ? 11 : 40
    if (best && bd < aggro) {
      const sp = def.speed * (m.kind === 'moths' && best.beam ? 1.4 : 1)
      m.x += (best.x - m.x) / bd * sp * dt
      m.z += (best.z - m.z) / bd * sp * dt
      m.cd -= dt
      if (bd < def.r + 0.45 && m.cd <= 0 && Math.abs((best.y ?? 0) + 0.8 - m.y) < 1.6) {
        m.cd = 1.4
        if (def.drains) sendTo2(best.id, 'drain', { n: 35 })
        else hurtPlayer(best.id, 1)
      }
    } else { m.wob += dt; m.x += Math.cos(m.wob * 0.5) * dt * 0.4; m.z += Math.sin(m.wob * 0.4) * dt * 0.4 }
    m.y = def.y + (m.kind === 'moths' ? Math.sin(m.wob * 2) * 0.4 : 0) + (m.kind === 'hollow' ? Math.sin(now() / 700 + m.wob) * 0.15 : 0)
    for (const p of players) if (p.beam && !p.down && inBeam(p.beam, m, def.r)) m.hp -= BEAM_DPS * 1.3 * dt
    if (m.hp <= 0) { m.dead = true; fx('minionDie', { x: m.x, y: m.y, z: m.z, kind: m.kind }) }
  }
  S.mins = S.mins.filter(m => !m.dead)
  // cocoons unwind under the light
  for (const c of islands[S.k].cocoons) {
    if (S.souls.has(c.id)) continue
    const lit = players.some(p => p.beam && !p.down && inBeam(p.beam, c, 0.7))
    const prog = S.cocoon[c.id] ?? 0
    S.cocoon[c.id] = Math.max(0, Math.min(1, prog + (lit ? dt / 2.2 : -dt / 6)))
    if (S.cocoon[c.id] >= 1) freeSoul(c.id)
  }
  // fireflies
  for (const m of islands[S.k].motes) {
    if (S.motes.has(m.id)) continue
    for (const p of players) if (!p.down && Math.hypot(p.x - m.x, p.z - m.z) < 1.3 && Math.abs((p.y ?? 0) + 1 - m.y) < 1.6) { S.motes.add(m.id); fx('mote', { id: m.id, to: p.id }); break }
  }
  // doors of light
  if ((S.gateOpen || S.k === 0) && !G.traveling) {
    for (const gt of islands[S.k].gates) {
      if (!gateOpen(gt)) continue
      if (players.some(p => !p.down && Math.hypot(p.x - gt.x, p.z - gt.z) < 1.25)) { travel(gt.to); return }
    }
  }
  if (net.online && now() - G.lastWorld > 100) { G.lastWorld = now(); sendAll('world', worldSnapshot()) }
}
const sendTo2 = (id, type, d) => { if (id === myId()) onLocal(type, d); else sendTo(id, type, d) }
const localHandlers = {}
const onLocal = (type, d) => localHandlers[type]?.(d)

function gateOpen (gt) {
  if (gt.home) return S.gateOpen
  // the Landing: each island opens after the one before it is cleared; the tower needs all three
  const j = gt.to
  if (j === 1) return true
  if (j === 4) return ['garden', 'parlour', 'bigtop'].every(id => S.beaten.has(id))
  return S.beaten.has(ISLANDS[j - 1].id)
}

function travel (k) {
  if (G.traveling) return
  fx('travel', { k, from: S.k })
}

function worldSnapshot () {
  return {
    k: S.k, souls: [...S.souls], beaten: [...S.beaten], cp: S.cocoon, motes: [...S.motes], gate: S.gateOpen,
    mins: S.mins.map(m => [m.id, m.kind, +m.x.toFixed(2), +m.y.toFixed(2), +m.z.toFixed(2), Math.round(m.hp)]), boss: S.boss,
  }
}

function hostRequest (pid, d) {
  switch (d.kind) {
    case 'flare': {
      for (const m of S.mins) if (Math.hypot(m.x - d.x, m.z - d.z) < 7) m.hp -= 45
      if (G.fight?.kind === 'ringmaster') for (const p of G.fight.podiums) { const pos = G.fight.podiumPos(p); if (Math.hypot(pos.x - d.x, pos.z - d.z) < 7 && G.fight.podiums.indexOf(p) !== G.fight.real) p.lit += 1 }
      fx('flare', { x: d.x, y: d.y, z: d.z, by: pid })
      break
    }
    case 'answer': G.fight?.answer(!!d.accept); if (G.fight) S.boss = G.fight.snapshot(); break
  }
}
const request = (kind, data = {}) => { if (isHost()) hostRequest(myId(), { kind, ...data }); else sendHost('req', { kind, ...data }) }

// ═════════════ effects ═════════════
function fx (kind, d = {}) {
  playFx(kind, d)
  if (net.online && isHost()) sendAll('fx', { kind, data: d })
}
const at = (x, z, y = 1.2) => ({ x, y, z })
function playFx (kind, d) {
  if (d.to && d.to !== myId() && kind !== 'mote') return
  switch (kind) {
    case 'travel': G.traveling = true; fade(1, 500); A.play('gate', { vol: 0.8 }); setTimeout(() => { loadIsland(d.k, d.from); fade(0, 1200) }, 550); break
    case 'bossStart': { const info = BOSS_INFO[d.kind]; big(info.name, info.hint); A.play('stinger', { vol: 0.8, music: true }); A.boss(true); break }
    case 'bossReset': toast('The lights went out. The fight starts over.'); A.boss(false); break
    case 'area': spawnArea(d); break
    case 'shot': spawnShot(d); break
    case 'lash': spawnLash(d); break
    case 'snip': A.play('snip', { pos: at(d.x, d.z, 6), vol: 1.2, ref: 6 }); toast(d.left ? `A string snaps. ${d.left} left.` : 'The last string snaps.'); break
    case 'needles': A.play('needles', { pos: at(d.x, d.z, 2.5), vol: 1, ref: 5 }); break
    case 'clink': A.play('clink', { pos: at(d.x, d.z, 3), vol: 0.7 }); break
    case 'rethread': A.play('rethread', { pos: at(d.x, d.z, 3), vol: 1, ref: 6 }); toast('She stops to thread her needles. Now!'); break
    case 'whip': A.play('whip', { pos: at(d.x, d.z, 2), vol: 1, ref: 6 }); break
    case 'poof': A.play('poof', { pos: at(d.x, d.z, 2), vol: 0.8, ref: 5 }); burst(d.x, 1.8, d.z, 0xcbb89a); break
    case 'spindleBreak': A.play('spindle_break', { pos: at(d.x, d.z), vol: 1.2, ref: 6 }); burst(d.x, 1.4, d.z, 0xb3243a); break
    case 'shieldDown': big('Her shield is down', 'Shine on her!'); A.play('shield_down', { vol: 1 }); break
    case 'pull': A.play('witch_laugh', { pos: at(d.x, d.z, 3), vol: 1, ref: 8 }); P.pull = { x: d.x, z: d.z, until: now() + d.dur * 1000 }; break
    case 'offer': G.offer = true; showOffer(true); A.play('witch_offer', { vol: 1, music: true }); break
    case 'refused': G.offer = false; showOffer(false); big('No.', 'Wren lifts her lantern higher.'); A.play('refuse', { vol: 0.9 }); break
    case 'bossDown': A.play('boss_down', { pos: at(d.x, d.z, 2), vol: 1.3, ref: 8 }); A.boss(false); burst(d.x, 2, d.z, 0xffd28a, 40); break
    case 'victory': big('The island is quiet', 'A door of light has opened at the far side. It leads home to the Landing.'); A.play('victory', { vol: 0.8, music: true }); S.gateOpen = true; S.beaten.add(d.island); break
    case 'soul': spawnSoul(d); A.play('soul_free', { pos: at(d.x, d.z, d.y), vol: 1, ref: 6 }); toast(d.pip ? 'Pip! Your brother\'s light flies up out of the thread.' : `${d.name} is free. ${d.n} of ${TOTAL_SOULS} souls.`, 4000); S.souls.add(d.id); break
    case 'mote': { const m = islands[S.k].motes.find(x => x.id === d.id); if (m) m.taken = true; S.motes.add(d.id); if (d.to === myId()) { P.light = Math.min(100, P.light + 45); A.play('mote', { vol: 0.7 }) } break }
    case 'flare': A.play('flare', { pos: at(d.x, d.z, d.y), vol: 1, ref: 5 }); burst(d.x, d.y, d.z, 0xffe6b0, 30, 7); if (Math.hypot(d.x - P.x, d.z - P.z) < 9) G.flash = 1; break
    case 'minionDie': A.play('minion_die', { pos: at(d.x, d.z, d.y), vol: 0.8 }); burst(d.x, d.y, d.z, d.kind === 'moths' ? 0xcbb89a : 0x221a33, 16); break
    case 'ending': showEnding(d.kind, d.souls); break
  }
}

// ═════════════ attacks everyone sees (each player checks itself) ═════════════
const ringGeo = new THREE.RingGeometry(0.85, 1, 40)
function spawnArea (d) {
  const m = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: d.kind === 'shears' ? 0xff3050 : 0xff7060, transparent: true, opacity: 0.6, depthWrite: false }))
  m.rotation.x = -Math.PI / 2
  const gy = Math.max(0, groundAt(S.k, d.x, d.z))
  m.position.set(d.x, gy + 0.04, d.z)
  m.scale.setScalar(d.r)
  const fill = new THREE.Mesh(new THREE.CircleGeometry(1, 32), new THREE.MeshBasicMaterial({ color: 0xff3050, transparent: true, opacity: 0.15, depthWrite: false }))
  fill.scale.setScalar(0.01)
  m.add(fill)
  scene.add(m)
  let proj = null
  if (d.from) {
    proj = new THREE.Mesh(new THREE.IcosahedronGeometry(0.22, 0), new THREE.MeshStandardMaterial({ color: d.kind === 'thorn' ? 0x2f4a20 : 0xf2ede4, roughness: 0.6 }))
    scene.add(proj)
  } else if (d.kind === 'teacup' || d.kind === 'needle') {
    proj = d.kind === 'teacup' ? new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.35, 0.5, 14), new THREE.MeshStandardMaterial({ color: 0xf2ede4, roughness: 0.25 })) : new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.005, 1.6, 4), new THREE.MeshStandardMaterial({ color: 0xc8c8d0, metalness: 0.9, roughness: 0.2 }))
    scene.add(proj)
  }
  G.areas.push({ ...d, gy, t: 0, mesh: m, fill, proj })
}
function updateAreas (dt) {
  for (const a of G.areas) {
    a.t += dt
    const f = Math.min(1, a.t / a.delay)
    a.fill.scale.setScalar(f)
    if (a.proj) {
      if (a.from) { const p = a.from; a.proj.position.set(p.x + (a.x - p.x) * f, p.y + (a.gy - p.y) * f + Math.sin(f * Math.PI) * 4, p.z + (a.z - p.z) * f); a.proj.rotation.x += dt * 8 } else a.proj.position.set(a.x, a.gy + (1 - f) * 12, a.z)
    }
    if (a.t >= a.delay && !a.hit) {
      a.hit = true
      A.play(a.kind === 'teacup' ? 'teacup' : a.kind === 'shears' ? 'shears' : a.kind === 'needle' ? 'needle_land' : 'thorn', { pos: at(a.x, a.z, 0.5), vol: 0.9 })
      if (!P.down && Math.hypot(P.x - a.x, P.z - a.z) < a.r && P.y - Math.max(0, groundAt(S.k, P.x, P.z)) < 1.2) hurtMe(a.dmg)
      if (a.kind === 'teacup') burst(a.x, a.gy + 0.3, a.z, 0xf2ede4, 14)
    }
  }
  for (const a of G.areas) if (a.t > a.delay + 0.25) { scene.remove(a.mesh); if (a.proj) scene.remove(a.proj); a.gone = true }
  G.areas = G.areas.filter(a => !a.gone)
}
const needleGeo = new THREE.CylinderGeometry(0.02, 0.004, 0.7, 4).rotateX(Math.PI / 2)
const hoopGeo = new THREE.TorusGeometry(0.85, 0.08, 6, 24)
function spawnShot (d) {
  let mesh
  if (d.kind === 'needle') { mesh = new THREE.Mesh(needleGeo, new THREE.MeshBasicMaterial({ color: 0xe8e8f0 })); mesh.lookAt(d.vx, 0, d.vz) } else if (d.kind === 'hoop') { mesh = new THREE.Mesh(hoopGeo, new THREE.MeshBasicMaterial({ color: 0xff8030 })); mesh.add(new THREE.PointLight(0xff8030, HIGH ? 6 : 0, 5, 2)) }
  mesh.position.set(d.x, d.y, d.z)
  scene.add(mesh)
  if (d.kind === 'hoop') { mesh.rotation.y = Math.atan2(d.vx, d.vz); A.play('hoop', { pos: at(d.x, d.z, 0.6), vol: 0.6 }) }
  G.shots.push({ ...d, t: 0, mesh })
}
function updateShots (dt) {
  for (const s of G.shots) {
    s.t += dt
    s.x += s.vx * dt; s.y += s.vy * dt; s.z += s.vz * dt
    s.vy -= (s.g ?? 0) * dt
    s.mesh.position.set(s.x, s.y, s.z)
    if (s.kind === 'hoop') s.mesh.rotation.x += dt * 5
    if (!P.down && !s.hitMe) {
      const feet = P.y, gy = Math.max(0, groundAt(S.k, P.x, P.z))
      const d = Math.hypot(P.x - s.x, P.z - s.z)
      const hit = s.low ? d < s.r && feet - gy < 0.55 : d < s.r + 0.25 && Math.abs(P.y + 1 - s.y) < 1.0
      if (hit) { s.hitMe = true; hurtMe(s.dmg) }
    }
    if (s.t > s.life) s.gone = true
  }
  for (const s of G.shots) if (s.gone) scene.remove(s.mesh)
  G.shots = G.shots.filter(s => !s.gone)
}
function spawnLash (d) {
  const group = new THREE.Group()
  group.position.set(d.x, 0.35, d.z)
  const mat = new THREE.MeshBasicMaterial({ color: 0xff3050, transparent: true, opacity: 0.35 })
  for (let i = 0; i < d.n; i++) {
    const line = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, d.len).translate(0, 0, d.len / 2), mat)
    line.userData.off = i / d.n * Math.PI * 2
    group.add(line)
  }
  scene.add(group)
  A.play('lash', { pos: at(d.x, d.z, 1), vol: 1, ref: 10 })
  G.lashes.push({ ...d, t: 0, mesh: group, mat, cd: 0 })
}
function updateLashes (dt) {
  for (const l of G.lashes) {
    l.t += dt
    const live = l.t > l.warn
    l.mat.opacity = live ? 0.95 : 0.2 + 0.2 * Math.sin(l.t * 20)
    l.mat.color.setHex(live ? 0xff2040 : 0xff8090)
    const a = l.a0 + l.spd * Math.max(0, l.t - l.warn)
    l.mesh.children.forEach(c => { c.rotation.y = a + c.userData.off })
    l.cd -= dt
    if (live && !P.down && l.cd <= 0) {
      const dx = P.x - l.x, dz = P.z - l.z, dist = Math.hypot(dx, dz)
      if (dist < l.len && dist > 0.4) {
        const pa = Math.atan2(dx, dz)
        for (const c of l.mesh.children) {
          let diff = pa - (a + c.userData.off)
          diff = Math.atan2(Math.sin(diff), Math.cos(diff))
          const gy = Math.max(0, groundAt(S.k, P.x, P.z))
          if (Math.abs(diff) * dist < 0.45 && P.y - gy < 0.5) { hurtMe(1); l.cd = 1; break }
        }
      }
    }
    if (l.t > l.dur) { scene.remove(l.mesh); l.gone = true }
  }
  G.lashes = G.lashes.filter(l => !l.gone)
}

// sparks and souls
const bursts = []
function burst (x, y, z, color, n = 20, spread = 2.5) {
  const geo = new THREE.BufferGeometry()
  const pos = new Float32Array(n * 3), vel = []
  for (let i = 0; i < n; i++) { pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z; vel.push([(Math.random() - 0.5) * spread * 2, Math.random() * spread, (Math.random() - 0.5) * spread * 2]) }
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ color, size: 0.12, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }))
  scene.add(pts)
  bursts.push({ pts, vel, t: 0 })
}
function updateBursts (dt) {
  for (const b of bursts) {
    b.t += dt
    const p = b.pts.geometry.attributes.position
    for (let i = 0; i < b.vel.length; i++) { p.setXYZ(i, p.getX(i) + b.vel[i][0] * dt, p.getY(i) + b.vel[i][1] * dt, p.getZ(i) + b.vel[i][2] * dt); b.vel[i][1] -= 3 * dt }
    p.needsUpdate = true
    b.pts.material.opacity = Math.max(0, 1 - b.t / 1.4)
  }
  for (let i = bursts.length - 1; i >= 0; i--) if (bursts[i].t > 1.4) { scene.remove(bursts[i].pts); bursts.splice(i, 1) }
}
function spawnSoul (d) {
  // a small child made of light rises out of the thread and floats away up
  const g = new THREE.Group()
  const m = new THREE.MeshBasicMaterial({ color: 0xffeccc, transparent: true, opacity: 0.9 })
  const body = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.6, 10), m)
  body.position.y = 0.3
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), m)
  head.position.y = 0.72
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: 0xffc070, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }))
  halo.scale.setScalar(2.4); halo.position.y = 0.5
  const light = new THREE.PointLight(0xffd28a, 8, 6, 2)
  light.position.y = 0.5
  g.add(body, head, halo, light)
  g.position.set(d.x, d.y - 0.5, d.z)
  scene.add(g)
  G.souls.push({ g, m, light, t: 0 })
}
function updateSouls (dt) {
  for (const s of G.souls) {
    s.t += dt
    s.g.position.y += dt * (s.t < 1.5 ? 0.4 : 1.6)
    s.g.rotation.y += dt
    s.m.opacity = Math.max(0, 0.9 - Math.max(0, s.t - 3) / 2)
    s.light.intensity = 8 * s.m.opacity / 0.9
  }
  for (let i = G.souls.length - 1; i >= 0; i--) if (G.souls[i].t > 5) { scene.remove(G.souls[i].g); G.souls.splice(i, 1) }
}
// the souls that made it home circle grandmother's lamp
const homeLights = []
function updateHomeLights (t) {
  while (homeLights.length < S.souls.size) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffe6b0 }))
    const h = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: 0xffc070, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }))
    h.scale.setScalar(0.9)
    m.add(h)
    islands[0].group.add(m)
    homeLights.push(m)
  }
  homeLights.forEach((m, i) => { const a = t * 0.4 + i / Math.max(1, homeLights.length) * Math.PI * 2; m.position.set(Math.cos(a) * 1.6, 3.3 + Math.sin(t + i) * 0.3, Math.sin(a) * 1.6) })
}

// ═════════════ networking ═════════════
on('state', (d, from) => {
  const p = G.registry.get(from) ?? { id: from }
  Object.assign(p, d, { id: from })
  G.registry.set(from, p)
  let av = G.avatars.get(from)
  if (!av) {
    const model = createAvatar(from, { outfit: 'girl', name: playerName(from), shadows: false, look: { coat: [0xe8c23a, 0x5b8ad6, 0xd65b8a, 0x6bd65b][G.avatars.size % 4] } })
    scene.add(model.group)
    const light = new THREE.PointLight(0xffb060, HIGH ? 5 : 0, 8, 1.8)
    model.group.add(light)
    light.position.set(0.3, 1.2, 0.3)
    av = { model, light, target: d, x: d.x, y: d.y, z: d.z, yaw: d.yaw, speed: 0 }
    G.avatars.set(from, av)
  }
  av.target = d
})
on('req', (d, from) => { if (isHost()) hostRequest(from, d) })
on('fx', d => { if (!isHost()) playFx(d.kind, d.data ?? {}) })
on('hurt', d => hurtMe(d.n))
on('drain', d => { P.light = Math.max(0, P.light - d.n); A.play('drain', { vol: 0.7 }); toast('The moths are eating your light!') })
localHandlers.drain = d => { P.light = Math.max(0, P.light - d.n); A.play('drain', { vol: 0.7 }); toast('The moths are eating your light!') }
on('start', d => { if (!isHost()) startGame({ coop: true, k: d.k }) })
on('world', d => {
  if (isHost()) return
  if (d.k !== S.k && G.mode === 'playing' && !G.traveling) loadIsland(d.k)
  S.souls = new Set(d.souls); S.beaten = new Set(d.beaten); S.cocoon = d.cp; S.gateOpen = d.gate
  for (const id of d.motes) { S.motes.add(id); const m = islands[S.k].motes.find(x => x.id === id); if (m) m.taken = true }
  S.mins = d.mins.map(([id, kind, x, y, z, hp]) => ({ id, kind, x, y, z, hp }))
  S.boss = d.boss
  if (d.boss && !G.view && BOSS_FOR[island().id] === d.boss.kind && !S.beaten.has(island().id)) G.view = new BossView(d.boss.kind, S.k, scene)
})
on('peerJoin', d => {
  toast(`${d.name} has a lantern too.`)
  if (isHost() && G.mode !== 'title') sendTo(d.id, 'start', { k: S.k })
  refreshLobby()
})
on('peerLeave', d => {
  toast(`${playerName(d.id)}'s light went home.`)
  G.registry.delete(d.id)
  const av = G.avatars.get(d.id)
  if (av) { av.model.dispose(); G.avatars.delete(d.id) }
  refreshLobby()
})
on('hostChange', ({ isHost: me }) => {
  if (me && G.mode !== 'title') {
    // carry on from what we last heard: rebuild the fight fresh
    const kind = BOSS_FOR[island().id]
    if (kind && !S.beaten.has(island().id)) G.fight = new Fight(kind, S.k, fightHooks)
    toast('You are leading now.')
  }
  refreshLobby()
})
on('disconnected', () => { if (G.mode !== 'title') { toast('Lost the others. Carrying on alone.'); for (const av of G.avatars.values()) av.model.dispose(); G.avatars.clear(); G.registry.clear(); const kind = BOSS_FOR[island().id]; if (kind && !S.beaten.has(island().id) && !G.fight) G.fight = new Fight(kind, S.k, fightHooks) } })
on('roster', () => refreshLobby())
on('name', (d, from) => { const p = net.players.get(from); if (p) p.name = d.name; refreshLobby() })
const playerName = id => (id === myId() ? myName : net.players.get(id)?.name ?? 'Someone')

// ═════════════ the girl ═════════════
function hurtMe (n) {
  if (P.down || now() < P.invuln) return
  P.hearts = Math.max(0, P.hearts - n)
  P.invuln = now() + 1100
  P.shake = Math.max(P.shake, 0.7)
  A.play('hurt', { vol: 0.9 })
  $('#hurt').style.opacity = '1'
  setTimeout(() => { $('#hurt').style.opacity = '0' }, 300)
  if (P.hearts <= 0) {
    P.down = true
    P.downAt = now()
    A.play('unravel', { vol: 1 })
    toast('Your thread comes loose…', 3000)
    setTimeout(respawn, 4500)
  }
}
function respawn () {
  const isl = island()
  fade(1, 300)
  setTimeout(() => {
    P.x = isl.entry.x + islandOrigin(S.k) + (Math.random() - 0.5); P.z = isl.entry.z + (Math.random() - 0.5); P.y = 0; P.vy = 0
    P.yaw = isl.entry.yaw; P.pitch = 0
    P.hearts = HEARTS; P.light = 100; P.down = false; P.safe = { x: P.x, z: P.z }
    fade(0, 900)
  }, 320)
}

const solidsNear = () => islands[S.k].solid
function updatePlayer (dt, look, canAct) {
  const sens = 0.0022 * settings.sensitivity
  P.yaw -= look.x * sens
  P.pitch = Math.max(-1.4, Math.min(1.4, P.pitch - look.y * sens * (settings.invertY ? -1 : 1)))
  if (P.down) return
  let mx = canAct ? input.move.x : 0, my = canAct ? input.move.y : 0
  const len = Math.hypot(mx, my)
  if (len > 1) { mx /= len; my /= len }
  const sprint = canAct && input.held.sprint && my > 0.3
  const speed = (sprint ? 5.6 : 3.6) * (P.beam ? 0.8 : 1)
  const fwx = -Math.sin(P.yaw), fwz = -Math.cos(P.yaw), rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw)
  const ox = P.x, oz = P.z
  let vx = (fwx * my + rx * mx) * speed, vz = (fwz * my + rz * mx) * speed
  if (P.pull && now() < P.pull.until) { const dx = P.pull.x - P.x, dz = P.pull.z - P.z, d = Math.hypot(dx, dz) || 1; vx += dx / d * 3.2; vz += dz / d * 3.2 } else P.pull = null
  P.x += vx * dt; P.z += vz * dt
  // walk round solid things
  for (const [sx, sz, r] of solidsNear()) {
    const dx = P.x - sx, dz = P.z - sz, d = Math.hypot(dx, dz), R = r + 0.3
    if (d < R && d > 1e-4) { P.x = sx + dx / d * R; P.z = sz + dz / d * R }
  }
  // ground, jumping, the void
  const gy = groundAt(S.k, P.x, P.z)
  if (canAct && consumePressed('jump') && P.grounded) { P.vy = 6.2; P.grounded = false; A.play('jump', { vol: 0.5 }) }
  P.vy -= 16 * dt
  P.y += P.vy * dt
  if (gy > -1e9 && P.y <= gy + 0.001 && P.y > gy - 0.6) {
    if (!P.grounded && P.vy < -6) A.play('land', { vol: 0.5 })
    P.y = gy; P.vy = 0; P.grounded = true
  } else if (gy > -1e9 && P.y < gy - 0.6 && P.y > gy - 1.4) {
    // walked into a step too tall: push back
    P.x = ox; P.z = oz
    if (P.y < gy) { const g2 = groundAt(S.k, P.x, P.z); if (g2 > -1e9) { P.y = Math.max(P.y, g2) } }
  } else P.grounded = false
  if (P.grounded && Math.hypot(P.x - P.safe.x, P.z - P.safe.z) > 1.5) {
    // remember somewhere safely away from the edge
    const ok = [[1.2, 0], [-1.2, 0], [0, 1.2], [0, -1.2]].every(([a, b]) => groundAt(S.k, P.x + a, P.z + b) > -1e9)
    if (ok) P.safe = { x: P.x, z: P.z }
  }
  if (P.y < -14) {
    P.x = P.safe.x; P.z = P.safe.z; P.y = Math.max(0, groundAt(S.k, P.x, P.z)) + 2; P.vy = 0
    A.play('fall', { vol: 0.8 })
    toast('You fell into the fog. It spat you back out.')
    P.invuln = 0
    hurtMe(1)
  }
  const moved = Math.hypot(P.x - ox, P.z - oz)
  P.moving = len > 0.15 && moved / dt > 0.2 && P.grounded
  P.sprinting = sprint && P.moving
  if (P.moving) {
    P.stepDist += moved
    P.bob += moved * 3
    if (P.stepDist > (P.sprinting ? 0.8 : 0.62)) { P.stepDist = 0; A.play(`step_${island().id === 'parlour' ? 'porcelain' : island().id === 'landing' || island().id === 'tower' ? 'wood' : 'grass'}`, { pos: at(P.x, P.z, P.y + 0.1), vol: P.sprinting ? 0.5 : 0.3 }) }
  }
  // the lantern
  const wantBeam = canAct && input.held.fire && P.light > 1
  if (wantBeam && !P.beam) A.play('beam_on', { vol: 0.6 })
  P.beam = wantBeam
  if (P.beam) { P.light = Math.max(0, P.light - 13 * dt); P.lightWait = 0.7 } else { P.lightWait -= dt; if (P.lightWait <= 0) P.light = Math.min(100, P.light + 9 * dt) }
  if (canAct && consumePressed('flare')) {
    if (P.light >= 50) { P.light -= 50; request('flare', { x: P.x, y: P.y + 1.2, z: P.z }) } else { toast('Not enough light for a flare.'); A.play('click', { vol: 0.4 }) }
  }
}
function beamPose () {
  const o = new THREE.Vector3(); camera.getWorldPosition(o)
  const d = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
  return { o: { x: +o.x.toFixed(2), y: +o.y.toFixed(2), z: +o.z.toFixed(2) }, d: { x: +d.x.toFixed(3), y: +d.y.toFixed(3), z: +d.z.toFixed(3) } }
}

// ═════════════ drawing per frame ═════════════
function updateMinionViews (dt, t) {
  const seen = new Set()
  for (const m of S.mins) {
    seen.add(m.id)
    let v = G.mins.get(m.id)
    if (!v) { v = { mesh: minionMesh(m.kind), x: m.x, y: m.y, z: m.z, kind: m.kind }; scene.add(v.mesh); G.mins.set(m.id, v) }
    const k = isHost() ? 1 : Math.min(1, dt * 10)
    v.x += (m.x - v.x) * k; v.y += (m.y - v.y) * k; v.z += (m.z - v.z) * k
    v.mesh.position.set(v.x, v.y, v.z)
    v.mesh.rotation.y = Math.atan2(P.x - v.x, P.z - v.z)
    animateMinion(v.mesh, m.kind, t, dt)
  }
  for (const [id, v] of G.mins) if (!seen.has(id)) { scene.remove(v.mesh); G.mins.delete(id) }
}
function updateAvatars (dt) {
  for (const [id, av] of G.avatars) {
    const t = av.target
    const jump = Math.hypot(t.x - av.x, t.z - av.z)
    const k = jump > 6 ? 1 : Math.min(1, dt * 12)
    const ox = av.x, oz = av.z
    av.x += (t.x - av.x) * k; av.z += (t.z - av.z) * k; av.y += ((t.y ?? 0) - av.y) * k
    let dy = t.yaw - av.yaw
    while (dy > Math.PI) dy -= Math.PI * 2
    while (dy < -Math.PI) dy += Math.PI * 2
    av.yaw += dy * Math.min(1, dt * 12)
    const v = jump > 6 ? 0 : Math.hypot(av.x - ox, av.z - oz) / Math.max(dt, 1e-3)
    av.speed += (v - av.speed) * Math.min(1, dt * 8)
    av.model.setName(playerName(id))
    av.model.update(dt, { x: av.x, y: av.y, z: av.z, yaw: av.yaw, pitch: t.pitch, speed: av.speed, down: !!t.down, flashlight: !!t.beam })
    av.model.group.visible = (t.k ?? S.k) === S.k
  }
}
function updateCamera (dt, t) {
  lantern.visible = G.mode === 'playing'
  lampLight.visible = beamCone.visible = G.mode === 'playing'
  if (G.mode === 'title' || G.mode === 'ending') {
    const s = t / 1000
    const k = G.mode === 'ending' ? 4 : 0
    if (!islands[k].group.visible) { for (const i of islands) i.group.visible = false; islands[k].group.visible = true; scene.fog.color.setHex(ISLANDS[k].fog) }
    const ox = islandOrigin(k)
    camera.position.set(ox + Math.sin(s * 0.05) * 16, 6 + Math.sin(s * 0.1), Math.cos(s * 0.05) * 16 + (k === 4 ? -40 : 0))
    camera.lookAt(ox, k === 4 ? 8 : 2.5, k === 4 ? -40 : 0)
    return
  }
  const bob = P.moving ? Math.sin(P.bob * Math.PI) * (P.sprinting ? 0.05 : 0.03) : 0
  const sh = P.shake * 0.06
  const eye = P.down ? 0.35 : 1.35 // she's small
  camera.position.set(P.x + (Math.random() - 0.5) * sh, P.y + eye + bob + (Math.random() - 0.5) * sh, P.z + (Math.random() - 0.5) * sh)
  camera.rotation.set(P.pitch, P.yaw, P.down ? 0.9 : 0)
  P.shake = Math.max(0, P.shake - dt * 2)
  // lantern sway + glow
  lantern.position.x = Math.min(0.26, 0.2 * camera.aspect) + (P.moving ? Math.sin(P.bob * Math.PI * 0.5) * 0.015 : 0)
  lantern.rotation.z = P.moving ? Math.sin(P.bob * Math.PI * 0.5) * 0.12 : Math.sin(t / 900) * 0.04
  const lightK = P.light / 100
  lanternGlowMat.color.setRGB(1, 0.6 + 0.2 * lightK, 0.3 + 0.2 * lightK).multiplyScalar(0.4 + 0.6 * lightK)
  lantern.userData.halo.scale.setScalar(P.beam ? 0.9 : 0.35 + 0.2 * lightK)
  lampLight.intensity = (P.down ? 1 : 4 + 6 * lightK) * (0.92 + Math.random() * 0.08)
  beamLight.intensity = P.beam ? 60 : 0
  beamCone.visible = P.beam
  G.flash = Math.max(0, (G.flash ?? 0) - dt * 2.5)
  hemi.intensity = 1.35 + G.flash * 3
}

let last = now()
function frame () {
  requestAnimationFrame(frame)
  const t = now()
  const dt = Math.min(0.05, (t - last) / 1000)
  last = t
  window.__frames = (window.__frames ?? 0) + 1
  if (G.mode === 'playing' && !G.paused) step(dt, t)
  if (G.mode === 'playing' && isHost() && !G.paused) hostTick(dt)
  if (G.mode === 'playing') {
    updateAreas(dt); updateShots(dt); updateLashes(dt); updateMinionViews(dt, t / 1000)
    G.view?.apply(S.boss, dt, t / 1000)
    updateHomeLights(t / 1000)
    for (const c of islands[S.k].cocoons) { c.progress = S.cocoon[c.id] ?? 0; c.freed = S.souls.has(c.id) }
    for (const gt of islands[S.k].gates) { gt.mesh.visible = gateOpen(gt); if (gt.label) gt.label.material.opacity = gateOpen(gt) ? 1 : 0.3 }
    islands[0].gates.forEach(gt => { gt.mesh.visible = true; gt.mesh.userData.fill.color.setHex(gateOpen(gt) ? [0x9ad6a0, 0xf0c0d0, 0xffb060, 0xb090ff][gt.to - 1] : 0x222030) })
  }
  islands[S.k].update(dt, t / 1000)
  updateBursts(dt); updateSouls(dt)
  updateAvatars(dt)
  updateCamera(dt, t)
  renderer.render(scene, camera)
}

function step (dt, t) {
  const look = consumeLook()
  const canAct = input.enabled && !P.down && !G.offer
  if (consumePressed('pause')) pause()
  if (G.offer) { if (consumePressed('choice1')) answer(true); if (consumePressed('choice2')) answer(false) }
  updatePlayer(dt, canAct || (G.offer && input.enabled) ? look : { x: 0, y: 0 }, canAct)
  if (net.online && t - G.lastState > 66) {
    G.lastState = t
    sendAll('state', { x: +P.x.toFixed(2), y: +P.y.toFixed(2), z: +P.z.toFixed(2), yaw: +P.yaw.toFixed(2), pitch: +P.pitch.toFixed(2), beam: P.beam ? beamPose() : null, down: P.down, k: S.k })
  }
  G.registry.set(myId(), { id: myId(), x: P.x, y: P.y, z: P.z, down: P.down, beam: P.beam ? beamPose() : null, k: S.k })
  const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
  A.S.listener(camera.position, fwd)
  A.updateBeds(dt, { beam: P.beam, low: P.hearts <= 1 })
  updateHud()
}

// ═════════════ UI ═════════════
const screens = ['title', 'prologue', 'join', 'lobby', 'howto', 'settings', 'pause', 'ending']
let current = 'title'
const stack = []
function showScreen (name, { push = false } = {}) {
  if (push && current) stack.push(current)
  for (const s of screens) $(`#screen-${s}`)?.classList.toggle('is-open', s === name)
  current = name
}
const backScreen = () => showScreen(stack.pop() ?? 'title')
const setHud = on => { $('#hud').classList.toggle('is-on', on); $('#touch').classList.toggle('is-on', on && touch) }
const fade = (to, ms) => { const el = $('#fade'); el.style.transition = `opacity ${ms}ms`; el.style.opacity = String(to) }
const cache = new WeakMap()
const setText = (el, text, html = false) => { if (cache.get(el) === text) return; cache.set(el, text); if (html) el.innerHTML = text; else el.textContent = text }
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
let toastTimer
const toast = (text, ms = 3200) => { const el = $('#toast'); el.textContent = text; el.style.opacity = '1'; clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.style.opacity = '0' }, ms) }
let bigTimer
const big = (a, b) => { const el = $('#big'); el.innerHTML = `${esc(a)}${b ? `<small>${esc(b)}</small>` : ''}`; el.classList.add('is-on'); clearTimeout(bigTimer); bigTimer = setTimeout(() => el.classList.remove('is-on'), 4200) }

function updateHud () {
  setText($('#hearts'), Array.from({ length: HEARTS }, (_, i) => `<i class="${i < P.hearts ? 'on' : ''}"></i>`).join(''), true)
  $('#light-bar').style.width = `${P.light}%`
  $('#light').classList.toggle('low', P.light < 25)
  setText($('#souls'), `${S.souls.size} / ${TOTAL_SOULS}`)
  const b = S.boss
  const bossOn = !!(b && b.on && !b.dead)
  $('#boss').classList.toggle('is-on', bossOn)
  $('#hud').classList.toggle('boss-on', bossOn)
  if (bossOn) {
    setText($('#boss-name'), BOSS_INFO[b.kind].name)
    $('#boss-bar').style.width = `${Math.max(0, b.hp / b.max) * 100}%`
    setText($('#boss-note'), b.kind === 'gardener' ? `${b.hp} string${b.hp > 1 ? 's' : ''} left` : b.kind === 'witch' && b.sp?.some(h => h > 0) ? (n => `${n} spindle${n > 1 ? 's' : ''} still standing`)(b.sp.filter(h => h > 0).length) : '')
  }
  // a gentle nudge
  let hint = ''
  const isl = island()
  if (S.k === 0) hint = !S.beaten.has('garden') ? 'Walk through the green door of light.' : !S.beaten.has('parlour') ? 'The pink door is open now.' : !S.beaten.has('bigtop') ? 'The orange door is open now.' : 'The violet door leads to the Spindle Tower.'
  else if (S.gateOpen && isl.id !== 'tower') hint = 'The door home is open at the far edge.'
  else {
    const cocoonsLeft = isl.cocoons.filter((c, i) => !S.souls.has(`${isl.id}-c${i}`)).length
    if (cocoonsLeft) hint = `${cocoonsLeft} soul${cocoonsLeft > 1 ? 's are' : ' is'} wound up somewhere on this island. Shine on the red cocoons.`
  }
  setText($('#hint'), hint)
  // the prompt: what the lantern is pointing at
  let prompt = ''
  if (P.down) prompt = 'Your thread is mending…'
  setText($('#prompt'), prompt)
  if (G.coop && net.online) setText($('#team'), [...net.players.values()].map(p => esc(p.name) + (p.id === myId() ? ' (you)' : '')).join('<br>'), true)
}

function showOffer (on) {
  $('#offer').classList.toggle('is-on', on)
  if (on) { document.exitPointerLock?.() }
}
function answer (accept) { request('answer', { accept }); showOffer(false) }
$('#offer-yes').addEventListener('click', () => answer(true))
$('#offer-no').addEventListener('click', () => answer(false))

const ENDINGS = {
  dawn: { title: 'Dawn', text: ['The witch comes apart like an old sleeve. Every thread she ever spun goes slack at once.', 'Twelve small lights rise out of the fog, and one of them is Pip, and he is laughing.', 'The islands sink gently into the clouds. Wren wakes in her own bed with the window open and the lantern cold in her hands. Down the hall, a door opens.'] },
  thread: { title: 'Thread', text: ['The witch comes apart like an old sleeve. Pip\'s light finds Wren\'s hand and holds on.', 'But not every cocoon was opened. Somewhere above the fog a few red threads are still turning, still waiting.', 'Wren keeps one loose thread in her pocket. Some nights it tugs. She could go back. (Free every soul for the true ending.)'] },
  spindle: { title: 'Spindle', text: ['Wren puts the lantern down.', 'The witch is very kind to her. She is given a seat at the long table, and a new dress, and a needle of her own, and the softest red thread.', 'In the morning a girl\'s bed is empty, and up above the fog there is one more island, small and lit, where someone is sewing.'] },
}
function showEnding (kind, souls) {
  G.mode = 'ending'
  G.offer = false
  showOffer(false)
  input.enabled = false
  document.exitPointerLock?.()
  setHud(false)
  if (!save.endings.includes(kind)) save.endings.push(kind)
  writeSave(true)
  const e = ENDINGS[kind]
  $('#screen-ending').dataset.kind = kind
  setText($('#ending-title'), `${e.title}`)
  setText($('#ending-text'), e.text.map(p => `<p>${esc(p)}</p>`).join(''), true)
  setText($('#ending-meta'), `Souls freed: ${souls} of ${TOTAL_SOULS}. Endings found: ${save.endings.length} of 3.`)
  showScreen('ending')
  A.boss(false)
  A.play(`ending_${kind}`, { vol: 0.9, music: true })
}

function writeSave (force = false) {
  if (!isHost() && !force) return
  save.souls = [...new Set([...S.souls])]
  save.beaten = [...S.beaten]
  store.set('lantern.save', save)
}

function pause () {
  if (G.mode !== 'playing' || current === 'pause') return
  G.paused = !net.online
  input.pressed.clear()
  setText($('#pause-note'), net.online ? 'The others keep going while you rest.' : 'The fog waits.')
  showScreen('pause')
}
function resume () { G.paused = false; showScreen(null); if (!touch) void canvas.requestPointerLock?.() }

function startGame ({ coop = false, k = 0 } = {}) {
  A.S.init(); A.S.setVolume(settings.volume); void A.startBeds()
  G.coop = coop
  if (isHost()) { S.souls = new Set(save.souls); S.beaten = new Set(save.beaten) }
  S.cocoon = {}
  S.ending = null
  G.mode = 'playing'
  loadIsland(k)
  input.enabled = true
  stack.length = 0
  showScreen(null); setHud(true)
  fade(1, 0); setTimeout(() => fade(0, 1400), 80)
  if (!touch) void canvas.requestPointerLock?.()
}
function quitToTitle () {
  if (isHost() && G.mode === 'playing') writeSave()
  disconnect()
  G.mode = 'title'
  input.enabled = false
  document.exitPointerLock?.()
  for (const av of G.avatars.values()) av.model.dispose()
  G.avatars.clear(); G.registry.clear()
  if (G.view) { G.view.dispose(); G.view = null }
  G.fight = null; S.boss = null; S.mins = []
  setHud(false); stack.length = 0; showScreen('title'); updateProfile()
  A.boss(false)
}
function updateProfile () {
  const n = save.souls.length
  setText($('#profile'), n || save.beaten.length ? `${n} of ${TOTAL_SOULS} souls freed${save.endings.length ? `, ${save.endings.length} of 3 endings` : ''}` : 'A new story')
}

// prologue: three short pages before the first night
const PROLOGUE = [
  'Every night the Spindle Witch winds another child out of their bed. She threads their soul on her needle and hangs it on an island above the fog.',
  'Wren\'s little brother Pip was taken on a Tuesday. Nobody else remembers him. His bed is made and his shoes are gone.',
  'Grandmother\'s paper lantern still works. Its light loosens thread. Hold it up to the dark, and the dark lets go.',
]
let page = 0
function showPrologue (then) {
  page = 0
  const el = $('#prologue-text')
  const draw = () => { el.textContent = PROLOGUE[page]; setText($('#prologue-next'), page < PROLOGUE.length - 1 ? 'Turn the page' : 'Light the lantern') }
  draw()
  showScreen('prologue')
  $('#prologue-next').onclick = () => { page++; if (page >= PROLOGUE.length) { save.introSeen = true; store.set('lantern.save', save); then() } else draw() }
}

function refreshLobby () {
  if (!net.online) return
  setText($('#lobby-code'), net.code || '- - - -')
  setText($('#lobby-roster'), [...net.players.values()].map(p => `<li>${esc(p.name)}${p.id === net.hostId ? '<small>leads</small>' : ''}${p.id === net.id ? '<small>you</small>' : ''}</li>`).join(''), true)
  $('#lobby-start').hidden = !isHost()
  setText($('#lobby-hint'), isHost() ? 'Share this code with up to three friends. Your saved story is used.' : 'Waiting for the leader to set off.')
}
const setStatus = (sel, text, bad = false) => { const el = $(sel); el.textContent = text; el.classList.toggle('bad', bad) }
const setName = n => { myName = n.slice(0, 14); try { localStorage.setItem('lantern.name', myName) } catch {} }
async function openRoom () {
  showScreen('lobby', { push: true }); $('#host-name-field').hidden = false; $('#host-name').value = myName
  setStatus('#lobby-status', 'Opening… (the server can take up to a minute to wake up)')
  try { await connect({ url: coopServerUrl(), mode: 'create', name: myName }); setStatus('#lobby-status', ''); refreshLobby() } catch (err) { setStatus('#lobby-status', err.message, true) }
}
async function joinRoom () {
  const code = $('#join-code').value.trim().toUpperCase()
  if (code.length !== 4) { setStatus('#join-status', 'Codes are four letters.', true); return }
  setName($('#join-name').value.trim() || myName)
  setStatus('#join-status', 'Joining… (the server can take up to a minute to wake up)')
  try { await connect({ url: coopServerUrl(), mode: 'join', code, name: myName }); setStatus('#join-status', ''); showScreen('lobby', { push: true }); $('#host-name-field').hidden = true; refreshLobby() } catch (err) { setStatus('#join-status', err.message, true) }
}

document.addEventListener('click', e => {
  const b = e.target.closest('[data-go]')
  if (!b) return
  A.S.init()
  switch (b.dataset.go) {
    case 'play': disconnect(); if (save.introSeen) startGame(); else showPrologue(() => startGame()); break
    case 'host': void openRoom(); break
    case 'join': showScreen('join', { push: true }); $('#join-name').value = myName; break
    case 'join-go': void joinRoom(); break
    case 'howto': showScreen('howto', { push: true }); break
    case 'settings': syncSettings(); showScreen('settings', { push: true }); break
    case 'back': backScreen(); break
    case 'leave': disconnect(); stack.length = 0; showScreen('title'); break
    case 'lobby-start': if (isHost()) { sendAll('start', { k: 0 }); startGame({ coop: true }) } break
    case 'resume': resume(); break
    case 'quit': quitToTitle(); break
    case 'reset': if (confirm('Start the story again? Freed souls and beaten bosses will be forgotten. Endings you found are kept.')) { save = { ...freshSave(), endings: save.endings }; store.set('lantern.save', save); updateProfile() } break
    case 'after-ending': {
      // after the tower, the story starts over but the endings you've found are remembered
      if (S.ending !== 'thread') { save.souls = []; save.beaten = [] } else save.beaten = save.beaten.filter(id => id !== 'tower')
      store.set('lantern.save', save)
      quitToTitle()
      break
    }
    case 'prologue-skip': save.introSeen = true; store.set('lantern.save', save); startGame(); break
  }
})
$('#host-name').addEventListener('change', e => { setName(e.target.value.trim() || myName); if (net.online) { sendAll('name', { name: myName }); const me = net.players.get(net.id); if (me) me.name = myName; refreshLobby() } })
$('#join-code').addEventListener('keydown', e => { if (e.key === 'Enter') void joinRoom() })
function syncSettings () {
  $('#set-sens').value = settings.sensitivity; $('#set-vol').value = settings.volume
  for (const b of document.querySelectorAll('#set-quality button')) b.setAttribute('aria-pressed', String(b.dataset.q === settings.quality))
  for (const b of document.querySelectorAll('#set-invert button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.invertY)))
}
$('#set-sens').addEventListener('input', e => { settings.sensitivity = +e.target.value; saveSettings() })
$('#set-vol').addEventListener('input', e => { settings.volume = +e.target.value; A.S.setVolume(settings.volume); saveSettings() })
$('#set-quality').addEventListener('click', e => { if (e.target.dataset.q) { settings.quality = e.target.dataset.q; saveSettings(); syncSettings(); setStatus('#settings-status', 'Graphics change when you next load the page.') } })
$('#set-invert').addEventListener('click', e => { if (e.target.dataset.v) { settings.invertY = e.target.dataset.v === 'true'; saveSettings(); syncSettings() } })

// ═════════════ boot ═════════════
bindFullscreenButtons()
initInput(canvas, { onPause: r => { if (r === 'unlock' && !G.offer && G.mode === 'playing') pause() } })
initGamepad(input, { sprintStick: true, held: { [BTN.RT]: 'fire', [BTN.LT]: 'fire', [BTN.LB]: 'sprint' }, press: { [BTN.A]: 'jump', [BTN.X]: 'flare', [BTN.RB]: 'flare', [BTN.LEFT]: 'choice1', [BTN.RIGHT]: 'choice2' } })
if (touch) initTouchControls($('#touch'))
updateProfile()
$('#loading').style.display = 'none'
showScreen('title')
fade(0, 1400)
requestAnimationFrame(frame)
window.__ll = { S, P, G, islands, input, camera, request, startGame, loadIsland, hostRequest, myId, freeSoul, finish, travel, answer, get fight () { return G.fight } }
