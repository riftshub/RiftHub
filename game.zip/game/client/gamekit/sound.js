// Sound engine shared by the site's games: loads the .mp3 files in a game's audio/ folder
// and plays them positioned in 3D (HRTF), with random variants and looping beds.

export function createSound ({ base, names }) {
  let ctx = null
  let master = null
  let sfxBus = null
  let musicBus = null
  let volume = 0.8
  const raw = new Map() // name -> Promise<ArrayBuffer>
  const buffers = new Map() // name -> AudioBuffer
  const variants = new Map() // 'step_metal' -> ['step_metal_1', ...]

  for (const n of names) {
    const m = n.match(/^(.*)_(\d+)$/)
    if (m) {
      if (!variants.has(m[1])) variants.set(m[1], [])
      variants.get(m[1]).push(n)
    }
  }

  // Start downloading right away (no audio context needed for that)
  const prefetch = () => {
    for (const n of names) {
      if (raw.has(n)) continue
      raw.set(n, fetch(`${base}${n}.mp3`).then(r => (r.ok ? r.arrayBuffer() : null)).catch(() => null))
    }
  }

  const decodeAll = async () => {
    await Promise.all(names.map(async n => {
      if (buffers.has(n)) return
      const ab = await raw.get(n)
      if (!ab || !ctx) return
      try {
        const buf = await new Promise((resolve, reject) => {
          const p = ctx.decodeAudioData(ab.slice(0), resolve, reject)
          if (p?.then) p.then(resolve, reject)
        })
        buffers.set(n, buf)
      } catch { /* a missing or broken file just stays silent */ }
    }))
  }

  let ready = null
  const api = {
    get ctx () { return ctx },
    get ready () { return !!ctx && buffers.size > 0 },
    loaded: () => ready,
    prefetch,
    /** Call from a click/tap (browsers only allow audio after a user gesture) */
    init () {
      if (ctx) { if (ctx.state === 'suspended') void ctx.resume(); return ready }
      const AC = window.AudioContext || window.webkitAudioContext
      if (!AC) return Promise.resolve()
      ctx = new AC()
      master = ctx.createGain()
      master.gain.value = volume
      const comp = ctx.createDynamicsCompressor()
      comp.threshold.value = -12
      comp.ratio.value = 4
      master.connect(comp).connect(ctx.destination)
      sfxBus = ctx.createGain(); sfxBus.connect(master)
      musicBus = ctx.createGain(); musicBus.gain.value = 0.7; musicBus.connect(master)
      prefetch()
      ready = decodeAll()
      return ready
    },
    setVolume (v) {
      volume = v
      if (master) master.gain.setTargetAtTime(v, ctx.currentTime, 0.05)
    },
    has: name => buffers.has(name) || (variants.get(name) ?? []).some(n => buffers.has(n)),
    listener (pos, fwd) {
      if (!ctx) return
      const l = ctx.listener
      if (l.positionX) {
        const t = ctx.currentTime
        l.positionX.setTargetAtTime(pos.x, t, 0.02); l.positionY.setTargetAtTime(pos.y, t, 0.02); l.positionZ.setTargetAtTime(pos.z, t, 0.02)
        l.forwardX.setTargetAtTime(fwd.x, t, 0.02); l.forwardY.setTargetAtTime(fwd.y, t, 0.02); l.forwardZ.setTargetAtTime(fwd.z, t, 0.02)
        l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0
      } else {
        l.setPosition(pos.x, pos.y, pos.z)
        l.setOrientation(fwd.x, fwd.y, fwd.z, 0, 1, 0)
      }
    },
    /**
     * Play a sound. name can be a variant group ('step_metal' picks step_metal_1..n at random).
     * opts: { pos:{x,y,z}, vol, rate, rateJitter, loop, music, ref, max, rolloff, delay, offset }
     * Returns a handle { stop(fade), setVol(v, t), setRate(r), setPos(p), ended }
     */
    play (name, opts = {}) {
      if (!ctx) return nullHandle
      const pick = variants.has(name) && !buffers.has(name) ? variants.get(name)[Math.floor(Math.random() * variants.get(name).length)] : name
      const buf = buffers.get(pick)
      if (!buf) return nullHandle
      const src = ctx.createBufferSource()
      src.buffer = buf
      src.loop = !!opts.loop
      const jitter = opts.rateJitter ?? (opts.loop || opts.music ? 0 : 0.06)
      src.playbackRate.value = (opts.rate ?? 1) * (1 + (Math.random() * 2 - 1) * jitter)
      const g = ctx.createGain()
      g.gain.value = opts.vol ?? 1
      let panner = null
      let out = g
      if (opts.pos) {
        panner = ctx.createPanner()
        panner.panningModel = 'HRTF'
        panner.distanceModel = 'inverse'
        panner.refDistance = opts.ref ?? 2
        panner.maxDistance = opts.max ?? 60
        panner.rolloffFactor = opts.rolloff ?? 1.2
        setPannerPos(panner, opts.pos)
        g.connect(panner)
        out = panner
      }
      out.connect(opts.music ? musicBus : sfxBus)
      src.connect(g)
      const when = ctx.currentTime + (opts.delay ?? 0)
      src.start(when, opts.offset ?? (opts.loop ? Math.random() * buf.duration : 0))
      const handle = {
        ended: false,
        stop (fadeTime = 0.05) {
          if (handle.ended) return
          handle.ended = true
          const t = ctx.currentTime
          g.gain.cancelScheduledValues(t)
          g.gain.setValueAtTime(g.gain.value, t)
          g.gain.linearRampToValueAtTime(0, t + fadeTime)
          try { src.stop(t + fadeTime + 0.02) } catch {}
        },
        setVol (v, time = 0.15) { g.gain.setTargetAtTime(v, ctx.currentTime, time) },
        setRate (r, time = 0.3) { src.playbackRate.setTargetAtTime(r, ctx.currentTime, time) },
        setPos (p) { if (panner) setPannerPos(panner, p) },
      }
      src.onended = () => { handle.ended = true; try { g.disconnect(); panner?.disconnect() } catch {} }
      return handle
    },
    /** A looping bed that starts silent; fade it with handle.setVol */
    bed (name, opts = {}) {
      return api.play(name, { ...opts, loop: true, vol: opts.vol ?? 0 })
    },
  }
  return api
}

const nullHandle = { ended: true, stop () {}, setVol () {}, setRate () {}, setPos () {} }

function setPannerPos (p, pos) {
  const y = pos.y ?? 1.2
  if (p.positionX) {
    const t = p.context.currentTime
    p.positionX.setTargetAtTime(pos.x, t, 0.03); p.positionY.setTargetAtTime(y, t, 0.03); p.positionZ.setTargetAtTime(pos.z, t, 0.03)
  } else p.setPosition(pos.x, y, pos.z)
}
