// Fullscreen toggle shared by the site's games.
// Any element with data-fullscreen becomes a toggle; its text follows the state.
// (iPhone Safari doesn't let pages go fullscreen, so the buttons hide themselves there.)

const el = document.documentElement
export const canFullscreen = () => !!(el.requestFullscreen || el.webkitRequestFullscreen)
export const isFullscreen = () => !!(document.fullscreenElement || document.webkitFullscreenElement)

export async function toggleFullscreen () {
  try {
    if (isFullscreen()) await (document.exitFullscreen || document.webkitExitFullscreen).call(document)
    else await (el.requestFullscreen || el.webkitRequestFullscreen).call(el, { navigationUI: 'hide' })
  } catch { /* the browser said no; nothing to do */ }
}

export function bindFullscreenButtons (root = document) {
  const buttons = [...root.querySelectorAll('[data-fullscreen]')]
  const sync = () => {
    for (const b of buttons) {
      b.hidden = !canFullscreen()
      b.textContent = isFullscreen() ? (b.dataset.exitLabel || 'Exit fullscreen') : (b.dataset.label || 'Fullscreen')
      b.setAttribute('aria-pressed', String(isFullscreen()))
    }
  }
  for (const b of buttons) b.addEventListener('click', e => { e.stopPropagation(); void toggleFullscreen() })
  document.addEventListener('fullscreenchange', sync)
  document.addEventListener('webkitfullscreenchange', sync)
  sync()
}
