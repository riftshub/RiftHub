// Player character models for co-op: an articulated person with walk / run / crouch / downed poses,
// a flashlight beam and a floating name tag. Shared by the site's games.
import * as THREE from 'three'

const glowTex = (() => {
  let tex = null
  return () => {
    if (tex) return tex
    const c = document.createElement('canvas')
    c.width = c.height = 64
    const g = c.getContext('2d')
    const r = g.createRadialGradient(32, 32, 0, 32, 32, 32)
    r.addColorStop(0, 'rgba(255,255,255,1)'); r.addColorStop(0.3, 'rgba(255,255,255,.5)'); r.addColorStop(1, 'rgba(255,255,255,0)')
    g.fillStyle = r; g.fillRect(0, 0, 64, 64)
    tex = new THREE.CanvasTexture(c)
    return tex
  }
})()

const OUTFITS = {
  // Vertigo Freight: railway conductor
  conductor: { coat: 0x1e2b40, trim: 0xb08d57, trousers: 0x161b24, shoes: 0x0d0d0f, hat: 'cap', hatColor: 0x14181f, coatTail: true, pack: false },
  // Creeps: explorers in hoodies
  explorer: { coat: 0x7a2e3a, trim: 0xe7e2d6, trousers: 0x2e3f5c, shoes: 0xe9e4da, hat: 'hood', hatColor: null, coatTail: false, pack: true },
}
const SKIN = [0xe0b394, 0xc69276, 0x8d5a3f, 0xf0caa8, 0x5e3b2a]
const COATS = [0x7a2e3a, 0x2f6b4f, 0x35508a, 0x8a6b2f, 0x5b3a7a, 0x2f6f7a]

export const hashId = s => { let h = 0; for (const ch of String(s)) h = Math.trunc(h * 31 + ch.charCodeAt(0)); return Math.abs(h) }

function nameSprite (text) {
  const c = document.createElement('canvas')
  c.width = 256; c.height = 64
  const g = c.getContext('2d')
  g.font = '600 30px system-ui, sans-serif'
  g.textAlign = 'center'
  const w = Math.min(240, g.measureText(text).width + 24)
  g.fillStyle = 'rgba(6,9,13,.55)'
  g.beginPath(); g.roundRect?.(128 - w / 2, 10, w, 44, 10); g.fill()
  g.fillStyle = 'rgba(240,234,220,.95)'
  g.fillText(text, 128, 43)
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, fog: false }))
  s.scale.set(0.95, 0.24, 1)
  s.renderOrder = 5
  return s
}

/**
 * id: used to pick skin tone / colours. opts: { name, outfit: 'conductor' | 'explorer', shadows }
 * Returns { group, update(dt, state), setName(n), dispose() }
 * state: { x, z, yaw, pitch, speed, crouch, down, hidden, flashlight, y }
 */
export function createAvatar (id, opts = {}) {
  const h = hashId(id)
  const o = { ...OUTFITS[opts.outfit ?? 'conductor'] }
  if (opts.outfit === 'explorer') o.coat = COATS[h % COATS.length]
  const mat = (color, rough = 0.8, metal = 0) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal })
  const M = {
    coat: mat(o.coat, 0.85), trim: mat(o.trim, 0.4, opts.outfit === 'conductor' ? 0.7 : 0),
    trousers: mat(o.trousers, 0.9), shoes: mat(o.shoes, 0.6), skin: mat(SKIN[h % SKIN.length], 0.65),
    hair: mat([0x1c140e, 0x3b2616, 0x6b4a2b, 0xb8925a, 0x0e0e10][(h >> 3) % 5], 0.9), eye: mat(0x101010, 0.3),
    hat: o.hatColor != null ? mat(o.hatColor, 0.6) : null, dark: mat(0x1a1a1a, 0.5, 0.4), lens: new THREE.MeshBasicMaterial({ color: 0xfff1c8 }),
  }
  const cast = opts.shadows !== false
  const mesh = (geo, m, parent, x = 0, y = 0, z = 0) => {
    const me = new THREE.Mesh(geo, m)
    me.position.set(x, y, z)
    me.castShadow = cast
    parent.add(me)
    return me
  }
  const joint = (parent, x, y, z) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); return g }

  const group = new THREE.Group()
  const body = joint(group, 0, 0, 0) // everything that tilts when downed
  const hips = joint(body, 0, 0.93, 0)
  mesh(new THREE.CapsuleGeometry(0.15, 0.1, 4, 10), M.trousers, hips, 0, 0.02, 0).scale.set(1.15, 1, 0.8)
  const spine = joint(hips, 0, 0.08, 0)
  // torso: slightly tapered capsule + coat
  const torso = mesh(new THREE.CapsuleGeometry(0.17, 0.36, 4, 12), M.coat, spine, 0, 0.27, 0)
  torso.scale.set(1.12, 1, 0.72)
  if (o.coatTail) {
    const tail = mesh(new THREE.CylinderGeometry(0.2, 0.25, 0.42, 12, 1, true), M.coat, spine, 0, -0.08, 0)
    tail.scale.set(1, 1, 0.75)
    tail.material = M.coat.clone(); tail.material.side = THREE.DoubleSide
    for (let i = 0; i < 4; i++) mesh(new THREE.SphereGeometry(0.014, 8, 6), M.trim, spine, 0, 0.42 - i * 0.1, 0.125)
    mesh(new THREE.BoxGeometry(0.36, 0.035, 0.24), M.dark, spine, 0, 0.06, 0) // belt
  } else {
    // hoodie pocket + drawstrings
    mesh(new THREE.BoxGeometry(0.22, 0.1, 0.03), M.coat, spine, 0, 0.13, 0.115)
    for (const sx of [-0.035, 0.035]) mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.14, 5), M.trim, spine, sx, 0.47, 0.12)
  }
  if (o.pack) {
    const pack = mesh(new THREE.BoxGeometry(0.3, 0.38, 0.14), mat(0x2b2b30, 0.8), spine, 0, 0.3, -0.17)
    pack.rotation.x = 0.05
    for (const sx of [-0.1, 0.1]) mesh(new THREE.BoxGeometry(0.04, 0.42, 0.02), mat(0x1c1c20), spine, sx, 0.33, 0.13)
  }
  const neck = joint(spine, 0, 0.55, 0)
  mesh(new THREE.CylinderGeometry(0.05, 0.055, 0.08, 10), M.skin, neck, 0, 0.03, 0)
  const head = joint(neck, 0, 0.1, 0)
  const skull = mesh(new THREE.SphereGeometry(0.115, 18, 14), M.skin, head, 0, 0.07, 0.005)
  skull.scale.set(0.92, 1.08, 1)
  mesh(new THREE.SphereGeometry(0.118, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), M.hair, head, 0, 0.085, -0.01).scale.set(0.95, 1.05, 1.02)
  for (const sx of [-0.038, 0.038]) mesh(new THREE.SphereGeometry(0.014, 8, 6), M.eye, head, sx, 0.085, 0.1)
  mesh(new THREE.ConeGeometry(0.018, 0.04, 6), M.skin, head, 0, 0.055, 0.115).rotation.x = Math.PI / 2 // nose
  if (o.hat === 'cap') {
    mesh(new THREE.CylinderGeometry(0.12, 0.118, 0.07, 18), M.hat, head, 0, 0.17, 0)
    mesh(new THREE.CylinderGeometry(0.128, 0.128, 0.025, 18), M.hat, head, 0, 0.205, 0.004)
    const visor = mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.012, 16, 1, false, -Math.PI / 2, Math.PI), M.dark, head, 0, 0.14, 0.03)
    visor.scale.set(1, 1, 0.9)
    mesh(new THREE.BoxGeometry(0.05, 0.03, 0.01), M.trim, head, 0, 0.18, 0.12)
  } else if (o.hat === 'hood') {
    const hood = mesh(new THREE.SphereGeometry(0.15, 16, 12, Math.PI * 0.18, Math.PI * 1.64, 0, Math.PI * 0.62), M.coat, head, 0, 0.07, -0.015)
    hood.material = M.coat.clone(); hood.material.side = THREE.DoubleSide
    hood.rotation.y = Math.PI
  }
  // arms
  const arms = [-1, 1].map(side => {
    const shoulder = joint(spine, side * 0.215, 0.5, 0)
    mesh(new THREE.CapsuleGeometry(0.052, 0.22, 4, 8), M.coat, shoulder, 0, -0.14, 0)
    const elbow = joint(shoulder, 0, -0.29, 0)
    mesh(new THREE.CapsuleGeometry(0.045, 0.2, 4, 8), M.coat, elbow, 0, -0.12, 0)
    mesh(new THREE.SphereGeometry(0.045, 10, 8), M.skin, elbow, 0, -0.27, 0.01).scale.set(0.8, 1.1, 0.6)
    return { shoulder, elbow }
  })
  // flashlight in the right hand
  const torch = joint(arms[1].elbow, 0, -0.3, 0.02)
  torch.rotation.x = Math.PI / 2 // torch points along the forearm
  mesh(new THREE.CylinderGeometry(0.022, 0.028, 0.17, 10), M.dark, torch, 0, 0, 0.04).rotation.x = Math.PI / 2
  const lens = mesh(new THREE.CircleGeometry(0.026, 12), M.lens, torch, 0, 0, 0.126)
  lens.castShadow = false
  const lamp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex(), color: 0xfff0c8, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.9 }))
  lamp.scale.setScalar(0.32)
  lamp.position.set(0, 0, 0.14)
  torch.add(lamp)
  const beamMat = new THREE.MeshBasicMaterial({ color: 0xffe6b0, transparent: true, opacity: 0.06, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide })
  const beam = new THREE.Mesh(new THREE.ConeGeometry(0.75, 5, 22, 1, true).translate(0, -2.5, 0).rotateX(-Math.PI / 2), beamMat)
  beam.position.z = 0.14
  torch.add(beam)
  // legs
  const legs = [-1, 1].map(side => {
    const hip = joint(hips, side * 0.09, -0.02, 0)
    mesh(new THREE.CapsuleGeometry(0.068, 0.3, 4, 8), M.trousers, hip, 0, -0.2, 0)
    const knee = joint(hip, 0, -0.42, 0)
    mesh(new THREE.CapsuleGeometry(0.056, 0.3, 4, 8), M.trousers, knee, 0, -0.2, 0)
    const shoe = mesh(new THREE.BoxGeometry(0.1, 0.07, 0.24), M.shoes, knee, 0, -0.43, 0.04)
    shoe.geometry.translate(0, 0, 0)
    return { hip, knee }
  })
  let label = nameSprite(opts.name ?? '')
  label.position.y = 2.05
  group.add(label)

  let phase = 0
  let crouchT = 0
  let downT = 0
  let lastName = opts.name ?? ''

  const api = {
    group,
    head,
    setName (n) {
      if (n === lastName) return
      lastName = n
      group.remove(label)
      label.material.map.dispose()
      label = nameSprite(n)
      label.position.y = 2.05
      group.add(label)
    },
    /** Smoothly pose the model. speed in m/s. */
    update (dt, st) {
      group.visible = !st.hidden && !st.gone
      group.position.set(st.x, st.y ?? 0, st.z)
      group.rotation.y = st.yaw + Math.PI // our yaw 0 looks along -z, the model faces +z
      const speed = st.down ? 0 : Math.min(6, st.speed ?? 0)
      crouchT += ((st.crouch ? 1 : 0) - crouchT) * Math.min(1, dt * 8)
      downT += ((st.down ? 1 : 0) - downT) * Math.min(1, dt * 4)
      const running = speed > 3.2
      phase += dt * (speed > 0.15 ? (running ? 11 : 7.5) * Math.min(1.3, speed / (running ? 4.3 : 2.3)) : 0)
      const s = Math.sin(phase)
      const amp = speed > 0.15 ? Math.min(1, speed / 2.3) * (running ? 0.85 : 0.55) : 0
      // legs
      legs.forEach((l, i) => {
        const ph = i ? -s : s
        l.hip.rotation.x = -ph * amp * 0.75 - crouchT * 1.25
        l.knee.rotation.x = Math.max(0, (i ? Math.cos(phase) : -Math.cos(phase))) * amp * 1.1 + crouchT * 2.1
      })
      hips.position.y = 0.93 - crouchT * 0.38 + (speed > 0.15 ? Math.abs(Math.cos(phase)) * 0.03 * amp : Math.sin(performance.now() / 1300) * 0.004)
      spine.rotation.x = crouchT * 0.45 + (running ? 0.18 : 0.04)
      // arms swing opposite; the torch arm points where the player looks
      arms.forEach((a, i) => {
        const ph = i ? s : -s
        if (i === 1 && st.flashlight) {
          a.shoulder.rotation.x = -1.25 - (st.pitch ?? 0) * 0.9
          a.elbow.rotation.x = -0.25
        } else {
          a.shoulder.rotation.x = ph * amp * 0.8 - crouchT * 0.4
          a.elbow.rotation.x = -0.25 - amp * 0.4 - crouchT * 0.3
        }
        a.shoulder.rotation.z = (i ? -1 : 1) * 0.08
      })
      head.rotation.x = -(st.pitch ?? 0) * 0.6
      // downed: lying on the side, one arm reaching
      body.rotation.z = downT * 1.45
      body.position.y = downT * 0.18
      body.position.x = -downT * 0.75
      if (downT > 0.5) { arms[0].shoulder.rotation.x = -2.6 + Math.sin(performance.now() / 500) * 0.15 }
      const lit = !!st.flashlight && !st.down
      lamp.visible = lit
      beam.visible = lit
      label.position.y = 2.05 - crouchT * 0.4 - downT * 1.3
    },
    dispose () {
      group.traverse(m => { if (m.isMesh) m.geometry.dispose() })
      group.removeFromParent()
    },
  }
  return api
}
