// Night Owl Market: customers. Host runs the AI; everyone renders from snapshots.
import * as THREE from 'three'
import { createAvatar } from '../../gamekit/avatar.js'
import { AISLES, FRONT_ROW, BACK_ROW, DOOR, TILLS, QUEUE } from './store.js'
import { productById } from './data.js'

const SPEED = 1.35

/** Walk route inside the store using the front/back cross aisles */
export function route (from, to) {
  const pts = []
  const inside = p => p.z < 7.8 && p.z > -10.8
  if (!inside(from) || !inside(to)) return [to]
  const aisleOf = p => AISLES.reduce((b, a) => (Math.abs(a - p.x) < Math.abs(b - p.x) ? a : b), AISLES[0])
  const inAisle = p => p.z < FRONT_ROW - 0.4 && p.z > BACK_ROW + 0.4
  const a0 = aisleOf(from), a1 = aisleOf(to)
  if (inAisle(from) && inAisle(to) && Math.abs(a0 - a1) < 0.1) return [to]
  const row = (from.z + to.z) / 2 < (FRONT_ROW + BACK_ROW) / 2 ? BACK_ROW : FRONT_ROW
  if (inAisle(from)) pts.push({ x: a0, z: from.z }, { x: a0, z: row })
  else pts.push({ x: from.x, z: Math.min(from.z, row === FRONT_ROW ? Math.max(from.z, FRONT_ROW) : from.z) })
  if (inAisle(to)) pts.push({ x: a1, z: row }, { x: a1, z: to.z })
  pts.push(to)
  return pts
}

export class Customers {
  /**
   * hooks: { pay(total, till), fx(kind, data), rating(delta, why), unlocked() -> product ids, displays, takeStock(display) -> bool,
   *          playersNear(x,z,r), hurtPlayer(id, dmg), doorStaffed() -> bool, autoDoor() -> bool, cashier() -> bool }
   */
  constructor (hooks) {
    this.hooks = hooks
    this.list = []
    this.nextId = 1
  }

  spawn (visitor) {
    const side = Math.random() < 0.5 ? -1 : 1
    const c = {
      id: `c${this.nextId++}`, v: visitor, x: side * 22, z: 12.6, yaw: 0, state: 'arrive', path: [], speed: 0,
      patience: 45, cart: [], wants: [], till: null, scanned: 0, hp: 0, turnAt: 0, attackAt: 0, anim: 'walk',
    }
    this.list.push(c)
    return c
  }

  queueSlot (c) {
    const q = this.list.filter(o => o.state === 'queue' || o.state === 'arriveQ')
    return q.indexOf(c)
  }

  tillQueue (till) { return this.list.filter(o => (o.state === 'tillQueue' || o.state === 'paying') && o.till === till).sort((a, b) => a.joinedAt - b.joinedAt) }

  move (c, speed, dt) {
    if (!c.path.length) { c.speed = 0; return true }
    const p = c.path[0]
    const dx = p.x - c.x, dz = p.z - c.z, d = Math.hypot(dx, dz)
    const step = speed * dt
    if (d <= step) { c.x = p.x; c.z = p.z; c.path.shift() } else { c.x += dx / d * step; c.z += dz / d * step }
    if (d > 0.02) {
      let dy = Math.atan2(dx, dz) - c.yaw
      while (dy > Math.PI) dy -= Math.PI * 2
      while (dy < -Math.PI) dy += Math.PI * 2
      c.yaw += dy * Math.min(1, dt * 8)
    }
    c.speed = speed
    return !c.path.length
  }

  /** the person at the door: let in (true) or turn away (false) */
  decide (c, admit, by) {
    if (c.state !== 'inspect') return
    if (admit) {
      c.state = 'enter'
      c.path = [DOOR.inner, { x: 0, z: 5.6 }]
      this.hooks.fx('admit', { id: c.id })
      if (!c.v.human) c.turnAt = performance.now() + (15 + Math.random() * 30) * 1000
    } else {
      c.state = 'leave'
      c.path = [DOOR.outer, { x: (Math.random() < 0.5 ? -1 : 1) * 24, z: 12.8 }]
      this.hooks.fx('reject', { id: c.id, human: c.v.human, by })
      if (c.v.human) this.hooks.rating(-0.08, 'turned away a real customer')
      else this.hooks.bounty(20, 'Good call: that wasn\'t a person.')
    }
  }

  update (dt, now, players) {
    const H = this.hooks
    // door: the first in the queue steps into the vestibule when it's free
    if (!this.list.some(c => c.state === 'inspect')) {
      const next = this.list.find(c => c.state === 'queue' && this.queueSlot(c) === 0)
      if (next) { next.state = 'toInspect'; next.path = [DOOR.outer, DOOR.inspect] }
    }
    for (const c of this.list) {
      switch (c.state) {
        case 'arrive': {
          const slot = this.list.filter(o => o.state === 'queue' || o.state === 'arrive').indexOf(c)
          c.path = [QUEUE(Math.max(0, slot))]
          if (this.move(c, SPEED, dt)) c.state = 'queue'
          break
        }
        case 'queue': {
          const slot = this.queueSlot(c)
          c.path = [QUEUE(Math.max(0, slot))]
          this.move(c, SPEED, dt)
          c.yaw = Math.PI
          c.patience -= dt
          if (c.patience <= 0) { c.state = 'leave'; c.path = [{ x: (Math.random() < 0.5 ? -1 : 1) * 24, z: 12.8 }]; H.rating(-0.04, 'a customer got tired of waiting outside'); H.fx('grumble', { x: c.x, z: c.z }) }
          break
        }
        case 'toInspect':
          if (this.move(c, SPEED, dt)) { c.state = 'inspect'; c.inspectAt = now; c.yaw = Math.PI; H.fx('doorbell', {}) }
          break
        case 'inspect':
          c.yaw = Math.PI
          c.patience -= dt * 0.5
          // the door scanner decides when nobody's at the door
          if (H.autoDoor() && !H.doorStaffed() && now - c.inspectAt > 2500) this.decide(c, c.v.human || Math.random() < 0.25, 'scanner')
          else if (c.patience <= -20) this.decide(c, false, 'timeout')
          break
        case 'enter':
          if (this.move(c, SPEED, dt)) {
            c.state = 'shop'
            const pool = H.unlocked()
            const n = 1 + Math.floor(Math.random() * 4)
            c.wants = Array.from({ length: n }, () => pool[Math.floor(Math.random() * pool.length)])
            c.patience = 70
            this.nextWant(c)
          }
          break
        case 'shop':
          if (!c.v.human && c.turnAt && now > c.turnAt) { this.turn(c); break }
          if (this.move(c, SPEED, dt)) {
            if (c.target) {
              // take what's on the shelf
              const d = H.displays.find(x => x.id === c.target)
              const want = c.wants.shift()
              if (d && d.product === want && d.stock > 0) {
                const qty = Math.min(d.stock, 1 + Math.floor(Math.random() * 2))
                for (let k = 0; k < qty; k++) if (H.takeStock(d)) c.cart.push({ product: d.product, value: d.unitValue ?? 1 })
              } else { c.unhappy = (c.unhappy ?? 0) + 1; H.fx('emptyShelf', { x: c.x, z: c.z, product: want }) }
              c.target = null
              c.lingerUntil = now + 600 + Math.random() * 1600
            } else if (!c.lingerUntil || now > c.lingerUntil) this.nextWant(c)
          }
          break
        case 'tillQueue': {
          const q = this.tillQueue(c.till)
          const i = q.indexOf(c)
          const t = TILLS[c.till]
          c.path = [{ x: t.front.x, z: t.front.z - i * 0.85 }]
          this.move(c, SPEED, dt)
          if (!c.path.length) c.yaw = 0
          if (i === 0 && !c.path.length) { c.state = 'paying'; c.scanned = 0; H.fx('atTill', { id: c.id, till: c.till }) }
          c.patience -= dt
          if (!c.v.human && c.turnAt && now > c.turnAt) { this.turn(c); break }
          if (c.patience <= 0) this.walkOut(c, true)
          break
        }
        case 'paying': {
          c.yaw = 0
          c.patience -= dt * 0.6
          if (!c.v.human && c.turnAt && now > c.turnAt) { this.turn(c); break }
          // a hired cashier works till 2 by themselves
          if (c.till === 1 && H.cashier() && now > (c.autoScanAt ?? 0)) { c.autoScanAt = now + 1100; this.scan(c, 'cashier') }
          if (c.patience <= -30) this.walkOut(c, true)
          break
        }
        case 'leave':
          if (this.move(c, SPEED * (c.fleeing ? 2.4 : 1), dt)) c.state = 'gone'
          break
        case 'turned': this.monster(c, dt, now, players); break
        case 'dying':
          c.dieT = (c.dieT ?? 0) + dt
          if (c.dieT > 1.4) c.state = 'gone'
          break
      }
    }
    this.list = this.list.filter(c => c.state !== 'gone')
  }

  nextWant (c) {
    const H = this.hooks
    if (!c.wants.length) {
      if (!c.cart.length) { this.walkOut(c, false); return }
      // pick the shorter till (till 2 only when it's open)
      const tills = H.cashier() ? [0, 1] : [0]
      c.till = tills.reduce((b, t) => (this.tillQueue(t).length < this.tillQueue(b).length ? t : b), tills[0])
      c.state = 'tillQueue'
      c.joinedAt = performance.now()
      c.patience = 75
      const t = TILLS[c.till]
      c.path = route(c, { x: t.front.x, z: t.front.z - 3 })
      return
    }
    const want = c.wants[0]
    const d = H.displays.find(x => x.product === want)
    if (!d) { c.wants.shift(); return }
    c.target = d.id
    const spot = { x: d.customer.x + (Math.random() - 0.5) * 0.4, z: d.display === 'shelf' ? Math.max(d.z0 + 0.3, Math.min(d.z1 - 0.3, d.customer.z + (Math.random() - 0.5) * 6)) : d.customer.z }
    c.path = route(c, spot)
  }

  /** one item over the scanner */
  scan (c, by) {
    if (c.state !== 'paying' || c.scanned >= c.cart.length) return
    c.scanned++
    this.hooks.fx('beep', { till: c.till })
    if (c.scanned >= c.cart.length) {
      const total = c.cart.reduce((s, it) => s + productById(it.product).price * it.value, 0)
      this.hooks.pay(total, c.till, by)
      if (c.unhappy) this.hooks.rating(-0.02 * c.unhappy, 'shelves were empty')
      else this.hooks.rating(0.02, '')
      this.walkOut(c, false)
    }
  }

  walkOut (c, angry) {
    if (angry) { this.hooks.rating(-0.1, 'a customer gave up and walked out'); this.hooks.fx('grumble', { x: c.x, z: c.z }) }
    c.state = 'leave'
    c.cart = []
    c.path = [...route(c, { x: -2.2, z: 6.6 }), DOOR.inner, DOOR.inspect, DOOR.outer, { x: (Math.random() < 0.5 ? -1 : 1) * 24, z: 12.8 }]
  }

  /** the disguise comes off */
  turn (c) {
    c.state = 'turned'
    c.hp = this.hooks.monsterHp()
    c.maxHp = c.hp
    c.path = []
    this.hooks.fx('turn', { id: c.id, x: c.x, z: c.z })
  }

  monster (c, dt, now, players) {
    const H = this.hooks
    // everyone nearby panics and runs out without paying
    for (const o of this.list) {
      if (o === c || !o.v.human || o.state === 'leave' || o.state === 'gone' || o.state === 'turned') continue
      if (o.x < 8.2 && o.z < 8 && Math.hypot(o.x - c.x, o.z - c.z) < 7) {
        o.fleeing = true
        this.walkOut(o, false)
        H.rating(-0.12, 'a customer was terrified')
        H.fx('scream', { x: o.x, z: o.z })
      }
    }
    let target = null
    for (const p of players) { if (p.down) continue; const d = Math.hypot(p.x - c.x, p.z - c.z); if (d < 22 && (!target || d < target.d)) target = { p, d } }
    if (target) {
      if (!c.path.length || now - (c.repath ?? 0) > 500) { c.path = route(c, { x: target.p.x, z: target.p.z }); c.repath = now }
      this.move(c, 3.0, dt)
      if (target.d < 1.1 && now > c.attackAt) { c.attackAt = now + 1000; H.hurtPlayer(target.p.id, 18); H.fx('swipe', { x: c.x, z: c.z }) }
    } else {
      // wander and knock things off shelves
      if (!c.path.length) {
        const d = H.displays[Math.floor(Math.random() * H.displays.length)]
        c.path = route(c, { x: d.customer.x, z: d.customer.z })
        if (d.stock > 0 && Math.random() < 0.6) { for (let k = 0; k < 3; k++) H.takeStock(d); H.fx('smash', { x: d.customer.x, z: d.customer.z }) }
      }
      this.move(c, 1.6, dt)
    }
  }

  /** a hit from a gun: true if it landed on someone */
  damage (c, dmg) {
    if (c.state === 'dying' || c.state === 'gone') return
    if (c.state === 'turned') {
      c.hp -= dmg
      if (c.hp <= 0) { c.state = 'dying'; c.dieT = 0; c.path = []; return 'killed' }
      return 'hit'
    }
    // shot before it turned: if it was one of them, it dies; if it was a person...
    if (!c.v.human) { c.state = 'dying'; c.dieT = 0; c.path = []; return 'unmasked' }
    c.state = 'leave'
    c.fleeing = true
    c.cart = []
    c.path = [...route(c, { x: -2.2, z: 6.6 }), DOOR.inner, DOOR.inspect, DOOR.outer, { x: 24, z: 12.8 }]
    return 'human'
  }

  snapshot () {
    return this.list.map(c => [c.id, +c.x.toFixed(2), +c.z.toFixed(2), +c.yaw.toFixed(2), c.state, +(c.speed ?? 0).toFixed(2), c.till ?? -1, c.scanned, c.cart.length, c.hp > 0 ? Math.round(c.hp / c.maxHp * 100) : 0, c.cart.map(i => i.product).join(',')])
  }
}

// ═════════════ visuals ═════════════

/** a customer as seen by everyone, plus their reflection and shadow */
export function customerVisual (scene, id, v, { shadows = true } = {}) {
  const look = { coat: v.coat, trousers: v.trousers, skin: v.skin, hair: v.hair }
  const model = createAvatar(`cust-${id}`, { outfit: 'shopper', name: '', look, shadows: false })
  model.group.children.filter(c => c.isSprite).forEach(s => { s.visible = false })
  scene.add(model.group)
  const scale = v.height / 175
  const blob = new THREE.Mesh(new THREE.CircleGeometry(0.35, 20), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.45, depthWrite: false }))
  blob.rotation.x = -Math.PI / 2
  blob.position.y = 0.012
  blob.visible = !v.tells.includes('shadow')
  scene.add(blob)
  // the reflection lives behind the mirror (x mirrored about x = -1.2) and only exists for people
  let mirror = null
  if (!v.tells.includes('reflection')) {
    mirror = createAvatar(`cust-${id}`, { outfit: 'shopper', name: '', look, shadows: false })
    mirror.group.children.filter(c => c.isSprite).forEach(s => { s.visible = false })
    mirror.group.scale.x = -1
    scene.add(mirror.group)
  }
  const float = v.tells.includes('float') ? 0.12 : 0
  let monsterT = 0
  return {
    model, blob, mirror,
    update (dt, s) {
      const turned = s.state === 'turned'
      const dying = s.state === 'dying'
      monsterT += ((turned || dying ? 1 : 0) - monsterT) * Math.min(1, dt * 3)
      const st = { x: s.x, z: s.z, yaw: s.yaw, speed: s.speed, y: float + Math.sin(performance.now() / 500) * (float ? 0.02 : 0) }
      model.update(dt, st)
      const sc = scale * (1 + monsterT * 0.35)
      model.group.scale.set(sc, sc * (1 + monsterT * 0.15), sc)
      if (dying) { model.group.rotation.z = Math.min(1.5, (s.dieT ?? 0)); model.group.position.y = -Math.min(1, (s.dieT ?? 0)) * 0.6 }
      model.setEyeGlow(turned || (v.tells.includes('eyes') && Math.sin(performance.now() / 700 + s.x) > 0.55), turned ? 0xff2a1a : 0xffe08a)
      if (turned) {
        model.materials.skin.color.setHex(0x8a9a8a)
        model.head.rotation.z = Math.sin(performance.now() / 70) * 0.25
      }
      blob.position.set(s.x, 0.012, s.z)
      blob.visible = !v.tells.includes('shadow') && !dying
      if (mirror) {
        mirror.update(dt, { ...st, x: -2.4 - s.x })
        mirror.group.scale.set(-scale, scale, scale)
        // only visible in the mirror room
        mirror.group.visible = s.x > -1.2 && s.z > 7.9 && s.z < 10.7
      }
    },
    dispose () { model.dispose(); mirror?.dispose(); scene.remove(blob) },
  }
}

/** The ID card the door console shows */
export function drawIdCard (canvas, v) {
  const g = canvas.getContext('2d')
  const W = canvas.width, H = canvas.height
  g.fillStyle = '#eef3ee'; g.fillRect(0, 0, W, H)
  g.fillStyle = '#3f7a5e'; g.fillRect(0, 0, W, 46)
  g.fillStyle = '#f6f3ea'; g.font = '700 22px system-ui, sans-serif'; g.fillText('CITY RESIDENT CARD', 16, 31)
  // portrait: drawn from the card's stated hair colour
  const hairCol = { Black: '#15110e', Brown: '#5a3a20', Blonde: '#d8b56a', Red: '#9a3a1a', Grey: '#9a9a9a', Blue: '#2e5fa8' }[v.idHair] ?? '#333'
  const skin = '#' + v.skin.toString(16).padStart(6, '0')
  g.fillStyle = '#c9d6cf'; g.fillRect(16, 60, 120, 150)
  g.fillStyle = skin; g.beginPath(); g.ellipse(76, 130, 34, 42, 0, 0, 7); g.fill()
  g.fillStyle = hairCol; g.beginPath(); g.ellipse(76, 104, 38, 22, 0, Math.PI, 0); g.fill(); g.fillRect(38, 100, 76, 10)
  g.fillStyle = '#' + v.coat.toString(16).padStart(6, '0'); g.fillRect(36, 176, 80, 34)
  g.fillStyle = '#1c1f24'; g.beginPath(); g.arc(64, 128, 4, 0, 7); g.arc(88, 128, 4, 0, 7); g.fill()
  const row = (label, value, y) => { g.fillStyle = '#5a6a62'; g.font = '600 14px system-ui, sans-serif'; g.fillText(label, 156, y); g.fillStyle = '#1c1f24'; g.font = '700 20px system-ui, sans-serif'; g.fillText(value, 156, y + 22) }
  row('NAME', v.name, 72)
  row('BORN', v.born, 122)
  row('HEIGHT', `${v.idHeight} cm`, 172)
  row('HAIR', v.idHair, 222)
  row('EXPIRES', v.expires, 272)
  g.strokeStyle = '#3f7a5e'; g.lineWidth = 4; g.strokeRect(2, 2, W - 4, H - 4)
}
