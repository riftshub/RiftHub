// Night Owl Market: first-person guns (models, recoil, tracers) and the hit test the host runs.
import * as THREE from 'three'

const std = (c, r = 0.5, m = 0.5) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m })
const part = (geo, mat, parent, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); parent.add(m); return m }

/** A gun model held in front of the camera. +z toward the player, barrel along -z. */
export function gunModel (id) {
  const g = new THREE.Group()
  const steel = std(0x2a2d31, 0.35, 0.8)
  const wood = std(0x6b4226, 0.7, 0)
  const brass = std(0xb08d57, 0.3, 0.9)
  if (id === 'pistol') {
    part(new THREE.BoxGeometry(0.05, 0.06, 0.24), steel, g, 0, 0, -0.05)
    part(new THREE.CylinderGeometry(0.033, 0.033, 0.07, 10).rotateZ(Math.PI / 2), steel, g, 0, -0.005, 0.03)
    part(new THREE.CylinderGeometry(0.012, 0.012, 0.16, 8).rotateX(Math.PI / 2), steel, g, 0, 0.015, -0.2)
    part(new THREE.BoxGeometry(0.045, 0.12, 0.06), wood, g, 0, -0.08, 0.08).rotation.x = -0.3
  } else if (id === 'shotgun') {
    part(new THREE.CylinderGeometry(0.018, 0.018, 0.62, 10).rotateX(Math.PI / 2), steel, g, 0, 0.02, -0.25)
    part(new THREE.CylinderGeometry(0.016, 0.016, 0.5, 10).rotateX(Math.PI / 2), steel, g, 0, -0.015, -0.2)
    part(new THREE.BoxGeometry(0.055, 0.05, 0.16), wood, g, 0, -0.015, -0.3) // pump
    part(new THREE.BoxGeometry(0.06, 0.08, 0.2), steel, g, 0, 0, 0.05)
    part(new THREE.BoxGeometry(0.05, 0.1, 0.3), wood, g, 0, -0.05, 0.26).rotation.x = 0.15
  } else if (id === 'uzi') {
    part(new THREE.BoxGeometry(0.06, 0.08, 0.26), steel, g, 0, 0, -0.04)
    part(new THREE.CylinderGeometry(0.012, 0.012, 0.1, 8).rotateX(Math.PI / 2), steel, g, 0, 0.01, -0.22)
    part(new THREE.BoxGeometry(0.035, 0.18, 0.04), steel, g, 0, -0.12, -0.02) // magazine
    part(new THREE.BoxGeometry(0.045, 0.1, 0.05), std(0x1a1a1a, 0.8, 0), g, 0, -0.08, 0.07)
  } else if (id === 'rifle') {
    part(new THREE.CylinderGeometry(0.014, 0.016, 0.7, 10).rotateX(Math.PI / 2), steel, g, 0, 0.02, -0.38)
    part(new THREE.BoxGeometry(0.05, 0.07, 0.5), wood, g, 0, -0.01, -0.05)
    part(new THREE.BoxGeometry(0.05, 0.11, 0.24), wood, g, 0, -0.05, 0.28).rotation.x = 0.12
    part(new THREE.CylinderGeometry(0.022, 0.022, 0.24, 10).rotateX(Math.PI / 2), steel, g, 0, 0.08, -0.08) // scope
    part(new THREE.CylinderGeometry(0.03, 0.03, 0.03, 10).rotateX(Math.PI / 2), brass, g, 0, 0.08, -0.21)
  } else if (id === 'dynamite') {
    for (let k = 0; k < 3; k++) part(new THREE.CylinderGeometry(0.022, 0.022, 0.2, 10), std(0xb8261c, 0.7, 0), g, -0.025 + k * 0.025, 0, 0)
    part(new THREE.BoxGeometry(0.09, 0.03, 0.05), std(0x3a2a1a, 0.9, 0), g, 0, 0.0, 0)
    part(new THREE.CylinderGeometry(0.004, 0.004, 0.08, 4), std(0xe8e1d0, 1, 0), g, 0, 0.13, 0).rotation.z = 0.4
  }
  g.traverse(o => { if (o.isMesh) o.castShadow = false })
  const flash = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0 }))
  flash.position.set(0, 0.015, { pistol: -0.3, shotgun: -0.58, uzi: -0.28, rifle: -0.75, dynamite: 0 }[id] ?? -0.3)
  g.add(flash)
  g.userData.flash = flash
  return g
}

/** Ray vs. upright cylinder (a person). Returns distance or null. */
export function rayCylinder (o, d, cx, cz, r, h) {
  const ox = o.x - cx, oz = o.z - cz
  const a = d.x * d.x + d.z * d.z
  if (a < 1e-9) return null
  const b = 2 * (ox * d.x + oz * d.z)
  const c = ox * ox + oz * oz - r * r
  const disc = b * b - 4 * a * c
  if (disc < 0) return null
  const t = (-b - Math.sqrt(disc)) / (2 * a)
  if (t < 0) return null
  const y = o.y + d.y * t
  if (y < 0 || y > h) return null
  return t
}

/** Ray vs. axis-aligned boxes (walls, shelves) on the floor plan: nearest t, or Infinity */
export function rayBoxes (o, d, boxes) {
  let best = Infinity
  for (const c of boxes) {
    let t0 = 0, t1 = 80
    let ok = true
    for (const [p, dd, lo, hi] of [[o.x, d.x, c.minX, c.maxX], [o.z, d.z, c.minZ, c.maxZ]]) {
      if (Math.abs(dd) < 1e-9) { if (p < lo || p > hi) { ok = false; break } continue }
      let ta = (lo - p) / dd, tb = (hi - p) / dd
      if (ta > tb) [ta, tb] = [tb, ta]
      t0 = Math.max(t0, ta); t1 = Math.min(t1, tb)
      if (t0 > t1) { ok = false; break }
    }
    // shelves are about 2 m tall: shots over the top go past
    if (ok && o.y + d.y * t0 < 2.0 && t0 < best) best = t0
  }
  return best
}

/** a short-lived tracer line */
export function tracer (scene, from, to) {
  const geo = new THREE.BufferGeometry().setFromPoints([from, to])
  const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xffe2a0, transparent: true, opacity: 0.9 }))
  scene.add(line)
  let life = 0.08
  return dt => { life -= dt; line.material.opacity = Math.max(0, life / 0.08); if (life <= 0) { scene.remove(line); geo.dispose(); return false } return true }
}
